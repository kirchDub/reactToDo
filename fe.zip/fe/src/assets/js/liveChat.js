window.onload = function() {
    function configureChatButton() {
        var chatButton = document.getElementsByClassName('mylivechat_inline')[0];
        if (chatButton === undefined) {
            setTimeout(function () {
                configureChatButton();
            }, 1000);
            return;
        }

        chatButton.onclick = function() {
            var collapsed = document.getElementsByClassName('mylivechat_collapsed')[0];
            var expanded = document.getElementsByClassName('mylivechat_expanded')[0];
            var feedback = document.getElementById('_hj-f5b2a1eb-9b07_feedback');
            if (collapsed.style.display == 'none') {
                feedback.style.visibility = 'hidden';
            }
            if (expanded.style.display == 'none') {
                feedback.style.visibility = 'visible';
            }
        }
    }

    configureChatButton();
};