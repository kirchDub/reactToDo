// redirect for ie 8 and older versions
window.location.href = "https://dev-backend.mycbdesk.com/unsupported-browsers"

