    // For IE9. fixes the issue with console.logs stalling the page load.
    console.log('ie9 fix is on')
    if(!window.console) {
        var console = {
            log : function(){},
            warn : function(){},
            error : function(){},
            time : function(){},
            timeEnd : function(){}
        }
    }