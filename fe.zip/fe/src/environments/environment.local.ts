// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  apiBaseURL: 'http://localhost:8000/',
  envName: 'local',
  gtm: 'GTM-K6QQHXB',
  gatewayURL: 'https://gateway-dv.nrtinc.com/',

  oktaAuthEnabled: true,
  oktaTenantUrl: 'https://realogy.oktapreview.com',
  oktaIssuer: 'https://realogy.oktapreview.com/oauth2/ausfby7lsqSlV4VZY0h7',
  oktaClientId: '0oafbe3ugwPI5aiLO0h7',
  oktaRedirectUri: 'http://localhost:4200/implicit/callback',
  impersonateTimeout: 900000,
  LimitRecentApps: 4,
  mobileWidthMax: 470,
  unsupportedBroowserUrl: 'unsupported-browsers',
  applicationName: 'Desk',
  toastyMessageTimeOut: 5000,
  blogArticleLimit: 3,
  topNavDivPicWidth: 38,
  myProfDivPicWidth: 95,
  userMenuDivPicWidth: 61,
};
