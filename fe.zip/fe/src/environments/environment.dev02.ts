// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: true,
  apiBaseURL: 'https://dev02-backend.mycbdesk.com/',
  gtm: 'GTM-K6QQHXB',
  gatewayURL: 'https://gateway-dv.nrtinc.com/',

  oktaAuthEnabled: true,
  oktaTenantUrl: 'https://realogy.okta.com',
  oktaIssuer: 'https://realogy.okta.com/oauth2/default',
  oktaClientId: '0oa7gm3m8hTEoq3mk1t7',
  oktaRedirectUri: 'https://dev02.mycbdesk.com/implicit/callback',
  impersonateTimeout: 900000,
  LimitRecentApps: 4,
  mobileWidthMax: 470,
  unsupportedBroowserUrl: 'unsupported-browsers',
  applicationName: 'Desk',
  toastyMessageTimeOut: 5000,
  blogArticleLimit: 3,
  topNavDivPicWidth: 38,
  myProfDivPicWidth: 95,
  userMenuDivPicWidth: 61,
};
