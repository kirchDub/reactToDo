import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/authentication/login/login.component';
import { AppManageComponent } from './components/app-manage/app-manage.component';
import { MessagesComponent } from './components/messages/messages.component';
import { MobileMsgComponent } from './components/mobile-msg/mobile-msg.component';
import { MobileWaffleComponent } from './components/mobile-waffle/mobile-waffle.component';
import { ImpersonateComponent } from './components/impersonate/impersonate.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { StaticPagesComponent } from './components/static-pages/static-pages.component';
import { AuthGuard } from './guards/auth.guard';
import { OktaCallbackComponent } from './components/authentication/okta/okta-callback/okta-callback.component';
import { LogoutComponent } from './components/authentication/logout/logout.component';
import { OktaLoginComponent } from './components/authentication/okta/okta-login/okta-login.component';
import { AppRedirectComponent } from './components/app-redirect/app-redirect.component';
import { MobileWflCtgrsComponent } from './components/mobile-wfl-ctgrs/mobile-wfl-ctgrs.component';

const appRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'app-management', component: AppManageComponent, canActivate: [AuthGuard]  },
  { path: 'messages', component: MessagesComponent, canActivate: [AuthGuard]  },
  { path: 'mobile-msg', component: MobileMsgComponent, canActivate: [AuthGuard]  },
  { path: 'mobile-waffle', component: MobileWaffleComponent, canActivate: [AuthGuard]  },
  { path: 'categories-menu', component: MobileWflCtgrsComponent, canActivate: [AuthGuard]  },
  { path: 'impersonate', component: ImpersonateComponent, canActivate: [AuthGuard]  },
  { path: 'my-profile', component: MyProfileComponent, canActivate: [AuthGuard]  },
  { path: 'okta/login', component: OktaLoginComponent },
  { path: 'implicit/callback', component: OktaCallbackComponent },
  { path: 'pages/:page', component: StaticPagesComponent },
  { path: 'app-redirect/:app/:id', component: AppRedirectComponent, canActivate: [AuthGuard] },
  { path: '', component: DashboardComponent, canActivate: [AuthGuard] },

  // otherwise redirect to home
  { path: '**', redirectTo: 'pages/not-found' }
];

export const routing = RouterModule.forRoot(appRoutes);
