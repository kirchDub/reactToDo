import { Injectable } from '@angular/core';

@Injectable()
export class UserImgPositionService {
  public imagewidth = 194;
  public imageHeight = 298;
  public picStyles: any;
  constructor() {

  }

  public getCoords(coords: string, viewPortSize: number) {
    const picStyles = {};
    if ( coords === '0' || coords === null) {
      picStyles['background-position'] = 'top left';
      picStyles['background-size'] = 'cover';
      return picStyles;
    }
    const faceCoords = coords.split(',');
    const top = Number(faceCoords[0]);
    const right = Number(faceCoords[1]);
    const bottom = Number(faceCoords[2]);
    const left = Number(faceCoords[3]);

    const faceWidth = right - left;
    const faceHeight = bottom - top;
    const centerX = (faceWidth / 2) + left;
    const centerY = (faceHeight / 2) + top;

    const scaledImageWidth = Math.min(centerX, this.imagewidth - centerX);
    const scaledImageHeight = Math.min(centerY, this.imageHeight - centerY);
    const scaledImageDistance = Math.min(scaledImageHeight, scaledImageWidth);

    const calculatedScale = viewPortSize / (2 * scaledImageDistance);

    const rescaledWidth = this.imagewidth * calculatedScale;
    const recalculatedHeight = this.imageHeight * calculatedScale;

    const desiredLeft = Math.max(0, ((centerX - scaledImageDistance) * calculatedScale));
    const desiredTop = Math.max(0, ((centerY - scaledImageDistance) * calculatedScale));

    picStyles['background-position'] = '-' +  desiredLeft.toString() + 'px -' + desiredTop.toString() + 'px';
    picStyles['background-size'] = rescaledWidth.toString() + 'px ' + recalculatedHeight.toString() + 'px';

    return picStyles;
  }

}
