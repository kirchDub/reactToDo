import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { StaticPage } from '../models/static-page.model';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class StaticPagesService {
  staticPage: StaticPage;

  constructor( private http: HttpClient) { }

  getContent(urlPath: string) {
      return this.http.get(environment.apiBaseURL + 'api/static-pages/' + urlPath)
      .map(
        (apiresult: any) => {
          if (apiresult.length === 0 ) {
            throw new Error('empty');
          } else {
            for (const page of apiresult) {
              return new StaticPage().deserialize(page);
            }
          }
      })
      .catch(
        (error: Response) => {
          console.log('Error is : ', error);
          throw new Error('Error retriving page content ' + error);
        }
      );
  }

}
