import { Injectable, Inject } from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Theme } from '../models/theme.model';
import { environment } from '../../environments/environment';
import { UserService } from './user.service';
import { DOCUMENT } from '@angular/common';
import * as _ from 'lodash';

@Injectable()
export class ThemeService {
  public theme: Theme;

  constructor(
    private httpClient: HttpClient,
    private userService: UserService,
    @Inject(DOCUMENT) private doc: any
  ) {
    const currentTheme = JSON.parse(localStorage.getItem('currentTheme'));

    if (currentTheme) {
      this.theme = new Theme().deserialize(currentTheme.theme);
    }

    this.retrieveTheme().subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }

  retrieveTheme() {
    return this.httpClient.get(environment.apiBaseURL + 'api/theme/')
      .map(
        (apiresult: any) => {
          for (const theme of apiresult) {
            this.theme = new Theme().deserialize(theme);
            localStorage.setItem('currentTheme', JSON.stringify({ theme: this.theme }));
            this.live_chat_injection();
          }
        }
      )
      .catch(
        (error: Response) => {
          console.log('Error', error);
          return Observable.throw('Error during Theme API Get' + error);
        }
      );
  }

  setIntroSeen() {
    return this.httpClient.get(environment.apiBaseURL + 'api/theme/' + this.userService.user.id + '/seen')
      .map(
        (results) => {
          this.userService.setIntroSeen();
          return results;
        }
      )
      .catch(
        (error: Response) => {
          return Observable.throw('Error during API Get');
        }
      );
  }

  displayIntroModal(): Boolean {
    if (localStorage.getItem('impersonatedUser') !== null ) {
      return false;
    }

    if (this.theme && this.userService.user) {
      try {
        const startDateTime = new Date(this.theme.introStartDate);
        let newToMe = true;
        try {
          if (this.userService.user.preferences.introVideoSeenOn) {
            const seenTime = new Date(this.userService.user.preferences.introVideoSeenOn);
            if (startDateTime.getTime() < seenTime.getTime()) {
              newToMe = false;
            }
          }
        } catch (e) {
        }

        if ( (startDateTime.getTime() < Date.now()) && newToMe ) {
          return true;
        }
      } catch (e) {
        return false;
      }
    }
    return false;
  }


  live_chat_injection() {
    if (this.theme.chatActive) {
      const a = this.doc.createElement('script');
      const body = this.doc.getElementsByTagName('body')[0];
      let liveChatOffices = '';
      if (_.get(this.userService, 'user.profile.offices', false)) {
        const offices = this.userService.user.profile.offices;
        for (const i of offices) {
          liveChatOffices += i.name.toString() + ', ';
        }
        liveChatOffices = liveChatOffices.replace(/,\s*$/, '');
      }
      a.type = 'text/javascript';
      // <!--Add the following script at the bottom of the web page (before </body></html>)-->
      a.innerHTML = 'function add_chatinline(){var hccid=58463238;'
      + 'var nt=document.createElement("script");nt.async=true;'
      + 'nt.src="https://www.mylivechat.com/chatinline.aspx?hccid="+hccid'
      + ';var ct=document.getElementsByTagName("script")[0];'
      + 'ct.parentNode.insertBefore(nt,ct);}'
      + 'add_chatinline();';

      const b = this.doc.createElement('script');
      b.type = 'text/javascript';
      b.innerHTML = 'function MyLiveChat_OnInit() { ';
      if (_.get(this.userService, 'user', false)) {
        b.innerHTML += 'MyLiveChat_SetUserName(\''
                    + this.userService.user.getFirstName() + ' '
                    + this.userService.user.getLastName() + '\');';
        b.innerHTML += 'MyLiveChat_SetEmail(\'' + this.userService.user.email + '\');';
      }
      b.innerHTML += 'MyLiveChat_SetContextData(\'offices:' + liveChatOffices + '\');';
      b.innerHTML += 'MyLiveChat_SetDepartment(\'nrt-help-desk-team\');}';


      // <!-- Hide the Hotjar feedback button when Chat is opened, show it when Chat is closed -->
      const c = this.doc.createElement('script');
      c.type = 'text/javascript';
      c.innerHTML = 'window.onload = function() {'
          + 'console.log(0);'
          + 'var chatsection = document.getElementsByClassName(\'mylivechat_inline\');'
          + 'console.log(chatsection);'
          + 'function chatClicked() {'
            + 'console.log(1);'
              + 'if (chatsection){'
                  + 'console.log(2);'
                  + 'var collapsed = document.getElementsByClassName(\'mylivechat_collapsed\')[0];'
                  + 'var expanded = document.getElementsByClassName(\'mylivechat_expanded\')[0];'
                  + 'var feedback = document.getElementById(\'_hj-f5b2a1eb-9b07_feedback\');'
                  + 'if (collapsed.style.display == \'none\') {'
                      + 'feedback.style.visibility = \'hidden\';'
                  + '}'
                  + 'if (expanded.style.display == \'none\') {'
                      + 'feedback.style.visibility = \'visible\';'
                  + '}'
              + '}'
          + '}'
          + 'chatsection[0].addEventListener("click", chatClicked);'
      + '};';

      body.appendChild(a);
      body.appendChild(b);
    }
  }
}
