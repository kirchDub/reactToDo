import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ThemeService } from './theme.service';
import * as _ from 'lodash';

@Injectable()
export class PageTitleService {

  constructor( private titleService: Title,
               private theme: ThemeService) { }

  setPageTitle(pageTitle?: string) {
    let title: string = _.get(this.theme, 'theme.appName', '');
    if (pageTitle && pageTitle.trim() !== '') {
      title += ` - ${pageTitle}`;
    }
    this.titleService.setTitle(title);
  }

}
