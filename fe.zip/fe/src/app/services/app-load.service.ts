import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/throw';

import { environment } from '../../environments/environment';
import * as browserDetection from 'detect-browser';
import { Observable } from 'rxjs/Observable';
import { DOCUMENT } from '@angular/common';


@Injectable()
export class AppOnLoadService {
  browsers = ['chrome', 'firefox', 'opera', 'safari', 'ie'];
  versions = [57.1, 57.1, 49.1, 11.0, 11.0];
  browser: any;
  bIndex: number;
  constructor(private httpClient: HttpClient,
              @Inject(DOCUMENT) private doc: any) {
    this.browser = browserDetection.detect();
    this.bIndex = this.browsers.indexOf(this.browser.name.toLowerCase());
   }

  detectBrowser(): Promise<any> {
    return new Promise((resolve, reject) => {
        if ((this.bIndex > -1) && (parseFloat(this.browser.version) < this.versions[this.bIndex])) {
          const redirectUrl = environment.apiBaseURL + environment.unsupportedBroowserUrl;
          window.location.href = redirectUrl;
        } else {
          resolve();
        }
    });
  }

  gtm_injection() {
    return this.httpClient.get(environment.apiBaseURL + 'api/theme/')
    .subscribe(
      result => {
        if (result[0]['gtm_code']) {
          const s = this.doc.createElement('script');
          s.type = 'text/javascript';
          s.innerHTML = '(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push'
            + '({\'gtm.start\':new Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)'
            + '[0],j=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src='
            + '\'https://www.googletagmanager.com/gtm.js?id=\'+i+dl;f.parentNode.insertBefore(j,f);})'
            + '(window,document,\'script\',\'dataLayer\',\'' + result[0]['gtm_code'] + '\');';
          const head = this.doc.getElementsByTagName('head')[0];
          head.appendChild(s);
        }
        return result;
      },
      error => {
        return Observable.throw('Error during api call.');
      }
    );
  }
}
