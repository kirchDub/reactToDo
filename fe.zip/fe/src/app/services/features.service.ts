import { Injectable } from '@angular/core';
import { Store} from '@ngrx/store';
import * as fromStore from '../store';
import { AuthenticationService } from './authentication.service';



@Injectable()
export class FeatureService {
  public features = {};

  constructor(
    private featureStore: Store<fromStore.FeatureState>,
    private authService: AuthenticationService
  ) {

    this.authService.isAuthenticatedObs().subscribe(
      (authenticated) => {
        if (authenticated) {
          this.featureStore.dispatch(new fromStore.LoadFeatures());
        }
      }
    );

    this.featureStore.select(state => {
      if (state.features && state.features.success) {
        this.features = {};
        for (const f of state.features.features) {
          this.features[f.name.toLowerCase()] = true;
        }
      }
    }).subscribe();
  }

  public enabled(feature: string) {
    if (this.features[feature.toLowerCase()]) {
      return true;
    }

    return false;
  }


}
