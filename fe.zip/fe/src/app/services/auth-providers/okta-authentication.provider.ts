import {Inject, Injectable, OnDestroy} from '@angular/core';
import { Router } from '@angular/router';
import * as OktaAuth from '@okta/okta-auth-js';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BaseAuthenticationProvider } from './base-authentication.provider';
import { Log } from 'ng2-logger';
import { UserService } from '../user.service';
import { User } from '../../models/user.model';
import { environment } from '../../../environments/environment';
import { ApplicationService } from '../application.service';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import * as fromStore from '../../store';
import { ActionsSubject, Store } from '@ngrx/store';
import { FeatureTourService } from '../../services/feature-tour.service';
import {DOCUMENT, PlatformLocation} from '@angular/common';
// const log = Log.create('OktaAuthenticationProvider');

@Injectable()
export class OktaAuthenticationProvider implements BaseAuthenticationProvider, OnDestroy {

  oktaAuth = new OktaAuth({
    url: environment.oktaTenantUrl,
    clientId: environment.oktaClientId,
    issuer: environment.oktaIssuer,
    redirectUri: environment.oktaRedirectUri,
  });

  private actionsSubscription = null;
  private userSubscription = null;

  protected isAuthenticatedSubject = new BehaviorSubject<boolean>(false);

  constructor(
    private router: Router,
    private httpClient: HttpClient,
    private userService: UserService,
    private appService: ApplicationService,
    private featureTourService: FeatureTourService,
    private appStore: Store<fromStore.AppsState>,
    private userStore: Store<fromStore.UserState>,
    private actionsSubject: ActionsSubject,
    public loc: PlatformLocation,
    @Inject(DOCUMENT) private doc: any,
  ) {
    this.userService.setAuthenticated(this.isAuthenticated());
  }

  public isAuthenticated(): boolean {
    // Checks if there is a current accessToken in the TokenManger.
    return !!this.oktaAuth.tokenManager.get('accessToken') && this.isAuthenticatedSubject.getValue();
  }

  public isAuthenticatedObs(): Observable<boolean> {
    return this.isAuthenticatedSubject.asObservable();
  }

  public handle401Response(): void {
    this.logout();
    this.redirectToLogin();
  }

  public redirectToLogin() {
    this.router.navigate(['/okta/login']);
  }

  public login() {
    this.oktaAuth.token.getWithRedirect({
      responseType: ['id_token', 'token'],
      scopes: ['openid', 'email', 'profile']
    });
  }

  public async logout() {
    this.isAuthenticatedSubject.next(false);
    this.oktaAuth.tokenManager.clear();
    await this.oktaAuth.signOut();
  }

  public getHeaderOptions(): any {
    return {
      Authorization: `OIDC-Bearer ${this.getToken()}`
    };
  }

  public getToken(): string {
    const token = this.oktaAuth.tokenManager.get('accessToken');
    if (token) {
      return token.accessToken;
    }

    return null;
  }

  public async handleAuthentication() {
    let accessToken = null;
    let tokens;

    let fullAuth = false;

    if (!this.oktaAuth.tokenManager.get('accessToken')) {
      fullAuth = true;

      try {
        tokens = await this.oktaAuth.token.parseFromUrl();
      } catch (e) {
        console.error(e.message);
        if (e.message.indexOf('not assigned') > -1) {   // User is not assigned to the client application
          return Promise.reject(new Error('Not assigned the ' + environment.applicationName + ' application in Okta'));
        }
        return Promise.reject(new Error('No token provided.'));
      }

      tokens.forEach(token => {
        if (token.idToken) {
          this.oktaAuth.tokenManager.add('idToken', token);
        }
        if (token.accessToken) {
          this.oktaAuth.tokenManager.add('accessToken', token);
          accessToken = token.accessToken;
        }
      });
    }

    await this.authenticateWithOktaToken(fullAuth);
  }

  private async authenticateWithOktaToken(fullAuth: boolean) {
    const headers = new HttpHeaders()
      .set('Authorization', this.getHeaderOptions()['Authorization']);
    let response: any;
    try {
      response = await this.httpClient.get(
        environment.apiBaseURL + 'api/users/current-user/',
        { headers: headers }
      ).toPromise();
    } catch (e) {
      return Promise.reject(new Error(e.error));
    }
    if (response) {
      // check for 401 error
      // render redirect to try again link
      // Error code (more: details) which indicates OktaID out of sync between desk and okta
      // try scenario where user does not exisat
      // backedn: if fail, attempt to sync user in okta (desk app assigned)
      // frontend: if here with 401 error, redirect pages/usernotfound with details okta account
      // not found or not assigned desk, 2nd level will attend to
      // todo

      const user = new User().deserialize(response);
      this.userService.setCurrentUser(user);
      this.userService.saveToLocalStorage();
      this.userService.setAuthenticated(true);

      this.userStore.dispatch(new fromStore.UpdateUserProfileSuccess(response));

      this.isAuthenticatedSubject.next(true);

      this.userStore.dispatch(new fromStore.SyncUserProfile());

      this.actionsSubscription = this.actionsSubject.subscribe(data => {
        const act = data.constructor.name;
        if (act === 'SyncUserProfileSuccess' || act === 'SyncUserProfileFail') {
          this.userStore.dispatch(new fromStore.SyncUserPhoto());
        }

        if (act === 'ImpersonateSuccess') {
          const dashboard = (this.loc as any).location.origin;
          this.doc.location.reload();
          window.location.href = dashboard;
        }
      });

      this.userSubscription =  this.userStore.select(state => {
        this.userService.setCurrentUser(state.user.user);
        return true;
      }).subscribe();

      this.featureTourService.retrieveTours().subscribe(
        (resp) => {},
        (error) => console.log(error)
      );

      if (fullAuth) {
        await this.appService.syncApps().toPromise();
      }

      this.appStore.dispatch(new fromStore.LoadApps());
    }
  }

  ngOnDestroy() {
    this.actionsSubscription.unsubscribe();
    this.userSubscription.unsubscribe();
  }
}
