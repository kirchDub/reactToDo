import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Log } from 'ng2-logger';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { User } from '../../models/user.model';
import { UserService } from '../user.service';
import { BaseAuthenticationProvider } from './base-authentication.provider';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

// const log = Log.create('JwtAuthenticationProvider');

@Injectable()
export class JwtAuthenticationProvider implements BaseAuthenticationProvider {
  public token: string;
  protected isAuthenticatedSubject = new BehaviorSubject<boolean>(false);

  constructor(
    protected userService: UserService,
    protected httpClient: HttpClient,
    protected router: Router
  ) {
    // set token if saved in local storage
    this.loadFromLocalStorate();
  }

  login(username: string, password: string): Observable<boolean> {
    return this.httpClient.post<any>(environment.apiBaseURL + 'api-token-auth/', { username: username, password: password })
      .catch((err: HttpErrorResponse) => {
        // log.error('Login failed', err);
        return Observable.of(false);
      })
      .map((response) => {

        if (response.token) {
          this.token = response.token;
          this.saveToLocalStorage();

          const user = new User().deserialize(response.user);
          this.userService.setAuthenticated(true);
          this.userService.setCurrentUser(user);
          this.userService.saveToLocalStorage();

          this.isAuthenticatedSubject.next(true);

          return true;
        } else {
          // log.error('Auth token not received');
          return false;
        }
      });
  }

  logout(): void {
    this.token = null;
    this.isAuthenticatedSubject.next(false);
    localStorage.removeItem('currentToken');
  }

  redirectToLogin(): void {
    this.router.navigate(['/login']);
  }

  public handle401Response(): void {
    this.redirectToLogin();
  }

  public getToken(): string {
    return this.token;
  }

  public getHeaderOptions(): any {
    return {
      Authorization: `Bearer ${this.token}`
    };
  }

  public isAuthenticated(): boolean {
    return this.token !== null && this.isAuthenticatedSubject.getValue();
  }

  public isAuthenticatedObs(): Observable<boolean> {
    return this.isAuthenticatedSubject.asObservable();
  }

  public saveToLocalStorage(): void {
    localStorage.setItem('currentToken', this.token);
  }

  public loadFromLocalStorate(): void {
    const currentToken = localStorage.getItem('currentToken');

    if (currentToken && !_.isEmpty(currentToken)) {
      this.isAuthenticatedSubject.next(true);
      this.userService.setAuthenticated(true);
      this.token = currentToken;
    } else {
      this.token = null;
    }
  }
}
