import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { HttpClient } from '@angular/common/http';
import { NotificationMessage } from '../models/notification-message.model';
import { environment } from '../../environments/environment';
import {Observable} from 'rxjs/Observable';
import { UserService } from './user.service';
import { AuthenticationService } from './authentication.service';
import * as moment from 'moment';

@Injectable()
export class NotificationMessageService {

  public messages: NotificationMessage[] = [];
  public messages_all: NotificationMessage[] = [];
  public notPresentCnt = 0;
  public ids = [];
  allMessages = '';
  firstRun = true;

  constructor(
    private httpClient: HttpClient,
    private userService: UserService,
    private authService: AuthenticationService
  ) {

    this.authService.isAuthenticatedObs().subscribe(authenticated => {
        if (authenticated) {
          this.getNotifications().subscribe(
            (response) => {
            },
            (error) => console.log(error)
          );

          this.getAllNotifications().subscribe(
            (response) => {
            },
            (error) => console.log(error)
          );
        }
      }
    );

    setInterval(() => {
       this.getNotifications().subscribe(
         (response) => {},
         (error) => console.log(error)
       );
    }, 120000);
  }

  getNotifications() {
    if (!this.authService.isAuthenticated()) {
      return Observable.of(false);
    }

    if (!this.userService.user) {
      return Observable.of(false);
    }

    if (!this.userService.user.id) {
      return Observable.of(false);
    }

    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + this.userService.user.id  + '/notifications/messages')
      .map(
        (apiresult: any) => {
          this.notPresentCnt = 0;
          let allMessages =  '';
          this.ids.length = 0;
          for (const msg of apiresult) {
            if (!msg.state.presented) {
              this.notPresentCnt++;
              this.ids.push(msg.id);
            }
            allMessages +=  msg.title + msg.message;
          }

          if (this.firstRun) {
            this.firstRun = false;
          } else {
            if (allMessages === this.allMessages) {
              return;
            }
          }
          this.allMessages = allMessages;
          this.messages.length = 0;
          for (const message of apiresult) {
            if (!message.state.dismissed) {
              const idx = this.messages.push(new NotificationMessage().deserialize(message));
              this.messages[idx - 1].message = this.messages[idx - 1].message.replace(/src="\//g, 'src="' + environment.apiBaseURL);
            }
          }
        }
      )
      .catch(
        (error: Response) => {
          console.log('Error', error);
          return Observable.throw('Error during Notifications API Get' + error);
        }
      );
  }

  getAllNotifications() {
    if (!this.authService.isAuthenticated()) {
      return Observable.of(false);
    }

    if (!this.userService.user) {
      return Observable.of(false);
    }

    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + this.userService.user.id  + '/notifications/allmessages')
      .map(
        (apiresult: any) => {


          this.messages_all.length = 0;
          for (const message of apiresult) {
              const idx = this.messages_all.push(new NotificationMessage().deserialize(message));
              this.messages_all[idx - 1].message = this.messages_all[idx - 1].message.replace(/src="\//g, 'src="' + environment.apiBaseURL);
              if (!this.messages_all[idx - 1].publishOn) {
                this.messages_all[idx - 1].publishOn = moment().format('YYYY-MM-DDThh:mm:ss');
              }
          }
          this.messages_all.sort(function(a, b) {
            return moment(b.publishOn).valueOf() - moment(a.publishOn).valueOf();
          });
        }
      )
      .catch(
        (error: Response) => {
          console.log('Error', error);
          return Observable.throw('Error during All Notifications API Get' + error);
        }
      );
  }

  public markAsPresented() {
    if (!this.userService.user) {
      return Observable.of(false);
    }
    this.notPresentCnt = 0;

    return this.httpClient.post(
      environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/notifications/messages/present',
      {'message_ids': this.ids}
      )
      .map((res: Response) => {
        for (const m of this.messages) {
          if (!m.state.presented)  {
            m.state.presented = true;
          }
        }
      })
      .catch(
        (error: Response) => {
          console.log('Error during API Post');
          return Observable.throw('Error during API Post');
        }
      );
  }

  markAsDismissed(id) {
    if (!this.userService.user) {
      return Observable.of(false);
    }
    const ids = [];
    ids.push(id);
    return this.httpClient.post(
      environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/notifications/messages/dismiss',
      {'message_ids': ids}
      )
      .map((res: Response) => {
        this.messages = this.messages.filter(function(el) {
          return el.id !== id;
        });
      })
      .catch(
        (error: Response) => {
          console.log('Error during API Post');
          return Observable.throw('Error during API Post');
        }
      );
  }

  public getNotPresented() {

    let cnt = 0;
    for (const m of this.messages) {
      if (!m.state.presented) {
        cnt++;
      }
    }
    return cnt;
  }

  public hasNotPresented(): boolean {
    return this.notPresentCnt > 0;
  }
}
