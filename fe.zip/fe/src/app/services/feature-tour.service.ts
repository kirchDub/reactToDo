import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { FeatureTour } from '../models/feature-tour.model';
import { Router } from '@angular/router';

import { UserService } from './user.service';
import {ApplicationService} from '../services/application.service';
import * as $ from 'jquery';

declare var require: any;

const IntroJs = require('../../../node_modules/intro.js/intro.js');

@Injectable()
export class FeatureTourService {

  private tourPlayer = IntroJs();

  public featureTours: { [path: string]: FeatureTour } = {};
  public lastStep: Number;

  constructor(private httpClient: HttpClient,
              private userService: UserService,
              private router: Router,
              private appService: ApplicationService) {
  }

  // Unused now: this.authservices.user.id - and all other user profile information, will need shortly

  isTourAvailable(): boolean {
    return this.featureTours[this.router.url] && !this.appService.isPhoneDevice();
  }

  getActiveTour(): FeatureTour {
    return this.featureTours[this.router.url];
  }

  playTour() {
    const tour = this.getActiveTour();
    if (!tour) {
      return;
    }
    // removing step from the tour if no widgetReducer present
    const tourOptions = tour.getIntroJSOptions();

    for (let i = tourOptions.steps.length - 1; i > 0; i--) {
      tourOptions.steps[i].intro = tourOptions.steps[i].intro.replace(/src="\//g, 'src="' + environment.apiBaseURL);
      if ($(tourOptions.steps[i].element)[0]) {
        continue;
      } else {
        tourOptions.steps.splice(i, 1);
      }
    }
    tourOptions.steps[0].intro = tourOptions.steps[0].intro.replace(/src="\//g, 'src="' + environment.apiBaseURL);

    const idx = tourOptions.steps.findIndex(s => s.element === '.widget');
    this.tourPlayer.setOptions(tourOptions);
    this.tourPlayer.service = this;

    this.tourPlayer.onchange(function() {
      if (this._currentStep === idx) {
        $('.widget .control').css('display', 'block');
      } else {
        $('.widget .control').css('display', '');
      }
      this.service.updateTourUserStep(this.service.getActiveTour().id, this._currentStep).subscribe(
        (response) => { },
        (error) => console.log(error)
      );
    }).start();
    this.tourPlayer.onexit(function() {
      $('.widget .control').css('display', '');
    });
  }

  retrieveTours() {
    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/feature-tours')
      .map(
        (apiresult: any) => {
          this.lastStep = 0;

          for (const tour of apiresult) {
            const t = new FeatureTour().deserialize(tour);
            this.featureTours[t.urlPath] = t;
          }
          return this.featureTours;
        }
      )
      .catch(
        (error: Response) => {
          console.log('Error', error);
          return Observable.throw('Error during API Get' + error);
        }
      );
  }

  updateTourUserStep(tourID: String, stepNumber: Number) {
    return this.httpClient.get(environment.apiBaseURL + 'api/feature-tours/' + tourID + '/' + stepNumber + '/record')
      .map((res: Response) => console.log(res))
      .catch(
        (error: Response) => {
          return Observable.throw('Error during API Get');
        }
      );
  }

}
