import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
@Injectable()
export class RecentlyUsedAppsService {

  constructor(private http: HttpClient) { }

  markUsed(widget_id, user_id) {
    console.log(environment.apiBaseURL + 'api/users/' + user_id + '/apps/' + widget_id);
    this.http.get(environment.apiBaseURL + 'api/users/' + user_id + '/apps/' + widget_id)
    .subscribe(data => data);
  }
}
