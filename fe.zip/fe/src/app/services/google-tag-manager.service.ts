import { Angulartics2GoogleTagManager } from 'angulartics2/gtm';
import { Injectable } from '@angular/core';
import * as moment from 'moment';

declare var dataLayer: any;

export class GoogleTagManagerProperties {
  public metro: string;
  public office: string;
  public metroID: string;
  public metroName: string;
  public officeID: string;
  public officeName: string;
  public createdAt: string;
  public emailAddress: string;
  public oktaID: string;
  public userType: string;
  public role: string;
}


@Injectable()
export class GoogleTagManagerService extends Angulartics2GoogleTagManager {

  public gtmProperties: GoogleTagManagerProperties = new GoogleTagManagerProperties();

  pageTrack(path: string) {
    if (typeof dataLayer !== 'undefined' && dataLayer) {
      dataLayer.push({
        'event': 'pageView',
        'action': path,
        'content-name': path,
        'userId': this.angulartics2.settings.gtm.userId,
        ...this.gtmProperties
      });
    }
  }

  setMetro(metro: string) {
    this.gtmProperties.metro = metro;
  }

  setOffice(office: string) {
    this.gtmProperties.office = office;
  }

  setMetroID(metro: string) {
    this.gtmProperties.metroID = metro;
  }

  setOfficeID(office: string) {
    this.gtmProperties.officeID = office;
  }

  setOktaID(oktaID: string) {
    this.gtmProperties.oktaID = oktaID;
  }

  setUserType(userType: string) {
    this.gtmProperties.userType = userType;
  }

  setRole(role: string) {
    this.gtmProperties.role = role;
  }

  setCreatedAt(createdAt: string) {
    this.gtmProperties.createdAt = moment(createdAt, 'YYYY-MM-DDTHH:mm:ssZ').format('X');
  }

  setEmailAddress(emailAddress: string) {
    this.gtmProperties.emailAddress = emailAddress;
  }

  setMetroName(metroName: string) {
    this.gtmProperties.metroName = metroName;
  }

  setOfficeName(officeName: string) {
    this.gtmProperties.officeName = officeName;
  }

}


