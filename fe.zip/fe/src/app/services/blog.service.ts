import { Injectable } from '@angular/core';
import { Log } from 'ng2-logger';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Blog } from '../models/blog.model';
import { Observable } from 'rxjs/Observable';
import { UserService } from './user.service';

import 'rxjs/add/observable/throw';

// const log = Log.create('BlogService');

@Injectable()
export class BlogService {
  public blogs = {};

  constructor(protected httpClient: HttpClient, protected userService: UserService) {
  }

  retrieveBlogs(widgetId: string) {
    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/blogs/posts/' + widgetId + '/')
      .map(
        (response: any) => {
          const blogs = [];

          for (const b of response) {
            const blog = new Blog().deserialize(b);
            blogs.push(blog);
          }

          this.blogs[widgetId] = blogs;

          return this.blogs[widgetId];
        }
      )
      .catch(
        (error: Response) => {
          return Observable.throw('Error during API Get');
        }
      );
  }
}
