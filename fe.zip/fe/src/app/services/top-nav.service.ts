import {Injectable} from '@angular/core';
import { Router } from '@angular/router';
import { DomService } from './dom.service';
import { environment } from '../../environments/environment';


@Injectable()
export class TopNavService {
  public waffleMenuVisible = false;
  public profileMenuVisible = false;
  public notificationsMenuVisible = false;
  public favoritesMenuVisible = false;
  private allowOutsideClose = false;
  public userNameWidth = 60;
  public mobile = false;
  public mobileWidth: number;
  public mobileHeight: number;
  public mobileMenuState = 'closed';
  public impersonation = false;
  constructor(protected router: Router,
              public domService: DomService) {
    if (window.screen.width < environment.mobileWidthMax) {
      this.mobile = true;
    }
  }

  toggleState() {
    // Toggle Mobile Menu
    this.allowOutsideClose = false;
    this.mobileMenuState = this.mobileMenuState === 'open' ? 'closed' : 'open';
    if (this.profileMenuVisible === false) {
      this.profileMenuVisible = true;
      if (this.mobile) {
        this.domService.stopScroll();
      }
    } else {
      setTimeout(() => {
        this.profileMenuVisible = false;
        if (this.mobile) {
          this.domService.resumeScroll();
        }
      }, 200);
    }
  }

  closeMobileMenu() {
    if (this.mobile) {
      this.domService.resumeScroll();
    }
    this.allowOutsideClose = false;
    this.mobileMenuState = 'closed';
    setTimeout(() => { this.profileMenuVisible = false; }, 200);
  }

  public showWaffleMenu() {
    this.waffleMenuVisible = true;

    setTimeout(() => { this.allowOutsideClose = true; }, 200);
  }

  public hideWaffleMenu(isOutsideCall: boolean) {
    if (isOutsideCall && !this.allowOutsideClose) {
      return;
    }

    this.waffleMenuVisible = this.allowOutsideClose = false;
  }

  public toggleWaffleMenu(isOutsideCall: boolean) {
    if (this.waffleMenuVisible) {
      this.hideWaffleMenu(isOutsideCall);
    } else {
      this.showWaffleMenu();
    }
  }

  public showNtfknsMenu() {
    this.notificationsMenuVisible = true;

    setTimeout(() => { this.allowOutsideClose = true; }, 200);
  }

  public hideNtfknsMenu(isOutsideCall: boolean) {
    if (isOutsideCall && !this.allowOutsideClose) {
      return;
    }

    this.notificationsMenuVisible = this.allowOutsideClose = false;
  }

  public toggleNtfknsMenu(isOutsideCall: boolean) {
    if (this.notificationsMenuVisible) {
      this.hideNtfknsMenu(isOutsideCall);
    } else {
      this.showNtfknsMenu();
    }
  }

  public showFavoritesMenu() {
    this.favoritesMenuVisible = true;

    setTimeout(() => { this.allowOutsideClose = true; }, 200);
  }

  public hideFavoritesMenu(isOutsideCall: boolean) {
    if (isOutsideCall && !this.allowOutsideClose) {
      return;
    }

    this.favoritesMenuVisible = this.allowOutsideClose = false;
  }

  public toggleFavoritesMenu(isOutsideCall: boolean) {
    if (this.favoritesMenuVisible) {
      this.hideFavoritesMenu(isOutsideCall);
    } else {
      this.showFavoritesMenu();
    }
  }

  public showUserMenu() {
    this.profileMenuVisible = true;

    setTimeout(() => { this.allowOutsideClose = true; }, 200);
  }

  public hideUserMenu(isOutsideCall: boolean) {
    if (isOutsideCall && !this.allowOutsideClose) {
      return;
    }

    this.profileMenuVisible = this.allowOutsideClose = false;
  }

  public toggleUserMenu(isOutsideCall: boolean) {
    if (this.profileMenuVisible) {
      this.hideUserMenu(isOutsideCall);
    } else {
      this.showUserMenu();
    }
  }
}
