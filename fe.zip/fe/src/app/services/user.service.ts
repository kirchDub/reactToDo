import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { GoogleTagManagerService } from './google-tag-manager.service';
import * as _ from 'lodash';
import { User } from '../models/user.model';
import { Office } from '../models/office.model';
import { AuthenticationService } from './authentication.service';



@Injectable()
export class UserService {
  public user: User;
  private authenticated: boolean;

  constructor(
    protected httpClient: HttpClient,
    private gtmService: GoogleTagManagerService,
  ) {
    // set token if saved in local storage
    this.loadFromLocalStorage();
  }

  setupDataLayer() {
    if (!this.user || !this.user.profile) {
      return false;
    }

    this.gtmService.setUsername(this.user.id);
    this.gtmService.setMetro(this.getOrgInfo(this.user.profile.metros[0]));
    this.gtmService.setOffice(this.getOrgInfo(this.user.profile.offices[0]));
    if (this.user.profile.metros[0]) {
      this.gtmService.setMetroName(this.user.profile.metros[0].name.trim());
      this.gtmService.setMetroID(this.user.profile.metros[0].id.trim());
    }
    if (this.user.profile.offices[0]) {
      this.gtmService.setOfficeName(this.user.profile.offices[0].name.trim());
      this.gtmService.setOfficeID(this.user.profile.offices[0].id.trim());
    }
    this.gtmService.setOktaID(this.user.profile.oktaId);
    this.gtmService.setUserType(this.getUserType(this.user.profile.personId, this.user.profile.wwid));
    this.gtmService.setEmailAddress(this.user.email);
    this.gtmService.setCreatedAt(this.user.profile.firstLogin);
  }

  getOrgInfo(unit: any) {
    const orgInfo = [];

    try {
      orgInfo.push(unit.name.trim());
      orgInfo.push(unit.id.trim());
    } catch (e) {
      return '';
    }

    return orgInfo.join(' - ');
  }

  getUserType(personID: string, wwid: string) {
    const userType = [];

    if (_.toNumber(this.user.profile.personId) > 0) {
      userType.push('Agent');
    }

    if (_.toNumber(this.user.profile.wwid) > 0) {
      userType.push('Employee');
    }
    if (!userType.length) {
      userType.push('Unknown');
    }

    return userType.join(' ');
  }

  syncUserProfile(): Observable<boolean> {
    if (!this.isAuthenticated()) {
      return Observable.of(false);
    }

    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + this.user.id + '/profile/sync/')
      .catch((err: HttpErrorResponse) => {
        return Observable.of(false);
      })
      .map((response) => {
        return true;
      });
  }

  public updateUserProfile(): Observable<boolean> {
    if (!this.isAuthenticated()) {
      return Observable.of(false);
    }

    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + this.user.id + '/')
      .catch((err: HttpErrorResponse) => {
        // log.error('Failed to retrieve user:', err);
        return Observable.of(false);
      })
      .map((response) => {
        const user = new User().deserialize(response);
        this.setCurrentUser(user);
        return true;
      });
  }

  setOffice(id): Observable<boolean>  {
    if (!this.isAuthenticated()) {
      return Observable.of(false);
    }
    return this.httpClient.post(environment.apiBaseURL + 'api/users/' + this.user.id + '/active-office/set',
      {'active_office': id})
      .map(
        (res: Response) => {
        return true;
      }
      )
      .catch(
        (error: Response) => {
          return Observable.of(false);
        }
      );
  }

  public setAuthenticated(authenticated: boolean) {
    this.authenticated = authenticated;
  }

  public isAuthenticated(): boolean {
    return (this.authenticated && this.user != null);
  }

  public setCurrentUser(user: User): void {
    this.user = user;
    this.setupDataLayer();
  }

  public setIntroSeen(): void {
    this.user.preferences.introVideoSeenOn = new Date();
    this.saveToLocalStorage();
  }

  public getProfileName(): string {
    if (this.user) {
      const name = this.user.getFirstName();
      const cleanName = name.replace(/\.*$/, '');
      return cleanName.trim();
    } else {
      return '';
    }
  }

  public getProfileFullName(): string {
    if (this.user) {
      return this.user.getFirstName() + ' ' + this.user.getLastName();
    } else {
      return '';
    }
  }
  public getUserId() {
    if (this.user) {
      return this.user.id;
    } else {
      return null;
    }
  }

  public clearUser(): void {
    this.user = null;
    localStorage.removeItem('currentUser');
  }

  public saveToLocalStorage(): void {
    localStorage.setItem('currentUser', JSON.stringify(this.user));
  }

  public loadFromLocalStorage(): void {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (currentUser && !_.isEmpty(currentUser)) {
      const user = new User().deserialize(currentUser);
      this.setCurrentUser(user);
    } else {
      this.user = null;
    }
  }

  public hasPermission(param): boolean {
    param = 'allow_impersonation';
    const objArray = this.user.userPermissions;
    const hasPermission = objArray.find(function (obj: any) { return obj.codename === param; });
    if ( hasPermission ) {
      return true;
    }
    return false;
  }
}
