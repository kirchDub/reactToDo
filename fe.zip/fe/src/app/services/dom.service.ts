import { Injectable, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import * as _ from 'lodash';


@Injectable()
export class DomService {
  public body: any;
  public allowOutsideClose = false;

  constructor(
    @Inject(DOCUMENT) private doc: any,
  ) { }

  measureTxt(text: string, fontSize: number, fontFamily: string): number {
    const canvas = this.doc.createElement('canvas');
    const context = canvas.getContext('2d');
    context.font = fontSize.toString() + 'px ' + fontFamily;
    return context.measureText(text).width;
  }

  scaleFontSizeToFit(text: string, divWidth: number, fontSize: number, fontFamily: string, wordBreak) {
    let words = [text];
    if (wordBreak) {
      words = text.split(' ');
    }
    const textWidth = this.measureTxt(text, fontSize, fontFamily);

    if (words.length < 2 && textWidth < divWidth) {
      return fontSize;
    }

    const wordSizes = [];
    for (let w = 0; w < words.length; w++) {
      const word = words[w];
      while (fontSize > 0) {
        if (this.measureTxt(word, fontSize, fontFamily) < divWidth) {
          wordSizes.push(fontSize);
          break;
        }
        fontSize --;
      }
    }
    return Math.min.apply(null, wordSizes);
  }

  preventDefault(e) {
    e = e || window.event;
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.returnValue = false;
  }

  stopScroll() {
    if (window.addEventListener) {
        window.addEventListener('touchmove', this.preventDefault, false);
    }
    window.ontouchmove  = this.doc.ontouchmove = this.preventDefault;
    this.body = this.doc.getElementsByTagName('body')[0];
    this.body.addEventListener('touchmove', this.preventDefault, false);
  }

  resumeScroll() {
    if (window.removeEventListener) {
      window.removeEventListener('touchmove', this.preventDefault, false);
    }
    this.body.removeEventListener('touchmove', this.preventDefault, false);
    window.ontouchmove = this.doc.ontouchmove = null;
  }
}
