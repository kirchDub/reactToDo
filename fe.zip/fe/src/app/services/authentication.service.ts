import { Injectable } from '@angular/core';
import { JwtAuthenticationProvider } from './auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from './auth-providers/okta-authentication.provider';
import { environment } from '../../environments/environment';
import { BaseAuthenticationProvider } from './auth-providers/base-authentication.provider';
import { UserService } from './user.service';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute, Router, UrlSegment } from '@angular/router';


@Injectable()
export class AuthenticationService {

  private activeAuthService: BaseAuthenticationProvider;

  private currentPath: UrlSegment[];
  private currentQueryParams: {};

  constructor(
    private userService: UserService,
    private jwtAuthService: JwtAuthenticationProvider,
    private oktaAuthService: OktaAuthenticationProvider,
    private router: Router,
    private route: ActivatedRoute,
  ) {
    if (environment.oktaAuthEnabled) {
      this.activeAuthService = oktaAuthService;
    } else {
      this.activeAuthService = jwtAuthService;
    }

    this.route.queryParams.subscribe(params => {
      this.currentQueryParams = params;
    });
  }

  redirectToLogin(): void {
    this.activeAuthService.redirectToLogin();
  }

  redirectPostLogin(): void {
    const postLoginRedirectTo: string = localStorage.getItem('post-login-redirect');
    if (postLoginRedirectTo && postLoginRedirectTo.length > 0) {
      this.router.navigateByUrl(postLoginRedirectTo);
    } else {
      this.router.navigate(['']);
    }
    localStorage.removeItem('post-login-redirect');
  }

  redirectToLogout(): void {
    this.router.navigate(['logout']);
  }

  logout(): void {
    this.userService.clearUser();
    this.activeAuthService.logout();
  }

  public getToken(): string {
    return this.activeAuthService.getToken();
  }

  public handle401Response(): void {
    this.activeAuthService.handle401Response();
  }

  public getHeaderOptions(): any {
    return this.activeAuthService.getHeaderOptions();
  }

  public isAuthenticated(): boolean {
    return this.activeAuthService.isAuthenticated() && this.userService.user !== null;
  }

  public isAuthenticatedObs(): Observable<boolean> {
    return this.activeAuthService.isAuthenticatedObs();
  }
}
