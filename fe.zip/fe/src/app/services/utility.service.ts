import {ApplicationAction} from '../models/application-action.model';
import {MarketLeaderLinks} from '../models/market-leader-links.model';
import * as _ from 'lodash';
import {environment} from '../../environments/environment';


export class UtilityService {
  constructor() {
  }

  public loadLinks ( response: any ) {

    const actions = [];
    if (response.RestOperationResponse) {
      if (_.get(response, 'RestOperationResponse.Status', '') === 'success') {
        if (_.get(response, 'RestOperationResponse.ProfileSiteList.ProfileSite.ProfileSiteMap', '') !== '') {
          const mlLinks = new MarketLeaderLinks()
            .deserialize(response.RestOperationResponse.ProfileSiteList.ProfileSite.ProfileSiteMap);
          actions.length = 0;
          if (typeof mlLinks.provisionLink === 'string') {
            actions.push(new ApplicationAction(1, 'Provision', mlLinks.provisionLink, true));
            actions.push(new ApplicationAction(2, 'Activate Your Account', mlLinks.provisionLink));
          } else if (typeof mlLinks.dashboardLink === 'string') {
            if (typeof mlLinks.dashboardLink === 'string') {
              actions.push(new ApplicationAction(1, 'Dashboard', mlLinks.dashboardLink, true));
            }
            if (typeof mlLinks.newContactsLink === 'string') {
              actions.push(new ApplicationAction(2, 'Leads', mlLinks.newContactsLink));
            }
            if (typeof mlLinks.contactMessagesLink === 'string') {
              actions.push(new ApplicationAction(3, 'Messages', mlLinks.contactMessagesLink));
            }
            if (typeof mlLinks.upcomingRemindersLink === 'string') {
              actions.push(new ApplicationAction(4, 'Reminders', mlLinks.upcomingRemindersLink));
            }
            if (typeof mlLinks.customApplicationLink === 'string') {
              actions.push(new ApplicationAction(5, 'Support', mlLinks.customApplicationLink));
            } else {
              if (typeof mlLinks.contactsLink === 'string') {
                actions.push(new ApplicationAction(5, 'Contacts', mlLinks.contactsLink));
              }
            }
            if (actions.length === 0) {
              this.pushMarketLeaderWarning(actions, 'Market Leader invalid for this office');
            }
          } else if (typeof mlLinks.customApplicationLink === 'string') {
            actions.push(new ApplicationAction(1, 'Support', mlLinks.customApplicationLink, true));
            actions.push(new ApplicationAction(2, 'Support Market Leader', mlLinks.customApplicationLink));
          }
        }
      } else {
        this.pushMarketLeaderError(actions, 'Market Leader Response: Failure');
      }

      if (_.get(response, 'RestOperationResponse.Status', '') === 'success') {
        if (_.get(response, 'RestOperationResponse.ProfileSiteList.ProfileSite.ProfileStatistic', '') !== '') {
          const mlLinks = new MarketLeaderLinks()
            .deserialize(response.RestOperationResponse.ProfileSiteList.ProfileSite.ProfileStatistic);

          if (typeof mlLinks.newListingsCount === 'string') {
            const idx = actions.findIndex(a => (a.label && a.label === 'Leads'));
            if (idx > -1) {
              actions[idx].count = mlLinks.newListingsCount;
            }
          }

          if (typeof mlLinks.waitingMessagesCount === 'string') {
            const idx = actions.findIndex(a => (a.label && a.label === 'Messages'));
            if (idx > -1) {
              actions[idx].count = mlLinks.waitingMessagesCount;
            }
          }

          if (typeof mlLinks.remindersCount === 'string') {
            const idx = actions.findIndex(a => (a.label && a.label === 'Reminders'));
            if (idx > -1) {
              actions[idx].count = mlLinks.remindersCount;
            }
          }

          if (typeof mlLinks.contactsLink !== 'string') {
            if (typeof mlLinks.waitingProspectsCount === 'string') {
              const idx = actions.findIndex(a => (a.label && a.label === 'Contacts'));
              if (idx > -1) {
                actions[idx].count = mlLinks.waitingProspectsCount;
              }
            }
          }
        }
      } else {
        this.pushMarketLeaderError(actions, 'Market Leader Response: Failure');
      }

    } else {
      const error_message = _.get(response, '0.error', '');
      if (error_message.search('MAK') > -1) {
        this.pushMarketLeaderError(actions, 'Unable to obtain Agent Key');
      } else if (error_message.search('API') > -1) {
        this.pushMarketLeaderError(actions, 'Problem accessing Market Leader');
      } else {
        this.pushMarketLeaderError(actions, 'Unknown Market Leader Error');
      }
    }

    if (actions.length === 0) {
      this.pushMarketLeaderError(actions, 'No Market Leader Links found');
    }
    return actions;
  }


  pushMarketLeaderError (actions, error_message) {
    actions.push(new ApplicationAction(1, 'Error', '#', true));
    actions.push(new ApplicationAction(2, error_message, ''));
  }

  pushMarketLeaderWarning (actions, warn_message) {
    actions.push(new ApplicationAction(1, 'Warning', '#', true));
    actions.push(new ApplicationAction(2, warn_message, ''));
  }

}
