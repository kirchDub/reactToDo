import {Inject, Injectable} from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { UserApplication } from '../models/user-application.model';
import { WaffleApp } from '../models/waffle-app.model';

import * as _ from 'lodash';
import { UserService } from './user.service';
import { ImageCacheService } from './image-cache.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Router } from '@angular/router';
import { DOCUMENT } from '@angular/common';

import { Store } from '@ngrx/store';
import { Widget } from './../models/widget.model';
import * as fromStore from '../store';

export enum WidgetMobileState {
  FullTile,
  Collapsed,
}

@Injectable()
export class ApplicationService {
  protected appsRetrievedSubject = new BehaviorSubject<boolean>(false);
  protected mlLinksRetrievedSubject = new BehaviorSubject<boolean>(false);

  private screenWidth: any;
  private router: Router;

  public widgetState: WidgetMobileState = WidgetMobileState.FullTile;
  public apps: UserApplication[] = [];
  public enabledWidgets: Widget[] = [];
  public disabledWidgets: Widget[] = [];
  public waffleApps: WaffleApp[] = [];
  public recentApps: WaffleApp[] = [];
  public widget: Widget;
  public load = false;

  constructor(
    private httpClient: HttpClient,
    private userService: UserService,
    private imageCacheService: ImageCacheService,
    private appStore: Store<fromStore.AppsState>,
    @Inject(DOCUMENT) private document: any
  ) {
    this.screenWidth = window.screen.width;
  }

  syncApps() {
    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/apps/sync')
      .map(
        (results) => {
          return results;
        }
      )
      .catch(
        (error: Response) => {
          return Observable.throw('Error during SyncApps API call');
        }
      );
  }

  public appsRetrievedObs(): Observable<boolean> {
    return this.appsRetrievedSubject.asObservable();
  }

  saveWidgetOrder() {
    const app_ids = [];
    for (const w of this.enabledWidgets) {
      app_ids.push(w.appId);
    }

    return this.httpClient.post(environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/apps/widget-order', app_ids)
      .map((res: Response) => console.log(res))
      .catch(
        (error: Response) => {
          return Observable.throw('Error during Save Widget Order API Post');
        }
      );
  }

  saveWaffleOrder() {
    const app_ids = [];
    for (const w of this.waffleApps) {
      app_ids.push(w.appId);
    }

    return this.httpClient.post(environment.apiBaseURL + 'api/users/' + this.userService.user.id + '/apps/waffle-order', app_ids)
      .map((res: Response) => console.log(res))
      .catch(
        (error: Response) => {
          return Observable.throw('Error during API Post');
        }
      );
  }

  updateWaffleState(waffle: WaffleApp) {
    const data = {
      'waffle_state': waffle.waffleState
    };

    return this.httpClient.patch(environment.apiBaseURL + 'api/user-apps/' + waffle.id + '/', data)
      .map((res: Response) => console.log(res))
      .catch(
        (error: Response) => {
          return Observable.throw('Error during API Get');
        }
      );
  }

  saveWidgetState(wState) {
    let userId;
    if (_.get(this.userService, 'user.id', false)) {
      userId = this.userService.user.id;
    }

    if (userId) {
      this.httpClient.post(environment.apiBaseURL + 'api/users/apps/widget-state', {'widget_state': wState, 'user_id': userId})
        .subscribe(
          result => {
          },
          error => {
            return Observable.throw('Error during Save Widget State API Post because: ' + error);
          }
        );
    }
  }

  switchWidgetState() {
    if (this.widgetState === WidgetMobileState.FullTile && this.isPhoneDevice()) {
      this.widgetState = WidgetMobileState.Collapsed;
    } else {
      this.widgetState = WidgetMobileState.FullTile;
    }
    this.saveWidgetState(this.widgetState);
  }

  isDefaultWidgetLayout(): boolean {
    const defaultWidgets = this.getDefaultWidgets();

    if (defaultWidgets.length !== this.enabledWidgets.length) {
      return false;
    }

    for (let i = 0; i < this.enabledWidgets.length; i++) {
      const w = this.enabledWidgets[i];
      const dw = defaultWidgets[i];

      if (w.id !== dw.id) {
        return false;
      }
    }

    return true;
  }

  getDefaultWidgets(): Widget[] {
    let widgets: Widget[] = [];

    for (const ua of this.apps) {
      if (ua.app.widget) {
        widgets.push(new Widget(ua));
      }
    }

    widgets = _.orderBy(widgets, [function (o) {
      return o.app.defaultWidgetWeight;
    }], ['asc']);
    return widgets;
  }

  isPhoneDevice() {
    return this.screenWidth <= environment.mobileWidthMax;
  }

  setScreenWidth(width): void {
    this.screenWidth = width;

    if (!this.isPhoneDevice()) {
      this.widgetState = WidgetMobileState.FullTile;
    }
  }

  getScreenWidth(): number {
    return this.screenWidth;
  }

  loadUserApps(userApps: any) {
    this.apps = [];
    this.enabledWidgets = [];
    this.disabledWidgets = [];
    this.waffleApps = [];

    for (const userApp of userApps) {
      const a = new UserApplication().deserialize(userApp);

      if (a.app.widget) {
        const w = new Widget(a);
        if (w.widgetState) {
          this.enabledWidgets.push(w);
        } else {
          this.disabledWidgets.push(w);
        }
      }

      // cache waffle image
      this.imageCacheService.cacheImage(a.app.waffleImage);

      if (a.app.type === 1 || a.app.type === 5) {
        this.waffleApps.push(new WaffleApp(a));
      }
      this.apps.push(a);
    }

    this.enabledWidgets = _.orderBy(this.enabledWidgets, [function (o) {
      return o.widgetWeight;
    }], ['asc']);
    this.waffleApps = _.orderBy(this.waffleApps, [function (o) {
      return o.waffleWeight;
    }], ['asc']);
  }

  markAsRecentlyUsed(id) {
    this.appStore.dispatch(new fromStore.MarkAsRecent(id));
  }

  markRecentlyUserRedirect (id, action) {
    this.markAsRecentlyUsed(id);
    this.document.location.href = action;
  }
}
