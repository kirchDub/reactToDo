import { Injectable } from '@angular/core';

@Injectable()
export class ImageCacheService {

  private imageCache = {};

  constructor() { }

  public cacheImages(arr) {
    for (let i = 0; i < arr.length; i++) {
      this.cacheImage(arr[i]);
    }
  }

  public cacheImage(imgSrc): void {
    if (imgSrc && !this.imageCache[imgSrc]) {
      const img =  new Image();
      img.src = imgSrc;
      this.imageCache[imgSrc] = img;
      // console.log('Cached image - ' + imgSrc);
    }
  }
}
