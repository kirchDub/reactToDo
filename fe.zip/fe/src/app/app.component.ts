import { Component } from '@angular/core';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { Angulartics2GoogleTagManager } from 'angulartics2/gtm';
import { GoogleTagManagerService } from './services/google-tag-manager.service';
import { UserService } from './services/user.service';
import * as $ from 'jquery';
import * as OktaAuth from '@okta/okta-auth-js';
import {environment} from '../environments/environment';
import { OktaAuthenticationProvider } from './services/auth-providers/okta-authentication.provider';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  oktaAuth = new OktaAuth({
    url: environment.oktaTenantUrl,
    clientId: environment.oktaClientId,
    issuer: environment.oktaIssuer,
    redirectUri: environment.oktaRedirectUri,
  });

  constructor(
    angulartics2GoogleAnalytics: Angulartics2GoogleAnalytics,
    // angulartics2GoogleTagManager: Angulartics2GoogleTagManager,
    angulartics2GoogleTagManager: GoogleTagManagerService,
    public userService: UserService,
    private okta: OktaAuthenticationProvider,
    private httpClient: HttpClient,
  ) { }
}
