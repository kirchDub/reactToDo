import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private authService: AuthenticationService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.authService.isAuthenticated()) {
      // logged in so return true
      return true;
    }

    // not logged in so redirect to login page
    const postLoginRedirectTo = state.url;
    localStorage.removeItem('post-login-redirect');
    if (postLoginRedirectTo) {
      localStorage.setItem('post-login-redirect', state.url);
    }

    this.authService.redirectToLogin();
    return false;
  }
}
