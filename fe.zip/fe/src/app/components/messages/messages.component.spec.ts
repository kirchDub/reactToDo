import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MessagesComponent } from './messages.component';
import { SafeHtmlPipe } from '../../pipes/safe-html.pipe';
import { NotificationMessageService } from '../../services/notification-message.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../store/reducers/user.reducers';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthenticationService } from '../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../services/auth-providers/okta-authentication.provider';
import { ApplicationService } from '../../services/application.service';
import { ImageCacheService } from '../../services/image-cache.service';
import { FeatureTourService } from '../../services/feature-tour.service';
import { PageTitleService } from '../../services/page-title.service';
import { ThemeService } from '../../services/theme.service';
import { CleanTitlePipe } from '../../pipes/cleanTitle.pipe';

describe('MobileMsgComponent', () => {
  let component: MessagesComponent;
  let fixture: ComponentFixture<MessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MessagesComponent,
        SafeHtmlPipe,
      ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
      ],
      providers: [
        NotificationMessageService,
        UserService,
        GoogleTagManagerService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        ApplicationService,
        ImageCacheService,
        FeatureTourService,
        PageTitleService,
        ThemeService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
