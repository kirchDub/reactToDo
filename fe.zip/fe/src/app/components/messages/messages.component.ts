import { Component, OnInit, OnDestroy } from '@angular/core';
import { NotificationMessageService } from '../../services/notification-message.service';
import { PageTitleService } from '../../services/page-title.service';

@Component({
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})

export class MessagesComponent implements OnInit, OnDestroy {
  constructor(public notificationService: NotificationMessageService,
              private pageTitleService: PageTitleService) { }

  ngOnInit() {
    this.pageTitleService.setPageTitle('Messages');

    this.notificationService.getAllNotifications().subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }

  ngOnDestroy() {}
}

