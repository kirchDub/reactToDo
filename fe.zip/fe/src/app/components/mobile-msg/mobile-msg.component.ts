import { Component, OnInit, OnDestroy } from '@angular/core';
import { NotificationMessageService } from '../../services/notification-message.service';
import { PageTitleService } from '../../services/page-title.service';

@Component({
  templateUrl: './mobile-msg.component.html',
  styleUrls: ['./mobile-msg.component.scss']
})

export class MobileMsgComponent implements OnInit, OnDestroy {
  constructor(public notificationService: NotificationMessageService,
              private pageTitleService: PageTitleService) {  }

  ngOnInit() {
    this.pageTitleService.setPageTitle('Messages');

    this.notificationService.getAllNotifications().subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }

  ngOnDestroy() {}

  removeNote(id) {
    this.notificationService.markAsDismissed(id).subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }
}

