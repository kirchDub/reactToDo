import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MobileMsgComponent } from './mobile-msg.component';
import { RouterTestingModule } from '@angular/router/testing';
import { SafeHtmlPipe } from '../../pipes/safe-html.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NotificationMessageService } from '../../services/notification-message.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../store/reducers/user.reducers';
import { UserService } from '../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { AuthenticationService } from '../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../services/auth-providers/okta-authentication.provider';
import { ApplicationService } from '../../services/application.service';
import { ImageCacheService } from '../../services/image-cache.service';
import { FeatureTourService } from '../../services/feature-tour.service';
import { PageTitleService } from '../../services/page-title.service';
import { ThemeService } from '../../services/theme.service';
import { CleanTitlePipe } from '../../pipes/cleanTitle.pipe';

describe('MobileMsgComponent', () => {
  let component: MobileMsgComponent;
  let fixture: ComponentFixture<MobileMsgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MobileMsgComponent,
        SafeHtmlPipe,
      ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
      ],
      providers: [
        NotificationMessageService,
        UserService,
        GoogleTagManagerService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        ApplicationService,
        ImageCacheService,
        FeatureTourService,
        PageTitleService,
        ThemeService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileMsgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`should have "View all" as a label to link `, () => {
    const componenet = TestBed.createComponent(MobileMsgComponent);
    const compiled = componenet.debugElement.nativeElement;
    expect(compiled.querySelector('a').textContent).toContain('View All');
  });
});


