import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { AppRedirect } from '../../models/app-redirect.model';
import * as _ from 'lodash';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-app-redirect',
  templateUrl: './app-redirect.component.html',
  styleUrls: ['./app-redirect.component.scss']
})
export class AppRedirectComponent implements OnInit {
  static readonly LEADROUTER = 'leadrouter';
  static readonly CBEXCHANGE = 'cbexchange';

  public debug = false;

  @ViewChild('form') form: ElementRef;
  public appType: string;
  public oktaId: string;
  public app: AppRedirect;
  public params = [];
  public isLoading: boolean;
  public hasError: boolean;
  public errorMsg: string;
  public gatewayReturnLink: string;

  constructor(
    private route: ActivatedRoute,
    private httpClient: HttpClient,
    private userService: UserService,
  ) { }

  ngOnInit() {
    this.gatewayReturnLink = environment.gatewayURL + '?desk=return';
    this.appType = this.route.snapshot.paramMap.get('app');
    this.oktaId = this.route.snapshot.paramMap.get('id');
    this.debug = Boolean(this.route.snapshot.queryParamMap.get('debug'));

    this.setupRedirect();
  }

  setupRedirect() {
    this.isLoading = true;
    this.hasError = false;
    switch (this.appType) {
      case AppRedirectComponent.LEADROUTER: {
        this.setupLeadRouterRedirect();
        break;
      }

      case AppRedirectComponent.CBEXCHANGE: {
        this.setupCBExchangeRedirect();
        break;
      }

      default: {
        this.isLoading = false;
        this.hasError = true;
        this.errorMsg = `Unknown application ${this.appType}.`;
      }
    }
  }

  setupLeadRouterRedirect() {
    this.getRedirectInfo(this.oktaId, this.userService.user.profile.getActiveMAK());
  }

  setupCBExchangeRedirect() {
    this.getRedirectInfo(this.oktaId, null);
  }

  getRedirectInfo(oktaId, makId) {
    let url = `${environment.apiBaseURL}api/app-redirect/${oktaId}/`;
    if (makId) {
      url = `${url}${makId}/`;
    }

    return this.httpClient.get(url).subscribe(
      (response: any) => {
        this.app = new AppRedirect().deserialize(response);

        this.form.nativeElement.action = this.app.url;

        this.params = [];
        for (const k of _.keys(this.app.params)) {
          this.params.push({key: k, value: this.app.params[k]});
        }

        if (!this.debug) {
          setTimeout(() => {
              this.form.nativeElement.submit();
              }, 300);

        } else {
          this.isLoading = false;
        }
      },
      (response: any) => {
        this.isLoading = false;
        this.hasError = true;

        if (response.error) {
          this.errorMsg = response.error.error;
        }
      }
    );
  }
}
