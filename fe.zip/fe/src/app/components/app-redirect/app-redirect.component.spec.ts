import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppRedirectComponent } from './app-redirect.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';

describe('AppRedirectComponent', () => {
  let component: AppRedirectComponent;
  let fixture: ComponentFixture<AppRedirectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppRedirectComponent ],
      imports: [ RouterTestingModule,
              HttpClientTestingModule,
              Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
             ],
      providers: [
        UserService,
        GoogleTagManagerService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppRedirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
