import { Component, OnInit } from '@angular/core';
import { TopNavService } from '../../services/top-nav.service';
import { ApplicationService } from '../../services/application.service';
import { RecentlyUsedAppsService } from '../../services/recently-used-apps.service';
import { UserService} from '../../services/user.service';
import * as _ from 'lodash';

import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../store';
import { WaffleApp } from '../../models/waffle-app.model';
import { Category } from '../../models/category.model';
@Component({
  selector: 'app-mobile-wfl-ctgrs',
  templateUrl: './mobile-wfl-ctgrs.component.html',
  styleUrls: ['./mobile-wfl-ctgrs.component.scss']
})
export class MobileWflCtgrsComponent implements OnInit {
  public waffleApps$: Observable<WaffleApp[]>;
  public recentApps$: Observable<WaffleApp[]>;
  public groupedCategories$: Observable<Category[]>;
  public columnCount: number;

  constructor(public topNavService: TopNavService,
              public appService: ApplicationService,
              public recentlyUsed: RecentlyUsedAppsService,
              public userService: UserService,
              private store: Store<fromStore.AppsState>) { }

  ngOnInit() {
    this.groupedCategories$ = this.store.select(state => {
      if (state.apps && state.apps.waffles) {
        const waffleApps = state.apps.waffles.filter((w) => {
          return w.waffleState === 1;
        });
        const groups = [];
        for (const w in waffleApps) {
          if (waffleApps.hasOwnProperty(w)) {
            const wApp = waffleApps[w];
            _.forEach(wApp.app.categories, function(category) {
              if (category.name) {
                const catGroupsIdx =  groups.map(function(e) { return e.name; }).indexOf(category.name);
                if (catGroupsIdx < 0) {
                  category.items = [];
                  category.items.push(wApp);
                  groups.push(category);
                } else {
                  groups[catGroupsIdx].items.push(wApp);
                }
              }
            });
          }
        }
        return _.orderBy(groups, [function(g) { return g.weight; }], ['asc']);
      }
    });

    this.recentApps$ = this.store.select(state => {
      if (state.apps && state.apps.recentApps) {
        let recentApps = state.apps.recentApps;
        if (window.screen.availWidth < 376) {
          recentApps = recentApps.slice(0, 2);
          this.columnCount = 2;
        } else {
          recentApps = recentApps.slice(0, 3);
          this.columnCount = 3;
        }
        return recentApps;
      }
    });
  }
}
