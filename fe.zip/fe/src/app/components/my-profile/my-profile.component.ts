import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PhonePipe } from '../../pipes/phone.pipe';
import { UserService } from '../../services/user.service';
import { PageTitleService } from '../../services/page-title.service';
import { UserImgPositionService } from '../../services/user-img-position.service';
import * as _ from 'lodash';

import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../store';
import { User } from '../../models/user.model';
import { environment } from '../../../environments/environment.prod';
import { PlatformLocation } from '@angular/common';


@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})

export class MyProfileComponent implements OnInit {
  imgStyles = {};
  photoAvailable: boolean;
  public user$: Observable<User>;
  public photoStyle$: Observable<boolean>;

  constructor(public userService: UserService,
    public platformLocation: PlatformLocation,
              public imgPositionService: UserImgPositionService,
              private pageTitleService: PageTitleService,
              private store: Store<fromStore.UserState>) {
  }

  ngOnInit() {
    this.user$ = this.store.select(state => state.user.user);
    this.photoStyle$ = this.store.select(userstate => {
      if (_.get(userstate.user, 'user.profile', false) && userstate.user.photoAvailable) {
        this.photoAvailable = true;
        this.imgStyles = this.imgPositionService.getCoords(
          userstate.user.user.profile.cbhomesPhotoFaceCoords,
          environment.myProfDivPicWidth
        );
        this.imgStyles['background-image'] = 'url('
          + userstate.user.user.profile.cbhomesPhotoUrl
          + ')';
        return userstate.user.photoAvailable;
      } else {
        this.photoAvailable = false;
        return userstate.user.photoAvailable;
      }
    });
    this.pageTitleService.setPageTitle('My Profile');
  }
}
