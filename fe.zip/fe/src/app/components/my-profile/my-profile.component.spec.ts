import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyProfileComponent } from './my-profile.component';
import { PhonePipe } from '../../pipes/phone.pipe';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../store/reducers/user.reducers';
import { UserService } from '../../services/user.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { RouterTestingModule } from '@angular/router/testing';
import { UserImgPositionService } from '../../services/user-img-position.service';
import { PageTitleService } from '../../services/page-title.service';
import { ThemeService } from '../../services/theme.service';

describe('MyProfileComponent', () => {
  let component: MyProfileComponent;
  let fixture: ComponentFixture<MyProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MyProfileComponent,
        PhonePipe,
      ],
      imports: [
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        HttpClientTestingModule,
        RouterTestingModule,
      ],
      providers: [
        UserService,
        GoogleTagManagerService,
        UserImgPositionService,
        PageTitleService,
        ThemeService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
