import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AppSummaryComponent } from './app-summary.component';
import { ApplicationService } from '../../../services/application.service';
import { ImageCacheService } from '../../../services/image-cache.service';
import { UiSwitchModule } from 'ngx-ui-switch';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { StoreModule } from '@ngrx/store';
import { appsReducers } from '../../../store/reducers/apps.reducers';
import { RouterTestingModule } from '@angular/router/testing';
import { UserApplication } from '../../../models/user-application.model';
import { Application } from '../../../models/application.model';
import { WaffleApp } from '../../../models/waffle-app.model';
import { FeatureService } from '../../../services/features.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../services/auth-providers/okta-authentication.provider';
import { FeatureTourService } from '../../../services/feature-tour.service';

describe('AppSummaryComponent', () => {
  let component: AppSummaryComponent;
  let fixture: ComponentFixture<AppSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppSummaryComponent ],
      imports: [
        UiSwitchModule,
        HttpClientTestingModule,
        RouterTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({
          apps: appsReducers
        }),
      ],
      providers: [
        ImageCacheService,
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        FeatureService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        FeatureTourService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const app = new Application();
    app.id = '42';
    app.name = 'Test App';
    app.oktaName = 'Okta Test app';
    app.waffleName = 'test waff name';
    app.widgetName = 'string';
    app.poweredBy = 'string';
    app.desc = 'string';
    app.fgImage = 'string';
    app.waffleImage = 'string';
    app.widget = true;
    app.state = 42;
    app.type = 42;
    app.gradientDirection = 42;
    app.gradientColorOne = 'string';
    app.gradientColorTwo = 'string';
    app.transparency = 42;
    app.defaultWidgetEnabled = true;
    app.defaultWidgetWeight = 42;
    app.defaultWaffleEnabled = true;
    app.defaultWaffleWeight = 42;
    app.actions = [];
    const userApp = new UserApplication();
    userApp.id = '42';
    userApp.userId = 'string';
    userApp.widgetWeight = 42;
    userApp.widgetState = 42;
    userApp.waffleWeight = 42;
    userApp.waffleState = 42;
    userApp.lastUsed = 42;
    userApp.app = app;
    const wApp = new WaffleApp(userApp);
    fixture = TestBed.createComponent(AppSummaryComponent);
    component = fixture.componentInstance;
    component.waffleApp = wApp;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
