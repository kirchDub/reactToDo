import { Component, Input, OnInit } from '@angular/core';
import { WaffleApp } from '../../../models/waffle-app.model';
import { ApplicationService } from '../../../services/application.service';
import { FeatureService } from '../../../services/features.service';

@Component({
  selector: 'app-app-summary',
  templateUrl: './app-summary.component.html',
  styleUrls: ['./app-summary.component.scss']
})
export class AppSummaryComponent implements OnInit {

  @Input()
  public waffleApp: WaffleApp;

  constructor(
    public appService: ApplicationService,
    public fetureService: FeatureService,
    ) { }

  ngOnInit() {
  }

  onToggle($event) {
    const newVal = ($event ? 1 : 0);
    this.waffleApp.waffleState = ($event ? 1 : 0);
    this.appService.updateWaffleState(this.waffleApp).subscribe(
      (response) => {
      }, // console.log(response),
      (error) => console.log(error)
    );
  }
}
