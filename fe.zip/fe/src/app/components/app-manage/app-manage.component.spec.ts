import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { AppManageComponent } from './app-manage.component';
import { ApplicationService } from '../../services/application.service';
import { DragulaService, DragulaModule } from 'ng2-dragula';
import { UiSwitchModule } from 'ngx-ui-switch';
import { PageTitleService } from '../../services/page-title.service';
import { ImageCacheService } from '../../services/image-cache.service';
import { AppSummaryComponent } from './app-summary/app-summary.component';
import { UserService } from '../../services/user.service';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { Angulartics2Module, RouterlessTracking } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StoreModule } from '@ngrx/store';
import { appsReducers } from '../../store/reducers/apps.reducers';
import { ThemeService } from '../../services/theme.service';
import { FeatureService } from '../../services/features.service';
import { AuthenticationService } from '../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../services/auth-providers/jwt-authentication.provider';
import { RouterTestingModule } from '@angular/router/testing';
import { OktaAuthenticationProvider } from '../../services/auth-providers/okta-authentication.provider';
import { FeatureTourService } from '../../services/feature-tour.service';

describe('AppManageComponent', () => {
  let component: AppManageComponent;
  let fixture: ComponentFixture<AppManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppManageComponent, AppSummaryComponent ],
      imports: [
        DragulaModule,
        UiSwitchModule,
        Angulartics2Module,
        HttpClientTestingModule,
        RouterTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({
          apps: appsReducers
        }),
      ],
      providers: [
        ApplicationService,
        DragulaService,
        PageTitleService,
        ImageCacheService,
        UserService,
        GoogleTagManagerService,
        RouterlessTracking,
        ThemeService,
        FeatureService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        FeatureTourService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
