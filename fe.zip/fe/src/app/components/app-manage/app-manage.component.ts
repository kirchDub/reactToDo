import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ApplicationService } from '../../services/application.service';
import { DragulaService } from 'ng2-dragula';
import { PageTitleService } from '../../services/page-title.service';
import { FeatureService } from '../../services/features.service';

import { WaffleApp } from '../../models/waffle-app.model';
import { Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../store';

@Component({
  selector: 'app-app-manage',
  templateUrl: './app-manage.component.html',
  styleUrls: ['./app-manage.component.scss']
})

export class AppManageComponent implements OnInit, OnDestroy {

  public waffleApps$: Observable<WaffleApp[]>;
  public draggerContainerName = 'manage-my-apps';

  constructor(public appService: ApplicationService,
              private dragulaService: DragulaService,
              private pageTitleService: PageTitleService,
              private store: Store<fromStore.AppsState>,
              public fetureService: FeatureService) { }

  ngOnInit() {
    this.waffleApps$ = this.store.select(state => state.apps.waffles);
    this.pageTitleService.setPageTitle('Manage Apps');

    this.dragulaService.setOptions(this.draggerContainerName, {});

    this.dragulaService.dropModel.subscribe((value) => {
      if (value[0] !== 'manage-my-apps') {
        return;
      }

      this.appService.saveWaffleOrder().subscribe(
        (response) => {
        }, // console.log(response),
        (error) => console.log(error)
      );
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.appService.setScreenWidth(window.innerWidth);
  }

  ngOnDestroy() {
    this.dragulaService.destroy(this.draggerContainerName);
  }
}

