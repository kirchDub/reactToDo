import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService } from '../../services/user.service';
@Component({
  templateUrl: './impersonate.component.html',
  styleUrls: ['./impersonate.component.scss']
})

export class ImpersonateComponent implements OnInit, OnDestroy {
  constructor(public userService: UserService) {  }

  ngOnInit() {}
  ngOnDestroy() {}
}
