import { Component, OnInit, NgZone } from '@angular/core';
import { OktaAuthenticationProvider } from '../../../services/auth-providers/okta-authentication.provider';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastyService, ToastyConfig, ToastOptions } from 'ngx-toasty';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromStore from '../../../store';
import * as browserDetection from 'detect-browser';




@Component({
  selector: 'app-impersonation-form',
  templateUrl: './impersonation-form.component.html',
  styleUrls: ['./impersonation-form.component.scss']
})
export class ImpersonationFormComponent implements OnInit {

  public form;
  public email: string;
  public oldToken: string;
  public errorMsg: string;
  public loading: boolean;
  private browser: any;

  constructor(
    private okta: OktaAuthenticationProvider,
    public router: Router,
    public zone: NgZone,
    private userStore: Store<fromStore.UserState>,
    public toastyService: ToastyService)   { }

  ngOnInit() {
    this.loading = false;
    this.browser = browserDetection.detect();
    this.form = new FormGroup({
      email: new FormControl('', Validators.compose(
        [
          Validators.required,
          Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+')
        ]))
    });
  }


  public startImpersonation(e) {
    const messageOptions: ToastOptions = {
      title: 'Error',
      msg: '',
      showClose: true,
      timeout: environment.toastyMessageTimeOut,
      theme: 'bootstrap',
    };
    if ((this.form.valid && e.keyCode === 13) || e.type === 'click') {
      this.userStore.dispatch(new fromStore.Impersonate(this.email));
      this.userStore.select(userstate => {
        this.loading = true;
        if (userstate.user.impersonationStartSuccess) {
          if (this.browser.name.toLowerCase() === 'ie') {
            this.zone.runOutsideAngular(() => {
              this.router.navigate(['']);
            });
          }
        }
        if (userstate.user.impersonationStartFailure) {
          messageOptions['msg'] = userstate.user.impersonationStartErrorText;
          this.toastyService.error(messageOptions);
          this.loading = false;
          return;
        }
        return;
      }).subscribe();

    }
  }
}
