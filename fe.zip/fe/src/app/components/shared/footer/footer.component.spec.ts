import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterComponent } from './footer.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ThemeService } from '../../../services/theme.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../store/reducers/user.reducers';
import { Angulartics2, Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FooterComponent ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
      ],
      providers: [
        ThemeService,
        UserService,
        GoogleTagManagerService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
