import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMenuComponent } from './user-menu.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FeatureTourService } from '../../../../../services/feature-tour.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../../../services/user.service';
import { GoogleTagManagerService } from '../../../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { ApplicationService } from '../../../../../services/application.service';
import { ImageCacheService } from '../../../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../../store/reducers/user.reducers';
import { AuthenticationService } from '../../../../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../../../services/auth-providers/okta-authentication.provider';
import { TopNavService } from '../../../../../services/top-nav.service';
import { DomService } from '../../../../../services/dom.service';
import { ThemeService } from '../../../../../services/theme.service';
import { UserImgPositionService } from '../../../../../services/user-img-position.service';

describe('UserMenuComponent', () => {
  let component: UserMenuComponent;
  let fixture: ComponentFixture<UserMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        UserMenuComponent
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({user: userReducers}),
      ],
      providers: [
        FeatureTourService,
        UserService,
        GoogleTagManagerService,
        ApplicationService,
        ImageCacheService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        TopNavService,
        DomService,
        ThemeService,
        UserImgPositionService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
