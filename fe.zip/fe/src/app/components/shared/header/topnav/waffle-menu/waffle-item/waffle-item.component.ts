import { Component, Input, OnInit } from '@angular/core';
import { WaffleApp } from '../../../../../../models/waffle-app.model';
import { ApplicationService } from '../../../../../../services/application.service';
import { ToastyService, ToastOptions } from 'ngx-toasty';
import { environment } from '../../../../../../../environments/environment';
import { DomService } from '../../../../../../services/dom.service';

import * as _ from 'lodash';


@Component({
  selector: 'app-waffle-item',
  templateUrl: './waffle-item.component.html',
  styleUrls: ['./waffle-item.component.scss']
})
export class WaffleItemComponent implements OnInit {
  private WAFFLE_TITLE_WIDTH = 80;
  private WAFFLE_FONT_SIZE = 12;
  private WAFFLE_FONT_FAMILY = 'Roboto';

  @Input()
  public waffleApp: WaffleApp;
  public scaledFontSize: number;

  constructor(public appService: ApplicationService,
              private toastyService: ToastyService,
              public domService: DomService) { }

  ngOnInit() {
    this.fitTitle(this.waffleApp.getTitle());
  }

  fitTitle(waffleTitle: string) {
    this.scaledFontSize = this.domService.scaleFontSizeToFit(
      waffleTitle,
      this.WAFFLE_TITLE_WIDTH,
      this.WAFFLE_FONT_SIZE,
      this.WAFFLE_FONT_FAMILY,
      true);
  }

  appErrorMsg(event) {
    if (_.get(this.waffleApp, 'app.actions[0].label', 'Error') === 'Error') {
      event.preventDefault();
      const messageOptions: ToastOptions = {
        title: 'Error',
        msg: 'Unfortunately something did not work as expected. Please try again later.',
        showClose: true,
        timeout: environment.toastyMessageTimeOut,
        theme: 'bootstrap',
      };
      this.toastyService.error(messageOptions);
    }
  }
}
