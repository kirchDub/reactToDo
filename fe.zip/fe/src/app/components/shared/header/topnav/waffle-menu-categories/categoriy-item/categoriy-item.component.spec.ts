import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriyItemComponent } from './categoriy-item.component';
import { Application } from '../../../../../../models/application.model';
import { UserApplication } from '../../../../../../models/user-application.model';
import { Widget } from '../../../../../../models/widget.model';
import { WaffleApp } from '../../../../../../models/waffle-app.model';
import { CleanTitlePipe } from '../../../../../../pipes/cleanTitle.pipe';
import { ApplicationService } from '../../../../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../../../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../../../store/reducers/user.reducers';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../../../../services/google-tag-manager.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ImageCacheService } from '../../../../../../services/image-cache.service';
import { ToastyService, ToastyComponent, ToastyConfig } from 'ngx-toasty';
import { DomService } from '../../../../../../services/dom.service';

describe('CategoriyItemComponent', () => {
  let component: CategoriyItemComponent;
  let fixture: ComponentFixture<CategoriyItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CategoriyItemComponent,
        CleanTitlePipe,
      ],
      imports: [
        HttpClientTestingModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        RouterTestingModule,
      ],
      providers: [
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        ToastyService,
        ToastyConfig,
        DomService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {

    const app = new Application();
    app.id = '42';
    app.name = 'Test App';
    app.oktaName = 'Okta Test app';
    app.waffleName = 'test waff name';
    app.widgetName = 'string';
    app.poweredBy = 'string';
    app.desc = 'string';
    app.fgImage = 'string';
    app.waffleImage = 'string';
    app.widget = true;
    app.state = 1;
    app.type = 42;
    app.gradientDirection = 42;
    app.gradientColorOne = 'string';
    app.gradientColorTwo = 'string';
    app.transparency = 42;
    app.defaultWidgetEnabled = true;
    app.defaultWidgetWeight = 42;
    app.defaultWaffleEnabled = true;
    app.defaultWaffleWeight = 42;
    app.actions = [];

    const userApp = new UserApplication();
    userApp.id = 'string';
    userApp.userId = 'string';
    userApp.widgetWeight = 42;
    userApp.widgetState = 1;
    userApp.waffleWeight = 42;
    userApp.waffleState = 1;
    userApp.lastUsed = 42;
    userApp.app = app;

    const waffleApp = new WaffleApp(userApp);
    waffleApp.app = app;

    fixture = TestBed.createComponent(CategoriyItemComponent);
    component = fixture.componentInstance;
    component.waffleApp = waffleApp;
    component.scaledFontSize = 16;
    fixture.detectChanges();
    component.waffleApp = waffleApp;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have an app title', () => {
    const title = fixture.nativeElement.querySelector('.title');
    expect(title.textContent).toContain('test waff name');
  });
});
