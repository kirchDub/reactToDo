import { Component, Input, OnInit } from '@angular/core';
import { NotificationMessage } from '../../../../../../models/notification-message.model';
import { NotificationMessageService } from '../../../../../../services/notification-message.service';
import { environment } from '../../../../../../../environments/environment';


@Component({
  selector: 'app-notification-item',
  templateUrl: './notify-item.component.html',
  styleUrls: ['./notify-item.component.scss']
})
export class NotificationItemComponent implements OnInit {

  @Input()
  public notificationMessage: NotificationMessage;
  @Input()
  public index: number;

  public readmore = false;

  constructor(public notificationMessageService:  NotificationMessageService ) {}

  ngOnInit() {
    if (this.notificationMessage.message.length > 50) {
      this.readmore = true;
    }
  }

  removeNote() {
    this.notificationMessageService.markAsDismissed(this.notificationMessage.id).subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }
}
