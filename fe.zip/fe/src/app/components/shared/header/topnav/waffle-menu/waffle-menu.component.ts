import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TopNavService } from '../../../../../services/top-nav.service';
import { ApplicationService } from '../../../../../services/application.service';
import { RecentlyUsedAppsService } from '../../../../../services/recently-used-apps.service';
import { UserService} from '../../../../../services/user.service';
import * as _ from 'lodash';

import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../../../store';
import { WaffleApp } from '../../../../../models/waffle-app.model';

@Component({
  selector: 'app-waffle-menu',
  templateUrl: './waffle-menu.component.html',
  styleUrls: ['./waffle-menu.component.scss']
})

export class WaffleMenuComponent implements OnInit {

  public waffleApps$: Observable<WaffleApp[]>;
  public recentApps$: Observable<WaffleApp[]>;

  constructor(public topNavService: TopNavService,
              public appService: ApplicationService,
              public recentlyUsed: RecentlyUsedAppsService,
              public userService: UserService,
              private store: Store<fromStore.AppsState>) { }

  ngOnInit() {
    this.waffleApps$ = this.store.select(state => state.apps.waffles);
    this.recentApps$ = this.store.select(state => state.apps.recentApps);
  }
}
