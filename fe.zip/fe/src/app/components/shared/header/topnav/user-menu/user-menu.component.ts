import { Component, OnInit, Input } from '@angular/core';
import { FeatureTourService } from '../../../../../services/feature-tour.service';
import { ApplicationService } from '../../../../../services/application.service';
import { AuthenticationService } from '../../../../../services/authentication.service';
import { environment } from '../../../../../../environments/environment';
import { ThemeService } from '../../../../../services/theme.service';
import { TopNavService } from '../../../../../services/top-nav.service';
import { UserService } from '../../../../../services/user.service';
import { HttpClient } from '@angular/common/http';
import { UserImgPositionService } from '../../../../../services/user-img-position.service';
import { Router } from '@angular/router';
import * as _ from 'lodash';

import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../../../store';


@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.scss']
})
export class UserMenuComponent implements OnInit {
  @Input('viewPort') viewPort: number;
  public imgStyles: {};
  public photoAvailable: boolean;
  public cbPhotoUrl$: Observable<boolean>;

  constructor(
    public featureTourService: FeatureTourService,
    public widgetService: ApplicationService,
    public userService: UserService,
    public authService: AuthenticationService,
    public appService: ApplicationService,
    public topNavService: TopNavService,
    public themeService: ThemeService,
    private httpClient: HttpClient,
    public imgPositionService: UserImgPositionService,
    private router: Router,
    private userStore: Store<fromStore.UserState>,
    private appStore: Store<fromStore.AppsState>,
  ) { }

  ngOnInit() {
    this.cbPhotoUrl$ = this.userStore.select(userstate => {
      if (_.get(userstate.user, 'user.profile', false) && userstate.user.photoAvailable) {
        this.photoAvailable = true;
        this.imgStyles = this.imgPositionService.getCoords(
          userstate.user.user.profile.cbhomesPhotoFaceCoords,
          environment.userMenuDivPicWidth
        );
        this.imgStyles['background-image'] = 'url('
          + userstate.user.user.profile.cbhomesPhotoUrl
          + ')';

        return userstate.user.photoAvailable;
      } else {
        this.photoAvailable = false;
        return userstate.user.photoAvailable;
      }
    });
  }



  closeMobileUserMenu() {
    this.topNavService.closeMobileMenu();
  }

  canResetDashboardLayout() {
    return !this.appService.isDefaultWidgetLayout() && this.router.url === '/';
  }

  resetDashboardLayout() {
    this.appStore.dispatch(new fromStore.ResetWidgets());
    return Observable.of(true);
  }

  logout () {
    this.stopImpersonate();
    setTimeout(() => this.authService.redirectToLogout(), 300);
  }

  adminRedirect() {
    window.location.href = environment.apiBaseURL + 'admin/login/?next=/admin/';
  }

  private async  stopImpersonate() {
    let response: any;
    try {
      response = await this.httpClient.get(
        environment.apiBaseURL + 'api/users/impersonate/stop/').toPromise();
    } catch (e) {
      if (e.status !== 404) {
        return Promise.reject(new Error('API Failed'));
      }
    }
  }
}
