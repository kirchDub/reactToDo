import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { ApplicationService } from '../../../../services/application.service';
import { AuthenticationService } from '../../../../services/authentication.service';
import { FeatureTourService } from '../../../../services/feature-tour.service';
import { ThemeService } from '../../../../services/theme.service';
import { NotificationMessageService } from '../../../../services/notification-message.service';
import { UserService } from '../../../../services/user.service';
import { TopNavService } from '../../../../services/top-nav.service';
import { Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';
import { UserImgPositionService } from '../../../../services/user-img-position.service';
import * as _ from 'lodash';

import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../../store';
import { User } from '../../../../models/user.model';
import { FeatureService } from '../../../../services/features.service';



@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.scss'],
  animations: [
    trigger('menuState', [
      state('closed', style({left: '-235px',
                              opacity: '0',
                              zIndex: '-1',
                              })),
      state('open',   style({left: '0px',
                              opacity: '1',
                              zIndex: '999999999',
                              })),
      transition('closed => open', animate('200ms ease-in')),
      transition('open => closed', animate('200ms ease-out')),

    ])
  ]
})
export class TopnavComponent implements OnInit {
  @ViewChild('profileButton') profileButton: ElementRef;
  @ViewChild('userMenu') userMenu: ElementRef;
  public deskReturnURL: string;
  public mobile = false;
  public imgStyles = {};
  public photoAvailable: boolean;
  public cbPhotoUrl$: Observable<boolean>;
  public user$: Observable<User>;

  constructor(
    public widgetService: ApplicationService,
    public authService: AuthenticationService,
    public userService: UserService,
    public featureTourService: FeatureTourService,
    public appService: ApplicationService,
    public themeService: ThemeService,
    public notificationMessageService: NotificationMessageService,
    public topNavService: TopNavService,
    public imgPositionService: UserImgPositionService,
    public featureService: FeatureService,
    protected router: Router,
    private store: Store<fromStore.UserState>
  ) { }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth < environment.mobileWidthMax) {
      this.mobile = true;
      this.topNavService.mobileWidth = event.target.innerWidth;
      this.topNavService.mobileHeight = screen.height;
    } else {
      this.mobile = false;
    }
  }

  ngOnInit() {
    this.topNavService.mobileWidth = window.innerWidth;
    this.topNavService.mobileHeight = screen.height;
    this.user$ = this.store.select(userstate => userstate.user.user);

    this.cbPhotoUrl$ = this.store.select(userstate => {
      if (_.get(userstate.user, 'user.profile', false) && userstate.user.photoAvailable) {
        this.photoAvailable = true;
        this.imgStyles = this.imgPositionService.getCoords(
          userstate.user.user.profile.cbhomesPhotoFaceCoords,
          environment.topNavDivPicWidth
        );
        this.imgStyles['background-image'] = 'url('
          + userstate.user.user.profile.cbhomesPhotoUrl
          + ')';
      } else {
        this.photoAvailable = false;
        return userstate.user.photoAvailable;
      }
    });

    if (window.screen.width < environment.mobileWidthMax) {
      this.mobile = true;
    }
  }

  setwidth() {
    if (this.profileButton !== undefined) {
      this.topNavService.userNameWidth = this.profileButton.nativeElement.offsetWidth - 19;
    }
  }

  markAsPresented() {
    if ( this.notificationMessageService.messages.length === 0 ) {
      this.notificationMessageService.getNotifications().subscribe(
        (response) => {
        },
        (error) => console.log(error)
      );
    }
    this.notificationMessageService.markAsPresented().subscribe(
      (response) => {},
      (error) => console.log(error)
    );

    if (this.mobile) {
      if (this.router.url === '/mobile-msg') {
        this.router.navigate(['']);
      } else {
        this.router.navigate(['/mobile-msg']);
      }
    }
  }

  toggleWaffleMenu() {
    if (this.mobile) {
      if (this.featureService.enabled('Category Menu')) {
        if (this.router.url === '/categories-menu') {
          this.router.navigate(['']);
        } else {
          this.router.navigate(['/categories-menu']);
        }
      } else {
        if (this.router.url === '/mobile-waffle') {
          this.router.navigate(['']);
        } else {
          this.router.navigate(['/mobile-waffle']);
        }
      }

    }
  }

  toggleMobileUserMenu() {
    this.topNavService.toggleState();
  }

  closeMobileUserMenu() {
    this.topNavService.closeMobileMenu();
  }
}
