import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopnavComponent } from './topnav.component';
import { RouterTestingModule } from '@angular/router/testing';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NotificationMenuComponent } from './notify-menu/notify-menu.component';
import { WaffleMenuComponent } from './waffle-menu/waffle-menu.component';
import { NotificationItemComponent } from './notify-menu/notify-item/notify-item.component';
import { SafeHtmlPipe } from '../../../../pipes/safe-html.pipe';
import { WaffleItemComponent } from './waffle-menu/waffle-item/waffle-item.component';
import { CleanTitlePipe } from '../../../../pipes/cleanTitle.pipe';
import { ApplicationService } from '../../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../store/reducers/user.reducers';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics, GoogleAnalyticsDefaults } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../../services/google-tag-manager.service';
import { ImageCacheService } from '../../../../services/image-cache.service';
import { AuthenticationService } from '../../../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { FeatureTourService } from '../../../../services/feature-tour.service';
import { ThemeService } from '../../../../services/theme.service';
import { NotificationMessageService } from '../../../../services/notification-message.service';
import { TopNavService } from '../../../../services/top-nav.service';
import { DomService } from '../../../../services/dom.service';
import { UserImgPositionService } from '../../../../services/user-img-position.service';
import { WaffleMenuCategoriesComponent } from './waffle-menu-categories/waffle-menu-categories.component';
import { CategoriyItemComponent } from './waffle-menu-categories/categoriy-item/categoriy-item.component';
import { FeatureService } from '../../../../services/features.service';


describe('TopnavComponent', () => {
  let component: TopnavComponent;
  let fixture: ComponentFixture<TopnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TopnavComponent,
        UserMenuComponent,
        NotificationMenuComponent,
        NotificationItemComponent,
        WaffleMenuComponent,
        WaffleItemComponent,
        WaffleMenuCategoriesComponent,
        CategoriyItemComponent,
        SafeHtmlPipe,
        CleanTitlePipe,
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        NgbModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),

      ],
      providers: [
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        FeatureTourService,
        FeatureService,
        ThemeService,
        NotificationMessageService,
        TopNavService,
        DomService,
        UserImgPositionService,

      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
