import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaffleMenuCategoriesComponent } from './waffle-menu-categories.component';
import { RouterTestingModule } from '@angular/router/testing';
import { WaffleApp } from '../../../../../models/waffle-app.model';
import { UserApplication } from '../../../../../models/user-application.model';
import { Application } from '../../../../../models/application.model';
import { CategoriyItemComponent } from './categoriy-item/categoriy-item.component';
import { CleanTitlePipe } from '../../../../../pipes/cleanTitle.pipe';
import { TopNavService } from '../../../../../services/top-nav.service';
import { DomService } from '../../../../../services/dom.service';
import { ApplicationService } from '../../../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleTagManager } from 'angulartics2/gtm';
import { GoogleTagManagerService } from '../../../../../services/google-tag-manager.service';
import { ImageCacheService } from '../../../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../../store/reducers/user.reducers';
import { RecentlyUsedAppsService } from '../../../../../services/recently-used-apps.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/from';
import { ToastyService, ToastyConfig } from 'ngx-toasty';

describe('WaffleMenuCategoriesComponent', () => {
  let component: WaffleMenuCategoriesComponent;
  let fixture: ComponentFixture<WaffleMenuCategoriesComponent>;
  const categories = ['productivity', 'marketing', 'financial', 'education'];
  const groupsHtmlElemets = [];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        WaffleMenuCategoriesComponent,
        CategoriyItemComponent,
        CleanTitlePipe,
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleTagManager]),
        StoreModule.forRoot({user: userReducers}),
      ],
      providers: [
        TopNavService,
        DomService,
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        RecentlyUsedAppsService,
        ToastyService,
        ToastyConfig,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const app = new Application();
    app.id = '42';
    app.name = 'Test App';
    app.oktaName = 'Okta Test app';
    app.waffleName = 'test waff name';
    app.widgetName = 'string';
    app.poweredBy = 'string';
    app.desc = 'string';
    app.fgImage = 'string';
    app.waffleImage = 'string';
    app.widget = true;
    app.state = 42;
    app.type = 1;
    app.gradientDirection = 42;
    app.gradientColorOne = 'string';
    app.gradientColorTwo = 'string';
    app.transparency = 42;
    app.defaultWidgetEnabled = true;
    app.defaultWidgetWeight = 42;
    app.defaultWaffleEnabled = true;
    app.defaultWaffleWeight = 42;
    app.actions = [];

    const userApp = new UserApplication();
    userApp.id = 'string';
    userApp.userId = 'string';
    userApp.widgetWeight = 42;
    userApp.widgetState = 42;
    userApp.waffleWeight = 42;
    userApp.waffleState = 42;
    userApp.lastUsed = 42;
    userApp.app = app;

    const waffleApp = new WaffleApp(userApp);
    waffleApp.app = app;
    const testApps = [waffleApp, waffleApp, waffleApp, waffleApp];
    this.recentsApps = [waffleApp];
    this.testgroups = [];
    let i = 1;

    for (i = 1; i <= 4; i++) {
      const tgroup = {
        'name' : categories[i - 1].toUpperCase(),
        'weight' : i,
        'items' : testApps
      };
      this.testgroups.push(tgroup);
    }

    fixture = TestBed.createComponent(WaffleMenuCategoriesComponent);
    component = fixture.componentInstance;
    component.recentApps$ = Observable.of(this.recentsApps);
    component.groupedCategories$ = Observable.of(this.testgroups);
    component.topNavService.waffleMenuVisible = true;
    fixture.detectChanges();
    component.recentApps$ = Observable.of(this.recentsApps);
    component.groupedCategories$ = Observable.of(this.testgroups);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should have one Recent App', () => {
    fixture.detectChanges();
    const recentAppsHtmlEl = fixture.nativeElement.querySelector('.recent-apps');
    const recentApp = recentAppsHtmlEl.querySelector('app-categoriy-item');
    expect(recentAppsHtmlEl.textContent).toContain('RECENTLY USED');
    expect(recentApp.localName).toEqual('app-categoriy-item');
  });

  it('Should have 4 categories', () => {
    fixture.detectChanges();
    const categoriesElement = fixture.nativeElement.querySelector('.categories-container');
    for (let i = 1; i <= 4; i++) {
      expect(categoriesElement.textContent).toContain(categories[i - 1].toUpperCase());
      groupsHtmlElemets.push(categoriesElement.querySelector('.category-group'));
    }
  });

  it('should have an app-categoriy-item in each category', () => {
    expect(groupsHtmlElemets.length).toBeGreaterThan(0);
    if (groupsHtmlElemets.length > 0) {
      for (const item of groupsHtmlElemets) {
        const appElement = item.querySelector('app-categoriy-item');
        expect(appElement.localName).toEqual('app-categoriy-item');
      }
    }
  });

});
