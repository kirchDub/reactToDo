import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NotificationMessageService } from '../../../../../services/notification-message.service';
import { TopNavService } from '../../../../../services/top-nav.service';

@Component({
  selector: 'app-notification-menu',
  templateUrl: './notify-menu.component.html',
  styleUrls: ['./notify-menu.component.scss']
})

export class NotificationMenuComponent implements OnInit {

  constructor(public notificationService: NotificationMessageService,
              public topNavService: TopNavService) {  }

  ngOnInit() { }
}
