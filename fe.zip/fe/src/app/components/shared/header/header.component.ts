import { Component, OnInit } from '@angular/core';
import { ThemeService } from '../../../services/theme.service';
import { TopNavService } from '../../../services/top-nav.service';
import { ApplicationService } from '../../../services/application.service';
import { ToastyService, ToastyConfig } from 'ngx-toasty';
import { UserService } from '../../../services/user.service';
import {Observable} from 'rxjs/Observable';
import * as fromStore from '../../../store';
import { Store } from '@ngrx/store';
import {environment} from '../../../../environments/environment.prod';
import * as _ from 'lodash';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  isImpersonated$: Observable<boolean>;

  constructor(public themeService: ThemeService,
              public topNavService: TopNavService,
              private toastyService: ToastyService,
              private toastyConfig: ToastyConfig,
              public userService: UserService,
              private userStore: Store<fromStore.UserState>,
              private appStore: Store<fromStore.AppsState>) {
                this.toastyConfig.position = 'top-right';
              }

  ngOnInit() {
    this.isImpersonated$ = this.userStore.select(userstate => {
      const impersonatedByUserId = _.get(userstate.user, 'user.profile.impersonatedByUserId', null);
      const userId = _.get(userstate.user, 'user.id', null);
      return impersonatedByUserId && impersonatedByUserId !== userId;
    });

  }

}
