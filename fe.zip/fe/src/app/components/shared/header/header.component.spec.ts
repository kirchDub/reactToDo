import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { ImpersonationPanelComponent } from './impersonation-panel/impersonation-panel.component';
import { TopnavComponent } from './topnav/topnav.component';
import { IntroModalComponent } from '../intro-modal/intro-modal.component';
import { ToastyModule } from 'ngx-toasty';
import { RouterTestingModule } from '@angular/router/testing';
import { UserMenuComponent } from './topnav/user-menu/user-menu.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NotificationMenuComponent } from './topnav/notify-menu/notify-menu.component';
import { WaffleMenuComponent } from './topnav/waffle-menu/waffle-menu.component';
import { SafeHtmlPipe } from '../../../pipes/safe-html.pipe';
import { NotificationItemComponent } from './topnav/notify-menu/notify-item/notify-item.component';
import { WaffleItemComponent } from './topnav/waffle-menu/waffle-item/waffle-item.component';
import { CleanTitlePipe } from '../../../pipes/cleanTitle.pipe';
import { ThemeService } from '../../../services/theme.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../store/reducers/user.reducers';
import { UserService } from '../../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { TopNavService } from '../../../services/top-nav.service';
import { DomService } from '../../../services/dom.service';
import { ApplicationService } from '../../../services/application.service';
import { ImageCacheService } from '../../../services/image-cache.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../services/auth-providers/okta-authentication.provider';
import { FeatureTourService } from '../../../services/feature-tour.service';
import { NotificationMessageService } from '../../../services/notification-message.service';
import { UserImgPositionService } from '../../../services/user-img-position.service';
import { WaffleMenuCategoriesComponent } from './topnav/waffle-menu-categories/waffle-menu-categories.component';
import { CategoriyItemComponent } from './topnav/waffle-menu-categories/categoriy-item/categoriy-item.component';
import { FeatureService } from '../../../services/features.service';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        HeaderComponent,
        ImpersonationPanelComponent,
        TopnavComponent,
        IntroModalComponent,
        UserMenuComponent,
        NotificationMenuComponent,
        WaffleMenuComponent,
        WaffleItemComponent,
        NotificationItemComponent,
        SafeHtmlPipe,
        CleanTitlePipe,
        WaffleMenuCategoriesComponent,
        CategoriyItemComponent,
      ],
      imports: [
        ToastyModule,
        RouterTestingModule,
        NgbModule,
        HttpClientTestingModule,
        StoreModule.forRoot({user: userReducers}),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
      ],
      providers: [
        ThemeService,
        UserService,
        GoogleTagManagerService,
        TopNavService,
        DomService,
        ApplicationService,
        ImageCacheService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        FeatureTourService,
        NotificationMessageService,
        UserImgPositionService,
        FeatureService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
