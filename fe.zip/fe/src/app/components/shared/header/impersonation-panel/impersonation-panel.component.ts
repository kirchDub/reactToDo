import {Component, NgZone, OnInit, ElementRef, ViewChild, HostListener, Inject, OnDestroy} from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../../../../services/user.service';
import * as _ from 'lodash';
import { TopNavService } from '../../../../services/top-nav.service';
import { DomService } from '../../../../services/dom.service';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { DOCUMENT } from '@angular/common';
import { ActionsSubject, Store } from '@ngrx/store';
import * as fromStore from '../../../../store';

@Component({
  selector: 'app-impersonate-header',
  templateUrl: './impersonation-panel.component.html',
  styleUrls: ['./impersonation-panel.component.scss']
})

export class ImpersonationPanelComponent implements OnInit, OnDestroy {
  public metros = [];
  public message = 'IMPERSONATING: ';
  public finalMessage: string;
  public averageLengthOfaCharecterPx = 8.3;
  public padding = 15;
  public stopButtonLengthPx: number;
  public space4Message: number;
  @ViewChild('msgSpan') msgSpan: ElementRef;
  @ViewChild('stopButton') stopButton: ElementRef;
  @ViewChild('container') container: ElementRef;

  private actionsSubscription = null;


  constructor(
    public topNavService: TopNavService,
    public userService: UserService,
    private httpClient: HttpClient,
    private zone: NgZone,
    public router: Router,
    public domService: DomService,
    private okta: OktaAuthenticationProvider,
    @Inject(DOCUMENT) private doc: any,
    private appStore: Store<fromStore.AppsState>,
    private userStore: Store<fromStore.UserState>,
    private actionsSubject: ActionsSubject,
  ) { }

  ngOnInit() {
    if (this.topNavService.mobile) { this.padding = 10; }
    this.message += this.userService.getProfileFullName() + ' ';

    if (_.get(this.userService.user, 'email', 'Error') !== 'Error') {
      this.message += '<' + this.userService.user.email + '> ';
    }

    if (_.get(this.userService.user, 'profile.metros', 'Error') !== 'Error') {
      if  (this.userService.user.profile.metros.length > 0) {
        this.message += 'Offices: ';
        for ( const m of this.userService.user.profile.metros) {
          this.message += m.name + ', ';
        }
      }
    }

    this.message = this.message.replace(/,\s*$/, '');

    this.actionsSubscription = this.actionsSubject.subscribe(data => {
      const act = data.constructor.name;

      if (act === 'LoadMLSuccess' || act === 'LoadAppsSuccess' ) {
        this.appStore.dispatch(new fromStore.UpdateLinks());
      }
    });

    setTimeout(() => {
      this.stopButtonLengthPx = this.stopButton.nativeElement.offsetWidth;
      this.space4Message = this.container.nativeElement.offsetWidth * 0.85;
      this.cutMessage();
    }, 100);

  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.stopButtonLengthPx = this.stopButton.nativeElement.offsetWidth;
    this.space4Message = this.container.nativeElement.offsetWidth * 0.85;
    this.cutMessage();
  }

  public stopImpersonation() {
    this.userStore.dispatch(new fromStore.StopImpersonate());
  }

  cutMessage() {
    const textLength = this.domService.measureTxt(this.message, 17, 'Roboto');
    const distanceBetweenMessageAndEndButton = this.space4Message - textLength - (this.padding * 2) - this.stopButtonLengthPx;
    if (distanceBetweenMessageAndEndButton < 0 ) {
      const charNum = Math.ceil(Math.abs(distanceBetweenMessageAndEndButton) / Math.floor(this.averageLengthOfaCharecterPx));
      const cutIndex = this.message.length  - charNum;
      const messageCut = this.message.slice(0, cutIndex);
      this.finalMessage = messageCut.trim() + '...';
    } else {
      this.finalMessage = this.message;
    }
  }

  ngOnDestroy() {
    this.actionsSubscription.unsubscribe();
  }
}
