import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { NgbModalRef, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ThemeService } from '../../../services/theme.service';
import { Theme } from '../../../models/theme.model';
import { SafeHtmlPipe } from '../../../pipes/safe-html.pipe';
import { FeatureTourService } from '../../../services/feature-tour.service';

@Component({
  selector: 'app-intro-modal',
  templateUrl: './intro-modal.component.html',
  styleUrls: ['./intro-modal.component.scss']
})


export class IntroModalComponent implements AfterViewInit {
  closeResult: string;
  myTheme: Theme;
  modalReference: any;

  @ViewChild('content') content: ElementRef;

  constructor(
    public themeService: ThemeService,
    private modalService: NgbModal,
    public featureTourService: FeatureTourService,
  ) { }

  ngAfterViewInit() {
    setTimeout( () => this.loadTour(), 0);
  }

  loadTour() {

    this.modalReference = this.modalService.open(this.content);
    this.modalReference.result.then((result) => {
      this.closeResult = ``;
    }, (reason) => {
      this.closeResult = ``;
    });

    this.themeService.setIntroSeen().subscribe(
      (response) => {},
      (error) => console.log(error)
    );
  }

  closeModalPlayTour() {
    this.modalReference.close();
    this.featureTourService.playTour();
  }

}
