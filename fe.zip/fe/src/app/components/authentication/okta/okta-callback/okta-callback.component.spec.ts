import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OktaCallbackComponent } from './okta-callback.component';
import { AuthenticationService } from '../../../../services/authentication.service';
import { UserService } from '../../../../services/user.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GoogleTagManagerService } from '../../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { RouterTestingModule } from '@angular/router/testing';
import { JwtAuthenticationProvider } from '../../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { ApplicationService } from '../../../../services/application.service';
import { ImageCacheService } from '../../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../store/reducers/user.reducers';
import { FeatureTourService } from '../../../../services/feature-tour.service';

describe('OktaCallbackComponent', () => {
  let component: OktaCallbackComponent;
  let fixture: ComponentFixture<OktaCallbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OktaCallbackComponent ],
      imports: [
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        RouterTestingModule,
        StoreModule.forRoot({
          user: userReducers,
        })
      ],
      providers: [
        AuthenticationService,
        UserService,
        GoogleTagManagerService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        ApplicationService,
        ImageCacheService,
        FeatureTourService,
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OktaCallbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
