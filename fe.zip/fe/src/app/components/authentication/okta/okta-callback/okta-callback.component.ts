import { Component, OnInit } from '@angular/core';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../../services/authentication.service';
import {environment} from '../../../../../environments/environment';

@Component({
  selector: 'app-okta-callback',
  templateUrl: './okta-callback.component.html',
  styleUrls: ['./okta-callback.component.scss']
})
export class OktaCallbackComponent implements OnInit {
  public errorMsg: any;
  public hasError = false;
  public gatewayReturnLink: string;

  constructor(
    private auth: AuthenticationService,
    private okta: OktaAuthenticationProvider,
    private router: Router
  ) {}

  ngOnInit() {
    // Handles the response from Okta and parses tokens
    const currentObject = this;
    this.gatewayReturnLink = environment.gatewayURL + '?desk=return';

    this.okta.handleAuthentication().then(function() {
      currentObject.auth.redirectPostLogin();
    }).catch(function(error) {
      currentObject.errorMsg = error.message;
      currentObject.hasError = true;
      return;
    });

  }

  retry() {
    this.okta.logout();
    this.okta.login();
  }
}
