import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OktaLoginComponent } from './okta-login.component';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../../services/user.service';
import { GoogleTagManagerService } from '../../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { ApplicationService } from '../../../../services/application.service';
import { ImageCacheService } from '../../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../../store/reducers/user.reducers';
import { FeatureTourService } from '../../../../services/feature-tour.service';

describe('OktaLoginComponent', () => {
  let component: OktaLoginComponent;
  let fixture: ComponentFixture<OktaLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OktaLoginComponent ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({
          user: userReducers,
        })
      ],
      providers: [
        OktaAuthenticationProvider,
        UserService,
        GoogleTagManagerService,
        ApplicationService,
        ImageCacheService,
        FeatureTourService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OktaLoginComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
