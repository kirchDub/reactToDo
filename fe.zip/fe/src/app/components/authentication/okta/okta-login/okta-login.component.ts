import { Component, OnInit } from '@angular/core';
import { OktaAuthenticationProvider } from '../../../../services/auth-providers/okta-authentication.provider';
import { Router } from '@angular/router';

@Component({
  selector: 'app-okta-login',
  templateUrl: './okta-login.component.html',
  styleUrls: ['./okta-login.component.scss']
})
export class OktaLoginComponent implements OnInit {

  constructor(
    private oktaAuthService: OktaAuthenticationProvider,
    private router: Router
  ) { }

  ngOnInit() {
    if (this.oktaAuthService.getToken()) {
      this.router.navigate(['implicit', 'callback']);
    } else {
      this.oktaAuthService.login();
    }
  }
}
