import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { JwtAuthenticationProvider } from '../../../services/auth-providers/jwt-authentication.provider';
import { UserService } from '../../../services/user.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { ApplicationService } from '../../../services/application.service';
import { ImageCacheService } from '../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { appsReducers } from '../../../store/reducers/apps.reducers';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { PageTitleService } from '../../../services/page-title.service';
import { ThemeService } from '../../../services/theme.service';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({
          apps: appsReducers,
        })
      ],
      providers: [
        JwtAuthenticationProvider,
        UserService,
        GoogleTagManagerService,
        ApplicationService,
        ImageCacheService,
        PageTitleService,
        ThemeService
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
