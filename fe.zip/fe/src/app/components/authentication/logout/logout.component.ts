import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../services/authentication.service';
import { ThemeService } from '../../../services/theme.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {

  constructor(
    public authService: AuthenticationService,
    public themeService: ThemeService
  ) { }

  ngOnInit() {
    this.authService.logout();
  }

  login() {
    this.authService.redirectToLogin();
  }
}
