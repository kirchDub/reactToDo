import { Component, OnInit } from '@angular/core';
import { TopNavService } from '../../services/top-nav.service';
import { ApplicationService } from '../../services/application.service';
import { UserService} from '../../services/user.service';
import { ToastyService, ToastOptions } from 'ngx-toasty';
import { Widget } from '../../models/widget.model';
import { environment } from '../../../environments/environment';
import { DomService } from '../../services/dom.service';
import * as _ from 'lodash';

import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../store';
import {WaffleApp} from '../../models/waffle-app.model';

@Component({
  templateUrl: './mobile-waffle.component.html',
  styleUrls: ['./mobile-waffle.component.scss'],
})



export class MobileWaffleComponent implements OnInit {
  private WAFFLE_TITLE_WIDTH = 60;
  private WAFFLE_FONT_SIZE = 12;
  private WAFFLE_FONT_FAMILY = 'Roboto';

  public mlWidget: Widget;
  public waffleApps$: Observable<WaffleApp[]>;
  public recentApps$: Observable<WaffleApp[]>;

  constructor(public topNavService: TopNavService,
              public appService: ApplicationService,
              public userService: UserService,
              private toastyService: ToastyService,
              public domService: DomService,
              private store: Store<fromStore.AppsState>) { }

  ngOnInit() {
    this.waffleApps$ = this.store.select(state => {
      if (state.apps) {
        return state.apps.waffles;
      }
    });
    this.recentApps$ = this.store.select(state => {
      if (state.apps) {
        return state.apps.recentApps;
      }
    });
  }

  fitTitle(waffleTitle: string) {
    return this.domService.scaleFontSizeToFit(
      waffleTitle,
      this.WAFFLE_TITLE_WIDTH,
      this.WAFFLE_FONT_SIZE,
      this.WAFFLE_FONT_FAMILY,
      true);
  }

  appErrorMsg(event, waffleApp) {
    if (_.get(waffleApp, 'app.actions[0].label', 'Error') === 'Error') {
      event.preventDefault();
      const messageOptions: ToastOptions = {
        title: 'Error',
        msg: 'Unfortunately something did not work as expected. Please try again later.',
        showClose: true,
        timeout: environment.toastyMessageTimeOut,
        theme: 'bootstrap',
      };
      this.toastyService.error(messageOptions);
    }
  }
}
