import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MobileWaffleComponent } from './mobile-waffle.component';
import { CleanTitlePipe } from '../../pipes/cleanTitle.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { TopNavService } from '../../services/top-nav.service';
import { DomService } from '../../services/dom.service';
import { ApplicationService } from '../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { ImageCacheService } from '../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../store/reducers/user.reducers';
import { ToastyService, ToastyConfig } from 'ngx-toasty';

describe('MobileMsgComponent', () => {
  let component: MobileWaffleComponent;
  let fixture: ComponentFixture<MobileWaffleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        MobileWaffleComponent,
        CleanTitlePipe,
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({user: userReducers}),
      ],
      providers: [
        TopNavService,
        DomService,
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        ToastyService,
        ToastyConfig,

      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobileWaffleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
