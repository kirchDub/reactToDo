import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { StaticPagesService } from '../../services/static-pages.service';
import { StaticPage } from '../../models/static-page.model';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-static-pages',
  templateUrl: './static-pages.component.html',
  styleUrls: ['./static-pages.component.scss']
})
export class StaticPagesComponent implements OnInit, OnDestroy {
  content: StaticPage;
  urlPath: string;
  routeChangeListener: Subscription;

  constructor( public staticPages: StaticPagesService,
              private titleService: Title,
              private route: ActivatedRoute,
              private router: Router) {
    this.routeChangeListener = router.events
      .filter(event => event instanceof NavigationEnd)
      .subscribe((event: NavigationEnd) => {
        this.content = null;
        this.presentContent();
        window.scroll(0, 0);
      });
  }

  ngOnInit() {
    this.presentContent();
  }

  ngOnDestroy() {
    this.routeChangeListener.unsubscribe();
  }

  presentContent() {
    const urlPath = this.route.snapshot.paramMap.get('page');

    this.staticPages.getContent(urlPath).subscribe(
    staticPage => {
      if (staticPage instanceof StaticPage) {
        this.content = staticPage;
        this.titleService.setTitle(this.content.title);
      }
    },
    error => {
      this.router.navigate(['pages/not-found']);
    }
  );
  }
}
