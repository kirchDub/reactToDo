import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogWidgetAccordianComponent } from './blog-widget-accordian.component';
import { CleanTitlePipe } from '../../../pipes/cleanTitle.pipe';
import { ApplicationService } from '../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../services/user.service';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { RouterTestingModule } from '@angular/router/testing';
import { ImageCacheService } from '../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { appsReducers } from '../../../store/reducers/apps.reducers';
import { BlogService } from '../../../services/blog.service';

describe('BlogWidgetAccordianComponent', () => {
  let component: BlogWidgetAccordianComponent;
  let fixture: ComponentFixture<BlogWidgetAccordianComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BlogWidgetAccordianComponent,
        CleanTitlePipe,
      ],
      imports: [
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        RouterTestingModule,
        StoreModule.forRoot({
          apps: appsReducers
        })
      ],
      providers: [
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        BlogService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogWidgetAccordianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
