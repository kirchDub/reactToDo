import { Component, Input, OnInit } from '@angular/core';
import { ApplicationService } from '../../../services/application.service';
import { Widget } from '../../../models/widget.model';
import { BlogService } from '../../../services/blog.service';
import { Blog } from '../../../models/blog.model';
import { environment } from '../../../../environments/environment';
import * as _ from 'lodash';
import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../store';


@Component({
  selector: 'app-blog-widget-accordian',
  templateUrl: './blog-widget-accordian.component.html',
  styleUrls: ['./blog-widget-accordian.component.scss']
})
export class BlogWidgetAccordianComponent implements OnInit {
  public isEmpty = false;
  public loading = true;
  @Input()
  public widget: Widget;
  public blogs: Blog[] = [];

  constructor(public appService: ApplicationService,
              public blogService: BlogService,
              private store: Store<fromStore.AppsState>) {
  }

  ngOnInit() {
    if (this.widget) {
      this.blogService.retrieveBlogs(this.widget.app.id).subscribe(
        (response) => {
          this.blogs = _.take(this.blogService.blogs[this.widget.app.id], environment.blogArticleLimit);
          this.isEmpty = this.blogs.length > 0 ? false : true;
          this.loading = false;
        },
        (error) => {
          console.log(error);
          this.loading = false;
        }
      );
    }
  }
}
