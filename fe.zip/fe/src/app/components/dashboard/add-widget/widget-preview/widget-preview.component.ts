import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Widget } from '../../../../models/widget.model';
import { ApplicationService } from '../../../../services/application.service';
import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../../store';

@Component({
  selector: 'app-widget-preview',
  templateUrl: './widget-preview.component.html',
  styleUrls: ['./widget-preview.component.scss']
})
export class WidgetPreviewComponent implements OnInit {

  @Input()
  public widget: Widget;

  @Output()
  widgetEnabled = new EventEmitter<any>();

  constructor(private appService: ApplicationService,
              private store: Store<fromStore.AppsState>) { }

  ngOnInit() {
  }

  enableWidget() {
    this.widgetEnabled.emit(this.widget);
    this.store.dispatch(new fromStore.SaveWidgetState(this.widget));
  }
}
