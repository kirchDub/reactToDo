import { Component, OnInit } from '@angular/core';
import { ApplicationService } from '../../../services/application.service';

import { Widget } from '../../../models/widget.model';
import { select, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../../store';



@Component({
  selector: 'app-add-widget',
  templateUrl: './add-widget.component.html',
  styleUrls: ['./add-widget.component.scss']
})
export class AddWidgetComponent implements OnInit {

  public disabledWidgets$: Observable<Widget[]>;
  public showPanel = false;
  public allowOutsideClose = false;

  constructor(public appService: ApplicationService,
              private store: Store<fromStore.AppsState>) {
  }

  ngOnInit() {
    this.disabledWidgets$ = this.store.select(state => state.apps.disabledWidgets);
  }

  togglePanel() {
    this.showPanel = !this.showPanel;

    if (this.showPanel) {
      setTimeout(() => { this.allowOutsideClose = true; }, 200);
    } else {
      this.allowOutsideClose = false;
    }
  }

  closePanel() {
    if (this.allowOutsideClose) {
      this.showPanel = false;
      this.allowOutsideClose = false;
    }
  }

  onWidgetEnabled() {
    this.allowOutsideClose = false;
    setTimeout(() => { this.allowOutsideClose = true; }, 200);
  }
}
