import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { NgbPanelChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { Widget } from '../../../models/widget.model';
import { ApplicationService } from '../../../services/application.service';
import { FeatureService } from '../../../services/features.service';


@Component({
  selector: 'app-app-accordion',
  templateUrl: './app-accordion.component.html',
  styleUrls: ['./app-accordion.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppAccordionComponent implements OnInit {

  @Input() public widgets: Widget[] = [];
  public activeWidgetId = null;

  constructor(public appService: ApplicationService,
              public featureService: FeatureService,
  ) { }

  ngOnInit() {
  }

  public isActive(widget) {
    return this.activeWidgetId === widget.appId;
  }

  public setActive(widget) {
    return this.activeWidgetId = widget.appId;
  }

  public onPanelChange($event: NgbPanelChangeEvent) {
    if ($event.nextState) {
      this.activeWidgetId = $event.panelId;
    } else {
      this.activeWidgetId = null;
    }
  }
}
