import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAccordionComponent } from './app-accordion.component';
import { NgbAccordionModule, NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import { CleanTitlePipe } from '../../../pipes/cleanTitle.pipe';
import { BlogWidgetAccordianComponent } from '../blog-widget-accordian/blog-widget-accordian.component';
import { ApplicationService } from '../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../services/user.service';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { RouterTestingModule } from '@angular/router/testing';
import { ImageCacheService } from '../../../services/image-cache.service';
import { StoreModule } from '@ngrx/store';
import { appsReducers } from '../../../store/reducers/apps.reducers';
import { FeatureService } from '../../../services/features.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../../services/auth-providers/okta-authentication.provider';
import { FeatureTourService } from '../../../services/feature-tour.service';

describe('AppAccordionComponent', () => {
  let component: AppAccordionComponent;
  let fixture: ComponentFixture<AppAccordionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppAccordionComponent,
        BlogWidgetAccordianComponent,
        CleanTitlePipe,
      ],
      imports: [
        NgbAccordionModule,
        HttpClientTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        RouterTestingModule,
        StoreModule.forRoot({
          apps: appsReducers,
        })
      ],
      providers: [
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        FeatureService,
        NgbAccordionConfig,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        FeatureTourService,
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppAccordionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
