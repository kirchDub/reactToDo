import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';
import { AppAccordionComponent } from './app-accordion/app-accordion.component';
import { DragulaModule } from 'ng2-dragula';
import { AppWidgetComponent } from './app-widget/app-widget.component';
import { BlogWidgetComponent } from './blog-widget/blog-widget.component';
import { AddWidgetComponent } from './add-widget/add-widget.component';
import { NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';
import { CleanTitlePipe } from '../../pipes/cleanTitle.pipe';
import { BlogWidgetAccordianComponent } from './blog-widget-accordian/blog-widget-accordian.component';
import { LinkDrawerComponent } from './app-widget/link-drawer/link-drawer.component';
import { WidgetPreviewComponent } from './add-widget/widget-preview/widget-preview.component';
import { UserService } from '../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../store/reducers/user.reducers';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { GoogleTagManagerService } from '../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthenticationService } from '../../services/authentication.service';
import { JwtAuthenticationProvider } from '../../services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from '../../services/auth-providers/okta-authentication.provider';
import { ApplicationService } from '../../services/application.service';
import { ImageCacheService } from '../../services/image-cache.service';
import { FeatureTourService } from '../../services/feature-tour.service';
import { ThemeService } from '../../services/theme.service';
import { PageTitleService } from '../../services/page-title.service';
import { BlogService } from '../../services/blog.service';
import { ToastyService, ToastyConfig } from 'ngx-toasty';
import { FeatureService } from '../../services/features.service';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DashboardComponent,
        AppAccordionComponent,
        AppWidgetComponent,
        BlogWidgetComponent,
        BlogWidgetAccordianComponent,
        AddWidgetComponent,
        LinkDrawerComponent,
        WidgetPreviewComponent,
        CleanTitlePipe,
      ],
      imports: [
        DragulaModule,
        NgbAccordionModule,
        HttpClientTestingModule,
        RouterTestingModule,
        StoreModule.forRoot({
          user: userReducers,
        }),
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
      ],
      providers: [
        UserService,
        GoogleTagManagerService,
        AuthenticationService,
        JwtAuthenticationProvider,
        OktaAuthenticationProvider,
        ApplicationService,
        ImageCacheService,
        FeatureTourService,
        ThemeService,
        PageTitleService,
        BlogService,
        ToastyService,
        ToastyConfig,
        FeatureService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


});
