import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Widget } from '../../../../models/widget.model';
import { TopNavService } from '../../../../services/top-nav.service';
import { DomService } from '../../../../services/dom.service';
import { ApplicationService } from '../../../../services/application.service';

@Component({
  selector: 'app-link-drawer',
  templateUrl: './link-drawer.component.html',
  styleUrls: ['./link-drawer.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LinkDrawerComponent implements OnInit {
  @Input() public widget: Widget;
  @Input() public placement: string;
  @Input() public CssClass: string;
  @Input() public listItems = [];

  public rightMargin: number;

  constructor(public topNavService: TopNavService,
              public domService: DomService,
              public appService: ApplicationService) { }


  ngOnInit() {
    this.placement === 'footer' ? this.rightMargin = 28 : this.rightMargin = 0;
  }

  public hideLinkDrawer(isOutsideCall: boolean) {
    if (isOutsideCall && !this.domService.allowOutsideClose) {
      return;
    }
    this.widget.drawerState = this.domService.allowOutsideClose = false;
    if (this.topNavService.mobile) {
      this.domService.resumeScroll();
    }
  }
}
