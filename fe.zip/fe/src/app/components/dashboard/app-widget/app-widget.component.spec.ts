import { AppWidgetComponent } from './app-widget.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CleanTitlePipe } from '../../../pipes/cleanTitle.pipe';
import { LinkDrawerComponent } from './link-drawer/link-drawer.component';
import { ApplicationService } from '../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../store/reducers/user.reducers';
import { UserService } from '../../../services/user.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ImageCacheService } from '../../../services/image-cache.service';
import { RecentlyUsedAppsService } from '../../../services/recently-used-apps.service';
import { DomService } from '../../../services/dom.service';
import { TopNavService } from '../../../services/top-nav.service';
import { Widget } from '../../../models/widget.model';
import { UserApplication } from '../../../models/user-application.model';
import { Application } from '../../../models/application.model';


describe('WidgetComponent', () => {
  let component: AppWidgetComponent;
  let fixture: ComponentFixture<AppWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
          AppWidgetComponent,
          LinkDrawerComponent,
          CleanTitlePipe,
      ],
      imports: [
          HttpClientTestingModule,
          StoreModule.forRoot({user: userReducers}),
          Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
          RouterTestingModule,
      ],
      providers: [
          ApplicationService,
          UserService,
          GoogleTagManagerService,
          ImageCacheService,
          RecentlyUsedAppsService,
          DomService,
          TopNavService,
      ]
    })
    .compileComponents();
  }));


  beforeEach(() => {
    const app = new Application();
    app.id = '42';
    app.name = 'Test App';
    app.oktaName = 'Okta Test app';
    app.waffleName = 'test waff name';
    app.widgetName = 'string';
    app.poweredBy = 'string';
    app.desc = 'string';
    app.fgImage = 'string';
    app.waffleImage = 'string';
    app.widget = true;
    app.state = 42;
    app.type = 42;
    app.gradientDirection = 42;
    app.gradientColorOne = 'string';
    app.gradientColorTwo = 'string';
    app.transparency = 42;
    app.defaultWidgetEnabled = true;
    app.defaultWidgetWeight = 42;
    app.defaultWaffleEnabled = true;
    app.defaultWaffleWeight = 42;
    app.actions = [];

    const userApp = new UserApplication();
    userApp.id = 'string';
    userApp.userId = 'string';
    userApp.widgetWeight = 42;
    userApp.widgetState = 42;
    userApp.waffleWeight = 42;
    userApp.waffleState = 42;
    userApp.lastUsed = 42;
    userApp.app = app;

    const widget = new Widget(userApp);

    fixture = TestBed.createComponent(AppWidgetComponent);
    component = fixture.componentInstance;
    component.widget = widget;
    fixture.detectChanges();
  });

  it('should create App widget component', () => {
    expect(component).toBeTruthy();
  });

});
