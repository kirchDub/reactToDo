import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import { ApplicationService } from '../../../services/application.service';
import { RecentlyUsedAppsService } from '../../../services/recently-used-apps.service';
import { UserService} from '../../../services/user.service';
import { Widget } from '../../../models/widget.model';
import { DomService } from '../../../services/dom.service';
import { TopNavService } from '../../../services/top-nav.service';
import { environment } from '../../../../environments/environment';
import * as _ from 'lodash';
import { Store } from '@ngrx/store';
import * as fromStore from '../../../store';
import { MaxLengthValidator } from '@angular/forms';
import { DashboardComponent } from '../dashboard.component';


@Component({
  selector: 'app-app-widget',
  templateUrl: './app-widget.component.html',
  styleUrls: ['./app-widget.component.scss']
})


export class AppWidgetComponent implements OnInit, OnDestroy {
  private WIDGET_FOOTER_WIDTH = 308;
  private FOOTER_FONT_SIZE = 24;
  private FOOTER_FONT_FAMILY = 'Roboto';

  public footerMenuItems = [];
  public drawerMenuItems = [];
  public widgetWidth = 320;
  public widgetFooterPadding  = 6;
  public rightMargin = 28;
  public footerUlWidth: number;
  public allowOutsideClose = false;
  public scaledFontSize: number;

  @Input() public widget: Widget;
  public widgetSubscription = null;

  constructor(public appService: ApplicationService,
              public recentlyUsed: RecentlyUsedAppsService,
              public userService: UserService,
              private store: Store<fromStore.AppsState>,
              public domService: DomService,
              public topNavService: TopNavService,
              ) {
                this.footerUlWidth = this.widgetWidth - (this.widgetFooterPadding * 2);
              }

  ngOnInit() {
    this.widgetSubscription = this.store.select(state => {
      if (state.apps) {
        if (state.apps.loaded) {
          const w = _.filter(state.apps.enabledWidgets, {'appId': this.widget.appId})[0];
          if (w) {
            this.widget = w;

            if (this.widget.app.type === 5 && !this.widget.loaded && !this.widget.loading) {
              this.store.dispatch(new fromStore.LoadML());
            }

            const actions = this.widget.app.getSecondaryActions();
            let footerUlChildWidthSum = 0;
            this.footerMenuItems = [];
            this.drawerMenuItems = [];
            for (let i = 0; i < actions.length; i++) {
              const appActionTextWidth = this.domService.measureTxt(actions[i].label, 16, 'Roboto-Bold');
              if (footerUlChildWidthSum + appActionTextWidth <= this.footerUlWidth) {
                footerUlChildWidthSum += appActionTextWidth + this.rightMargin;
                this.footerMenuItems.push(actions[i]);
              } else {
                this.drawerMenuItems.push(actions[i]);
              }
            }
          }
        }
      }
    }).subscribe();

    this.fitTitle(this.widget.getTitle());
  }

  ngOnDestroy() {
    this.widgetSubscription.unsubscribe();
  }

  disable() {
    this.store.dispatch(new fromStore.SaveWidgetState(this.widget) );
  }

  showFooter() {
    return _.get(this.widget, 'app.actions', []).length > 1;
  }

  public showLinkDrawer() {
    this.widget.drawerState = true;
    if (this.topNavService.mobile) {
      this.domService.stopScroll();
    }

    setTimeout(() => { this.domService.allowOutsideClose = true; }, 200);
  }

  public hideLinkDrawer(isOutsideCall: boolean) {
    if (isOutsideCall && !this.domService.allowOutsideClose) {
      return;
    }
    this.widget.drawerState = this.domService.allowOutsideClose = false;
    if (this.topNavService.mobile) {
      this.domService.resumeScroll();
    }
  }

  public toggleLinkDrawer(isOutsideCall: boolean) {
    if (this.widget.drawerState) {
      this.hideLinkDrawer(isOutsideCall);
    } else {
      this.showLinkDrawer();
    }
  }

  fitTitle(waffleTitle: string) {
    this.scaledFontSize = this.domService.scaleFontSizeToFit(
      waffleTitle,
      this.WIDGET_FOOTER_WIDTH,
      this.FOOTER_FONT_SIZE,
      this.FOOTER_FONT_FAMILY,
      false);
  }

}
