import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogWidgetComponent } from './blog-widget.component';
import { CleanTitlePipe } from '../../../pipes/cleanTitle.pipe';
import { ApplicationService } from '../../../services/application.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { UserService } from '../../../services/user.service';
import { StoreModule } from '@ngrx/store';
import { userReducers } from '../../../store/reducers/user.reducers';
import { GoogleTagManagerService } from '../../../services/google-tag-manager.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { RouterTestingModule } from '@angular/router/testing';
import { ImageCacheService } from '../../../services/image-cache.service';
import { BlogService } from '../../../services/blog.service';

describe('BlogWidgetComponent', () => {
  let component: BlogWidgetComponent;
  let fixture: ComponentFixture<BlogWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        BlogWidgetComponent,
        CleanTitlePipe,
      ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
        StoreModule.forRoot({
          user: userReducers
        })
      ],
      providers: [
        ApplicationService,
        UserService,
        GoogleTagManagerService,
        ImageCacheService,
        BlogService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
