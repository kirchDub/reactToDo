import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ApplicationService } from '../../services/application.service';
import { ThemeService } from '../../services/theme.service';
import { AuthenticationService } from '../../services/authentication.service';
import * as _ from 'lodash';
import { DragulaService } from 'ng2-dragula';
import { UserService } from '../../services/user.service';
import { environment } from '../../../environments/environment';
import { PageTitleService } from '../../services/page-title.service';
import { HttpClient } from '@angular/common/http';
import { Widget } from '../../models/widget.model';
import { WidgetMobileState } from '../../services/application.service';
import { BlogService } from '../../services/blog.service';
import { ToastyService, ToastyConfig, ToastOptions } from 'ngx-toasty';
import { ImageCacheService } from '../../services/image-cache.service';
import { FeatureService } from '../../services/features.service';

import { select, ActionsSubject, Store} from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import * as fromStore from '../../store';
import {User} from '../../models/user.model';

import * as moment from 'moment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit, OnDestroy {

  public enabledWidgets$: Observable<Widget[]>;
  public hasVisibleWidgets$: Observable<boolean>;
  public loading$: Observable<boolean>;
  public loadDragulaWidgets$: Observable<boolean>;
  public imageCache$: Observable<boolean>;
  public user$: Observable<User>;
  public greetingMsg = '';
  public blogVisible: boolean;

  public widgets = [];
  public draggerContainerName = 'dashboard';
  public showdrop = false;
  public officeChanged = false;
  public currentOffice = {id: '', name: '', metroId: '', metroName: ''};
  public mlWidget: Widget;
  public showOffice = false;
  private subsc = null;

  constructor(
    public userService: UserService,
    public authService: AuthenticationService,
    public appService: ApplicationService,
    public themeService: ThemeService,
    private dragulaService: DragulaService,
    private pageTitleService: PageTitleService,
    public widgetService: ApplicationService,
    public httpClient: HttpClient,
    public blogService: BlogService,
    public toastyService: ToastyService,
    private imageCacheService: ImageCacheService,
    public featureService: FeatureService,
    private store: Store<fromStore.AppsState>,
    private userstore: Store<fromStore.UserState>,
    private appStore: Store<fromStore.AppsState>,
    private featureStore: Store<fromStore.FeatureState>,
    private actionsSubject: ActionsSubject,
  ) {}

  ngOnInit() {
    this.user$ = this.userstore.select(state => {
      if (state.user.user) {
        const name = state.user.user.profile.preferredFirstName ?
        state.user.user.profile.preferredFirstName.replace('*', '') : state.user.user.firstName.replace('*', '');
      if (this.isBirthday(state.user.user.profile.birthday) ) {
        this.greetingMsg = 'Happy Birthday, ' + name + '!';
      } else {
        this.greetingMsg = 'Good ' + this.getGreetingTime() + ', ' + name + '.';
      }

      return state.user.user;
      }
    });

    this.hasVisibleWidgets$ = this.store.select(state => {
      if (state.apps.enabledWidgets.length === 0) {
        return false;
      } else if (state.apps.enabledWidgets.length === 1 && state.apps.enabledWidgets[0].app.type === 2) {
        if (_.flatten(_.values(this.blogService.blogs)).length < 1) {
          return true;
        }
      }
      return true;
    });

    this.enabledWidgets$ = this.store.select(state => {
      if (state.apps && state.apps.loaded) {
        return state.apps.enabledWidgets.filter(widget => {
          if (widget.app.type === 2 && !this.featureService.enabled('Hot Releases')) {
            return;
          } else {
            return widget;
          }
        });
      }
    });

    this.loading$ = this.store.select(state => state.apps.loading);
    this.loadDragulaWidgets$ = this.store.select(state => {
      this.appService.enabledWidgets = state.apps.enabledWidgets;
      return true;
    });

    this.imageCache$ = this.store.select(state => {
      for (const w of state.apps.waffles) {
        this.imageCacheService.cacheImage(w.app.waffleImage);
      }
      return true;
    });


    this.pageTitleService.setPageTitle();
    const agents = _.get(this.userService.user, 'profile.agents', []);
    if (agents.length > 0) {
      if (agents.length === 1) {
        this.showOffice = false;  // do not display office if only one but set currentOffice
      } else {
        this.showOffice = true;
      }
      if (this.userService.user.profile.activeOffice) {
        const idx = this.userService.user.profile.agents.findIndex(
          a => (a.office && a.office.id === this.userService.user.profile.activeOffice));
        if (idx > -1) {
          this.setCurrentOffice(idx);
        } else {
          this.setCurrentOffice(0);
          this.setOffice(this.currentOffice.id);
        }
      } else {
        this.setCurrentOffice(0);
        this.setOffice(this.currentOffice.id);
      }
    }

    const component = this;
    this.dragulaService.setOptions(this.draggerContainerName, {
      direction: 'mixed',
      moves: function (el, container, handle) {
        if (!component.appService.isPhoneDevice()) {
          return handle.className === 'handle far fa-arrows';
        }

        return false;
      }
    });

    this.dragulaService.dropModel.subscribe((value) => {
      if (value[0] !== 'dashboard') {
        return;
      }

      this.appService.saveWidgetOrder().subscribe(
        (response) => {
          this.widgets = this.appService.enabledWidgets;
        }, // console.log(response),
        (error) => console.log(error)
      );
    });

    this.authService.isAuthenticatedObs().subscribe(
      (responce) => {
        if (responce) {
          const viewMode = _.get(this.userService.user, 'preferences.mobileViewType', '1');
          if (viewMode === 1) {
            this.appService.widgetState = WidgetMobileState.Collapsed;
          } else {
            this.appService.widgetState = WidgetMobileState.FullTile;
          }
        }
      }
    );

    this.appService.setScreenWidth(window.innerWidth);
  }

  ngOnDestroy() {
    this.dragulaService.destroy(this.draggerContainerName);
    if (this.subsc) {
      this.subsc.unsubscribe();
    }
  }

  getGreetingTime() {
    const afternoonStart = 12;
    const eveningStart = 17;
    const currentHour = parseFloat(moment().format('HH'));

    if (currentHour >= afternoonStart && currentHour < eveningStart) {
      return 'afternoon';
    } else if (currentHour >= eveningStart) {
      return 'evening';
    }

    return 'morning';
  }


  isBirthday(bday) {
    const birthday_day = moment(bday).date();
    const birthday_month = moment(bday).month();
    const today_day = moment().date();
    const today_month = moment().month();
    if (birthday_day === today_day && birthday_month === today_month ) {
      return true;
    }
    return false;
  }

  getGatewayReturnUrl(): string {
    if (this.userService.user && this.userService.user.profile) {
      return environment.gatewayURL + '?desk=return&oktaid=' + this.userService.user.profile.oktaId;
    }

    return null;
  }

  setOfficeSelectorName(metroName, officeName): string {
    let concatSelector = metroName.replace(' Metro', '') + ' - ' + officeName;

    if (concatSelector.length > 35) {
      concatSelector = concatSelector.substr(0, 32) + '...';
    }

    return concatSelector;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.appService.setScreenWidth(window.innerWidth);
  }

  switchMode() {
    this.widgetService.switchWidgetState();
  }

  officeSelect(obj) {
    if (obj.office.name) {
      this.currentOffice.name = obj.office.name;
      this.currentOffice.id = obj.office.id;

      this.setOffice(this.currentOffice.id);
      const idx = this.userService.user.profile.agents.findIndex(a => a.office.id === obj.office.id);
      this.setCurrentOffice(idx);
    }
    this.officeChanged = true;
    this.officeChangedMessage();
    setTimeout( () => this.showdrop = false, 100);
  }

  setOffice(id) {
    // TODO: refactor this to leverage the store.
    this.userService.setOffice(id).subscribe(
      () => {
        this.store.dispatch(new fromStore.LoadML());
      },
      (error) => console.log(error)
    );
  }

  setCurrentOffice(id) {
    if (this.userService.user.profile.agents.length) {
      if (this.userService.user.profile.agents[id].office && this.userService.user.profile.agents[id].metro) {
        this.userService.user.profile.activeOffice = this.userService.user.profile.agents[id].office.id;
        this.currentOffice.id = this.userService.user.profile.agents[id].office.id;
        this.currentOffice.name = this.userService.user.profile.agents[id].office.name;
        this.currentOffice.metroId = this.userService.user.profile.agents[id].metro.id;
        this.currentOffice.metroName = this.userService.user.profile.agents[id].metro.name;
      }
    }
  }
  officeChangedMessage() {
    if (this.officeChanged) {
      const messageOptions: ToastOptions = {
        title: 'Success',
        msg: 'You are now working from ' + this.currentOffice.metroName + ' - ' + this.currentOffice.name + ' ' + this.currentOffice.id,
        showClose: true,
        timeout: environment.toastyMessageTimeOut,
        theme: 'bootstrap',
      };
      this.toastyService.success(messageOptions);
      this.officeChanged = false;
    }
  }
}
