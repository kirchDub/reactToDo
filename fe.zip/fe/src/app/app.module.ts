import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { UiSwitchModule } from 'ngx-ui-switch';
import { AppComponent } from './app.component';
import { AppWidgetComponent } from './components/dashboard/app-widget/app-widget.component';
import { ApplicationService } from './services/application.service';
import { FooterComponent } from './components/shared/footer/footer.component';
import { TopnavComponent } from './components/shared/header/topnav/topnav.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './components/shared/header/header.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AppAccordionComponent } from './components/dashboard/app-accordion/app-accordion.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './components/authentication/login/login.component';
import { AuthGuard } from './guards/auth.guard';
import { routing } from './app.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from './interceptors/token.interceptor';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { DragulaModule } from 'ng2-dragula';
import { AppSummaryComponent } from './components/app-manage/app-summary/app-summary.component';
import { AppManageComponent } from './components/app-manage/app-manage.component';
import { AddWidgetComponent } from './components/dashboard/add-widget/add-widget.component';
import { WidgetPreviewComponent } from './components/dashboard/add-widget/widget-preview/widget-preview.component';
import { ClickOutsideModule } from 'ng-click-outside';
import { WaffleMenuComponent } from './components/shared/header/topnav/waffle-menu/waffle-menu.component';
import { WaffleItemComponent } from './components/shared/header/topnav/waffle-menu/waffle-item/waffle-item.component';
import { NotificationMenuComponent } from './components/shared/header/topnav/notify-menu/notify-menu.component';
import { NotificationItemComponent } from './components/shared/header/topnav/notify-menu/notify-item/notify-item.component';
import { NotificationMessageService } from './services/notification-message.service';
import { Angulartics2Module } from 'angulartics2';
import { Angulartics2GoogleAnalytics } from 'angulartics2/ga';
import { GoogleTagManagerService } from './services/google-tag-manager.service';
import { FeatureTourService } from './services/feature-tour.service';
import { ThemeService } from './services/theme.service';
import { BlogWidgetComponent } from './components/dashboard/blog-widget/blog-widget.component';
import { BlogWidgetAccordianComponent } from './components/dashboard/blog-widget-accordian/blog-widget-accordian.component';
import { BlogService } from './services/blog.service';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { PhonePipe } from './pipes/phone.pipe';
import { CleanTitlePipe } from './pipes/cleanTitle.pipe';
import { IntroModalComponent } from './components/shared/intro-modal/intro-modal.component';
import { SafeHtmlPipe } from './pipes/safe-html.pipe';
import { MessagesComponent } from './components/messages/messages.component';
import { MobileWaffleComponent } from './components/mobile-waffle/mobile-waffle.component';
import { ImpersonateComponent } from './components/impersonate/impersonate.component';
import { ImpersonationPanelComponent } from './components/shared/header/impersonation-panel/impersonation-panel.component';
import { JwtAuthenticationProvider } from './services/auth-providers/jwt-authentication.provider';
import { OktaAuthenticationProvider } from './services/auth-providers/okta-authentication.provider';
import { OktaCallbackComponent } from './components/authentication/okta/okta-callback/okta-callback.component';
import { UserService } from './services/user.service';
import { AuthenticationService } from './services/authentication.service';
import { TopNavService } from './services/top-nav.service';
import { FavoritesComponent } from './components/shared/header/topnav/favorites/favorites.component';
import { UserMenuComponent } from './components/shared/header/topnav/user-menu/user-menu.component';
import { StaticPagesComponent } from './components/static-pages/static-pages.component';
import { StaticPagesService } from './services/static-pages.service';
import { PageTitleService } from './services/page-title.service';
import { ImpersonationFormComponent } from './components/shared/impersonation-form/impersonation-form.component';
import { RecentlyUsedAppsService } from './services/recently-used-apps.service';
import { MobileMsgComponent } from './components/mobile-msg/mobile-msg.component';
import { UserImgPositionService } from './services/user-img-position.service';
import { LogoutComponent } from './components/authentication/logout/logout.component';
import { OktaLoginComponent } from './components/authentication/okta/okta-login/okta-login.component';
import { AppRedirectComponent } from './components/app-redirect/app-redirect.component';
import { AppLoadModule } from './app-load.module';
import { ImageCacheService } from './services/image-cache.service';
import { DomService } from './services/dom.service';
import { ToastyModule } from 'ngx-toasty';
import { FeatureService } from './services/features.service';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { effects } from './store';
import { AppsAPI } from './store/api/apps-api';
import { UserApi } from './store/api/user-api';
import { FeatureAPI } from './store/api/features-api';
import { appsReducers } from './store/reducers/apps.reducers';
import { userReducers } from './store/reducers/user.reducers';
import { featureReducers } from './store/reducers/features.reducers';
import { LinkDrawerComponent } from './components/dashboard/app-widget/link-drawer/link-drawer.component';
import { WaffleMenuCategoriesComponent } from './components/shared/header/topnav/waffle-menu-categories/waffle-menu-categories.component';
import { CategoriyItemComponent } from './components/shared/header/topnav/waffle-menu-categories/categoriy-item/categoriy-item.component';
import { MobileWflCtgrsComponent } from './components/mobile-wfl-ctgrs/mobile-wfl-ctgrs.component';




@NgModule({
  declarations: [
    AppComponent,
    AppWidgetComponent,
    FooterComponent,
    TopnavComponent,
    HeaderComponent,
    DashboardComponent,
    AppAccordionComponent,
    LoginComponent,
    AppSummaryComponent,
    AppManageComponent,
    AddWidgetComponent,
    WidgetPreviewComponent,
    WaffleMenuComponent,
    WaffleItemComponent,
    MobileWaffleComponent,
    NotificationMenuComponent,
    NotificationItemComponent,
    BlogWidgetComponent,
    BlogWidgetAccordianComponent,
    MyProfileComponent,
    PhonePipe,
    CleanTitlePipe,
    IntroModalComponent,
    SafeHtmlPipe,
    MessagesComponent,
    MobileMsgComponent,
    ImpersonateComponent,
    ImpersonationPanelComponent,
    OktaLoginComponent,
    OktaCallbackComponent,
    FavoritesComponent,
    UserMenuComponent,
    StaticPagesComponent,
    ImpersonationFormComponent,
    LogoutComponent,
    AppRedirectComponent,
    LinkDrawerComponent,
    WaffleMenuCategoriesComponent,
    CategoriyItemComponent,
    MobileWflCtgrsComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule.forRoot(),
    ToastyModule.forRoot(),
    FormsModule,
    DragulaModule,
    ClickOutsideModule,
    routing,
    UiSwitchModule,
    Angulartics2Module.forRoot([Angulartics2GoogleAnalytics]),
    Angulartics2Module.forRoot([GoogleTagManagerService]),
    ReactiveFormsModule,
    FormsModule,
    AppLoadModule,
    StoreModule.forRoot({ apps: appsReducers, user: userReducers, features: featureReducers }),
    EffectsModule.forRoot(effects),
    StoreDevtoolsModule.instrument({
      maxAge: 25, // Retains last 25 states
    }),
],
  providers: [
    ApplicationService,
    FeatureTourService,
    AuthGuard,
    AuthenticationService,
    JwtAuthenticationProvider,
    OktaAuthenticationProvider,
    BlogService,
    AuthGuard,
    ThemeService,
    NotificationMessageService,
    UserService,
    TopNavService,
    StaticPagesService,
    PageTitleService,
    RecentlyUsedAppsService,
    UserImgPositionService,
    ImageCacheService,
    DomService,
    AppsAPI,
    UserApi,
    FeatureAPI,
    FeatureService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    ],
  bootstrap: [AppComponent]
})

export class AppModule {
}
