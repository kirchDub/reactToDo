import { Deserializable } from './deserializable.model';

import * as _ from 'lodash';

export class FeatureTourStep implements Deserializable<FeatureTourStep> {
  id: string;
  stepNumber: number;
  selector: string;
  message: string;
  toolTipClass: string;
  highlightClass: string;
  position: string;
  scrollTo: string;
  disableInteraction: string;

  deserialize(input: any): FeatureTourStep {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);
    return this;
  }

  getIntroJSOptions() {
    return {
      intro: this.message,
      element: this.selector,
      position: this.position,
      tool_tip_class: this.toolTipClass,
      highlight_class: this.highlightClass,
      scroll_to: this.scrollTo,
      disale_interaction: this.disableInteraction
    };
  }
}
