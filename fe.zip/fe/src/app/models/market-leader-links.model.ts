import { Deserializable } from './deserializable.model';
import { Office } from './office.model';
import * as _ from 'lodash';

export class MarketLeaderLinks implements Deserializable<MarketLeaderLinks> {
  agentProfileLink: string;
  contactMessagesLink: string;
  contactsLink: string;
  customApplicationLink: string;
  dashboardLink: string;
  listingsLink: string;
  marketingCenterLink: string;
  newContactsLink: string;
  partialMatchLink: string;
  provisionLink: string;
  trackingLink: string;
  upcomingRemindersLink: string;
  newListingsCount: number;
  waitingMessagesCount: number;
  remindersCount: number;
  waitingProspectsCount: number;

  deserialize(input: any): MarketLeaderLinks {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
