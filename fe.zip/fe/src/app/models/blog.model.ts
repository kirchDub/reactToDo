import { Deserializable } from './deserializable.model';

import * as _ from 'lodash';


export class Blog implements Deserializable<Blog> {
  id: string;
  title: string;
  link: string;
  desc: string;
  date: string;

  deserialize(input: any): Blog {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
