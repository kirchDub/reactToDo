import { Deserializable } from './deserializable.model';
import { Metro } from './metro.model';
import { Office } from './office.model';
import { PhoneNumber } from './phone-number.model';
import { RealEstateLicense } from './real-estate-license.model';
import { Agent } from './agent.model';
import * as _ from 'lodash';

export class Profile implements Deserializable<Profile> {
  static readonly EMPLOYEE_MAK_OFFSET = 10000000;

  id: string;
  preferredFirstName: string;
  preferredLastName: string;
  title: string;
  birthday: string;
  wwid: string;
  personId: string;
  oktaId: string;
  cbhomesPhotoUrl: string;
  cbhomesPhotoFaceCoords: string;
  originalToken: string;
  firstLogin: string;
  impersonatedByUserId: string;
  widgetOrderModified: boolean;
  waffleOrderModified: boolean;
  metros: Metro[] = [];
  offices: Office[] = [];
  phoneNumbers: PhoneNumber[] = [];
  realEstateLicenses: RealEstateLicense[] = [];
  activeOffice: string;
  agents: Agent[] = [];

  getLicenseInfo() {
    if (this.realEstateLicenses.length > 0) {
      let licenseInfo = '';

      for (const l of this.realEstateLicenses) {
        if (licenseInfo) {
          licenseInfo += ', ';
        }

        licenseInfo += l.number + ' (' + l.state + ')';
      }

      return licenseInfo;
    }

    return '';
  }

  getFaceCoords() {
    if (this.cbhomesPhotoFaceCoords) {
      return this.cbhomesPhotoFaceCoords;
    }
    return '';
  }

  getTitle() {
    if (this.title) {
      return this.title;
    }
    return '';
  }

  getActiveOffice(): string {
    if (!_.isEmpty(this.activeOffice)) {
      const actAgent: Agent = _.filter(this.agents, ['office.id', this.activeOffice])[0];
      if (!_.isEmpty(actAgent)) {
        return this.activeOffice;
      }
    }

    if (this.agents && this.agents.length > 0) {
      return this.agents[0].office.id;
    }

    return null;
  }

  getActiveAgent(): Agent {
    if (_.isEmpty(this.agents)) {
      return null;
    }

    const actOffice: string = this.getActiveOffice();
    if (_.isEmpty(actOffice)) {
      return null;
    }

    const actAgent: Agent = _.filter(this.agents, ['office.id', actOffice])[0];
    if (!_.isEmpty(actAgent)) {
      return actAgent;
    }

    return null;
  }


  getActiveMAK(): number {
    const activeAgent: Agent = this.getActiveAgent();

    if (activeAgent) {
      return activeAgent.makId;
    }

    if (_.isNumber(this.wwid)) {
      return Profile.EMPLOYEE_MAK_OFFSET + Number(this.wwid);
    }

    return null;
  }

  deserialize(input: any): Profile {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    if (input['agents']) {
      this.agents = [];
      for (const a of input.agents) {
        const agent = new Agent().deserialize(a);
        this.agents.push(agent);
      }
    }

    if (input['metros']) {
      this.metros = [];
      for (const m of input.metros) {
        const metro = new Metro().deserialize(m);
        this.metros.push(metro);
      }
    }

    if (input['offices']) {
      this.offices = [];
      for (const o of input.offices) {
        const office = new Office().deserialize(o);
        this.offices.push(office);
      }
    }

    if (input['phoneNumbers']) {
      this.phoneNumbers = [];
      for (const p of input.phoneNumbers.reverse()) {
        const phoneNumber = new PhoneNumber().deserialize(p);
        this.phoneNumbers.push(phoneNumber);
      }
    }

    if (input['realEstateLicenses']) {
      this.realEstateLicenses = [];
      for (const l of input.realEstateLicenses) {
        const license = new RealEstateLicense().deserialize(l);
        this.realEstateLicenses.push(license);
      }
    }

    return this;
  }
}
