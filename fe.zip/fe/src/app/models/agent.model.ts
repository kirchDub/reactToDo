import { Deserializable } from './deserializable.model';
import { Office } from './office.model';
import { Metro } from './metro.model';
import * as _ from 'lodash';

export class Agent implements Deserializable<Agent> {
  agentId: string;
  makId: number;
  office: Office;
  metro: Metro;

  deserialize(input: any): Agent {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    if (input['metro']) {
      this.metro = new Metro().deserialize(input['metro']);
    }

    if (input['office']) {
      this.office = new Office().deserialize(input['office']);
    }

    return this;
  }
}
