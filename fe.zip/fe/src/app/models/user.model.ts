import { Deserializable } from './deserializable.model';
import { Profile } from './profile.model';
import { UserPreferences } from './user-preferences.model';

import * as _ from 'lodash';

export class User implements Deserializable<User> {
  id: string;
  username: string;
  email: string;
  dateJoined: string;
  firstName: string;
  lastName: string;
  profile: Profile;
  preferences: UserPreferences;
  userPermissions: string[];

  deserialize(input: any): User {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    if (input['profile']) {
      this.profile = new Profile().deserialize(input['profile']);
    }

    if (input['preferences']) {
      this.preferences = new UserPreferences().deserialize(input['preferences']);
    }

    return this;
  }

  getFirstName(): string {
    if (this.profile && this.profile.preferredFirstName) {
      return this.profile.preferredFirstName;
    }

    return this.firstName;
  }

  getLastName(): string {
    if (this.profile && this.profile.preferredLastName) {
      return this.profile.preferredLastName;
    }

    return this.lastName;
  }

  getCbhomesPhotoUrl(): string {
    if (this.profile && this.profile.cbhomesPhotoUrl) {
      return this.profile.cbhomesPhotoUrl;
    }

    return '';
  }

}
