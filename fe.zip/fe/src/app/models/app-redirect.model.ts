import * as _ from 'lodash';
import { Deserializable } from './deserializable.model';

export class AppRedirect implements Deserializable<AppRedirect> {
  appId: string;
  appName: string;
  url: string;
  params: {};

  deserialize(input: any): AppRedirect {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
