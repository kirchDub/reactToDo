import * as _ from 'lodash';

export class Feature {
  name: string;


  constructor(name = '', active = false, allUsers = false) {
    this.name = name;
  }

  deserialize(input: any) {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);
    return this;
  }
}
