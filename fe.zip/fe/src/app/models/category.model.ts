import { WaffleApp } from './waffle-app.model';
export class Category {
    name: string;
    id: number;
    weight: number;
    items: WaffleApp[];

    constructor(name = '', id = 0, weight = 0, items = []) {
      this.name = name;
      this.id = id;
      this.weight = weight;
      this.items = items;
    }
  }
