import { Deserializable } from './deserializable.model';

import * as _ from 'lodash';

export class ApplicationAction implements Deserializable<ApplicationAction> {
  id: string;
  label: string;
  url: string;
  weight: number;
  primary: boolean;
  count: number;

  constructor(id = 0 , label = '', url = '', primary = false, count = 0) {
    this.id = String(id);
    this.label = label;
    this.url = url;
    this.primary = primary;
    this.weight = id;
    this.count = count;
  }

  deserialize(input: any): ApplicationAction {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);
    return this;
  }
}
