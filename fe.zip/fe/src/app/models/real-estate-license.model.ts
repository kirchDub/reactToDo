import { Deserializable } from './deserializable.model';
import * as _ from 'lodash';

export class RealEstateLicense implements Deserializable<RealEstateLicense> {
  id: string;
  type: string;
  state: string;
  number: string;
  expireDate: string;

  deserialize(input: any): RealEstateLicense {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
