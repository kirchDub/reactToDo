import { Deserializable } from './deserializable.model';
import * as _ from 'lodash';

export class Theme implements Deserializable<Theme> {
  appName: string;
  companyLogo: string;
  isBeta: boolean;
  chatActive: boolean;
  gtmCode: string;
  facebookLink: string;
  headerLogoImage: string;
  instagramLink: string;
  introHeader: string;
  introStartDate: Date;
  introVideoEmbed: string;
  privacyPolicyPath: string;
  termsOfServicePath: string;
  twitterLink: string;
  youtubeLink: string;
  helpdeskLabel: string;
  helpdeskPhone: string;
  helpdeskPhoneHint: string;

  deserialize(input: any): Theme {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
