import { Application } from './application.model';
import { UserApplication } from './user-application.model';
import { ApplicationAction } from './application-action.model';

export class WaffleApp {
  id: string;
  appId: string;
  waffleWeight: number;
  waffleState: number;
  app: Application;

  constructor(userApp: UserApplication) {
    this.id = userApp.id;
    this.appId = userApp.app.id;
    this.app = userApp.app;

    this.waffleWeight = userApp.waffleWeight;
    this.waffleState = userApp.waffleState;

    if (this.waffleWeight === 0) {
      this.waffleWeight = userApp.app.defaultWaffleWeight;
    }
  }

  getTitle() {
    if (!this.app.waffleName || 0 === this.app.waffleName.length) {
      return this.app.name;
    }

    return this.app.waffleName;
  }
}
