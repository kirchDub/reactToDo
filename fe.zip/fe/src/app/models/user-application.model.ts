import { Deserializable } from './deserializable.model';
import { Application } from './application.model';

import * as _ from 'lodash';

export class UserApplication implements Deserializable<UserApplication> {
  id: string;
  userId: string;
  widgetWeight: number;
  widgetState: number;
  waffleWeight: number;
  waffleState: number;
  lastUsed: number;
  app: Application;

  deserialize(input: any): UserApplication {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    _.assign(this, _.omit(input, 'application', 'lastUsed'));

    this.lastUsed = 0;
    if (input.lastUsed) {
      this.lastUsed = Math.round(new Date(input.lastUsed).getTime() / 1000);
    }

    this.app = new Application().deserialize(input.application);
    return this;
  }

  markAsRecentlyUsed(): void {
    this.lastUsed = Math.round(new Date().getTime() / 1000);
  }
}
