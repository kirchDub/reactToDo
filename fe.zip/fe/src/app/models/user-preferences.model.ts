import { Deserializable } from './deserializable.model';
import * as _ from 'lodash';

export class UserPreferences implements Deserializable<UserPreferences> {
  id: string;
  mobileViewType: string;
  introVideoSeenOn: Date;

  deserialize(input: any): UserPreferences {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
