import { Deserializable } from './deserializable.model';
import * as _ from 'lodash';
import {FeatureTourUserProgress} from './feature-tour-user-progress.model';

export class NotificationMessage implements Deserializable<NotificationMessage> {
  id: string;
  published: boolean;
  publishOn: string;
  title: string;
  message: string;
  link: string;
  created: string;
  expanded: boolean;
  state: State;

  deserialize(input: any): NotificationMessage {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);
    return this;
  }
}

interface State {
  message: string;
  user: number;
  dismissed: boolean;
  presented: boolean;
}
