import { Application } from './application.model';
import { UserApplication } from './user-application.model';
import { ApplicationAction } from './application-action.model';

export class Widget {
  id: string;
  appId: string;
  widgetWeight: number;
  widgetState: number;
  widgetErrorState: boolean;
  widgetWarningState: boolean;
  drawerState: boolean;
  loading: boolean;
  loaded: boolean;
  app: Application;

  constructor(userApp: UserApplication) {
    this.id = userApp.id;
    this.appId = userApp.app.id;
    this.app = userApp.app;

    this.widgetState = userApp.widgetState;
    this.widgetWeight = userApp.widgetWeight;
    this.widgetErrorState = false;
    this.widgetWarningState = false;
    this.drawerState = false;
    this.loading = false;
    this.loaded = false;

    if (this.widgetWeight === 0) {
      this.widgetWeight = userApp.app.defaultWidgetWeight;
    }
  }

  getTitle() {
    if (!this.app.widgetName || 0 === this.app.widgetName.length) {
      return this.app.name;
    }

    return this.app.widgetName;
  }
}
