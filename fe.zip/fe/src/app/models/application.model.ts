import { Deserializable } from './deserializable.model';
import { ApplicationAction } from './application-action.model';

import * as _ from 'lodash';

export class Application implements Deserializable<Application> {
  id: string;
  name: string;
  categories: [any];
  oktaName: string;
  waffleName: string;
  widgetName: string;
  poweredBy: string;
  desc: string;
  fgImage: string;
  waffleImage: string;
  widget: boolean;
  state: number;
  type: number;
  gradientDirection: number;
  gradientColorOne: string;
  gradientColorTwo: string;
  transparency: number;
  defaultWidgetEnabled: boolean;
  defaultWidgetWeight: number;
  defaultWaffleEnabled: boolean;
  defaultWaffleWeight: number;
  actions: ApplicationAction[];

  deserialize(input: any): Application {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    this.actions = [];

    for (const a of input.actions) {
      const action = new ApplicationAction().deserialize(a);
      this.actions.push(action);
    }

    return this;
  }

  getPrimaryAction(): ApplicationAction {
    return _.filter(this.actions, function(a) { return a.primary; })[0];
  }

  getPrimaryActionUrl(): string {
    const action: ApplicationAction = this.getPrimaryAction();
    if (action) {
      return action.url;
    } else {
      return '#';
    }
  }

  getPrimaryActionLabel(): string {
    const action: ApplicationAction = this.getPrimaryAction();
    if (action) {
      return action.label;
    } else {
      return '';
    }
  }

  getSecondaryActions(): ApplicationAction[] {
    return _.filter(this.actions, function(a) { return !a.primary; });
  }

  getBackgroundGradient(): string {
    return 'linear-gradient(' +
      this.gradientDirection + 'deg, ' +
      this.gradientColorOne + ', ' +
      this.gradientColorTwo + ')';
  }

  hexToRgba(hex) {
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function(m, r, g, b) {
        return r + r + g + g + b + b;
    });
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? 'rgba('
        + parseInt(result[1], 16).toString() + ', '
        + parseInt(result[2], 16).toString() + ', '
        + parseInt(result[3], 16).toString() + ', '
        + this.transparency + ')'
        : null;
}

  getBackgroundTransparentGradient() {
    return 'linear-gradient(' +
      this.gradientDirection + 'deg, ' +
      this.hexToRgba(this.gradientColorOne) + ', ' +
      this.hexToRgba(this.gradientColorTwo) + ')';
  }
}
