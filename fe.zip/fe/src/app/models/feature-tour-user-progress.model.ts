import { Deserializable } from './deserializable.model';

import * as _ from 'lodash';

export class FeatureTourUserProgress implements Deserializable<FeatureTourUserProgress> {
  completed: boolean;
  lastStep: number;
  tourID: number;
  userID: number;

  deserialize(input: any): FeatureTourUserProgress {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }

}
