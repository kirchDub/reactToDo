import { Deserializable } from './deserializable.model';
import * as _ from 'lodash';

export class Metro implements Deserializable<Metro> {
  id: string;
  name: string;
  companyName: string;

  deserialize(input: any): Metro {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    return this;
  }
}
