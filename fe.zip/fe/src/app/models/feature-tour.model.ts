import { FeatureTourStep } from './feature-tour-step.model';
import { Deserializable } from './deserializable.model';
import { FeatureTourUserProgress} from './feature-tour-user-progress.model';

import * as _ from 'lodash';

export class FeatureTour implements Deserializable<FeatureTour> {
  id: string;
  name: string;
  urlPath: string;
  selector: string;
  description: string;
  startDate: string;
  endDate:  string;
  tourSteps: FeatureTourStep[];
  userProgress: FeatureTourUserProgress;

  deserialize(input: any): FeatureTour {
    input = _.mapKeys(input, (v, k: string) => _.camelCase(k));
    Object.assign(this, input);

    this.tourSteps = [];

    for (const a of input.tourSteps) {
      const action = new FeatureTourStep().deserialize(a);
      this.tourSteps.push(action);
    }

    this.userProgress = new FeatureTourUserProgress().deserialize(input.userProgress);

    return this;
  }

  getIntroJSOptions() {
    const options = {};
    const steps = [];

    this.tourSteps.forEach(function (step) {
      steps.push(step.getIntroJSOptions());
    });

    return {
      'steps': steps,
      'tourID': this.id,
      'showStepNumbers': false,
      'skipLabel': 'Exit Tour',
      'nextLabel': 'Next',
      'prevLabel': 'Back',
      'hideNext': true,
      'buttonClass': 'btn  btn-primary',
    };
  }
}
