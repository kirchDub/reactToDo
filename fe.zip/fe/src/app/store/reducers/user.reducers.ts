import * as fromUser from '../actions/user.actions';
import { User } from '../../models/user.model';

export interface UserState {
  user: User;
  imgStyles: any;
  loaded: boolean;
  loading: boolean;
  photoLoaded: boolean;
  photoAvailable: boolean;
  impersonationStartFailure: boolean;
  impersonationStartSuccess: boolean;
  impersonationStartErrorText: string;
}

const initialState = {
  user: null,
  imgStyles: null,
  loaded: false,
  loading: false,
  photoLoaded: false,
  photoAvailable: false,
  impersonationStartFailure: false,
  impersonationStartSuccess: false,
  impersonationStartErrorText: null,
};


 export function  userReducers(state = initialState, action: fromUser.UserAction): UserState {
    switch (action.type) {
    case  fromUser.UPDATE_USER_PROFILE: {
      return {
        ...state,
      };
    }

    case  fromUser.UPDATE_USER_PROFILE_SUCCESS: {
      const user = new User().deserialize(action.payload);
      return {
        ...state,
        user: user,
      };
    }

    case  fromUser.UPDATE_USER_PROFILE_FAIL: {
      return {
        ...state,
      };
    }

    case  fromUser.SYNC_USER_PROFILE: {
      return {
        ...state,
        loading: true
      };
    }

    case  fromUser.SYNC_USER_PROFILE_SUCCESS: {
      return {
        ...state,
        loading: false,
        loaded: true,
      };
    }

    case  fromUser.SYNC_USER_PROFILE_FAIL: {
      return {
        ...state,
        loading: false,
        loaded: false,
      };
    }

    case  fromUser.SYNC_USER_PHOTO: {
      return {
        ...state,
        photoLoaded: false,
      };
    }

    case  fromUser.SYNC_USER_PHOTO_SUCCESS: {


      return {
        ...state,
        photoLoaded: true,
        photoAvailable: true,
      };
    }

    case  fromUser.SYNC_USER_PHOTO_FAIL: {
      return {
        ...state,
        photoLoaded: true,
        photoAvailable: false,
      };
    }

    case fromUser.IMPERSONATE: {
      state.impersonationStartSuccess = false;
      state.impersonationStartFailure = false;
      state.impersonationStartErrorText = null;
      return state;
    }

    case fromUser.IMPERSONATE_SUCCESS: {
      state.impersonationStartSuccess = true;
      window.location.href = window.location.origin;

      return state;
    }

    case fromUser.IMPERSONATE_FAIL: {
      const error = action.payload;
      state.impersonationStartFailure = true;
      state.impersonationStartErrorText = error.error.error;

      return state;
    }

    case fromUser.STOP_IMPERSONATE_SUCCESS: {
      window.location.href = window.location.origin;

      return state;
    }

    default: {
      return state;
    }
  }
}
