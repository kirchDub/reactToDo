import * as fromApps from '../actions/apps.actions';
import { Widget } from '../../models/widget.model';
import { UserApplication } from '../../models/user-application.model';
import { WaffleApp } from '../../models/waffle-app.model';
import * as _ from 'lodash';
import {environment} from '../../../environments/environment';

import { UtilityService } from '../../services/utility.service';



export interface AppsState {
  apps: UserApplication[];
  loaded: boolean;
  loading: boolean;
  enabledWidgets: Widget[];
  disabledWidgets: Widget[];
  waffles: WaffleApp[];
  recentApps: WaffleApp[];
}

const initialState = {
  apps: [],
  loaded: false,
  loading: false,
  enabledWidgets: [],
  disabledWidgets: [],
  waffles: [],
  recentApps: [],
};


 export function  appsReducers(state = initialState, action: fromApps.AppsAction): AppsState {

    switch (action.type) {
      case  fromApps.LOAD_APPS: {
        return {
          ...state,
          loading: true,
        };
      }

      case  fromApps.RESET_WIDGETS_SUCCESS:
      case  fromApps.LOAD_APPS_SUCCESS: {
        const data = action.payload;
        const disabledWidgets = [];
        let enabledWidgets = [];
        let waffleApps = [];
        let recentApps = [];
        const sortedApplications = [];
        for (const userApp of data) {
          const a = new UserApplication().deserialize(userApp);
          if (a.app.type === 1 || a.app.type === 5) {
            waffleApps.push(new WaffleApp(a));
          }
          if (a.app.widget) {
            const w = new Widget(a);
            if (w.widgetState) {
              enabledWidgets.push(w);
            } else {
              disabledWidgets.push(w);
            }
          }
          sortedApplications.push(a);
        }
        enabledWidgets = _.orderBy(enabledWidgets, [function(o) { return o.widgetWeight; }], ['asc']);
        waffleApps = _.orderBy(waffleApps, [function(o) { return o.waffleWeight; }], ['asc']);

        // load recent apps
        recentApps = identifyRecentApps(sortedApplications);

        return {
          ...state,
          apps: sortedApplications,
          loading: false,
          loaded: true,
          enabledWidgets: enabledWidgets,
          disabledWidgets: disabledWidgets,
          waffles: waffleApps,
          recentApps: recentApps,
        };
      }

      case  fromApps.UPDATE_LINKS: {
        for (let i = 0; i < state.apps.length;  i++) {
          state.apps[i] = imp_okta_links_only(state.apps[i]);
        }

        return state;
      }

      case  fromApps.LOAD_APPS_FAIL: {
        return {
          ...state,
          loading: false,
          loaded: false,
        };
      }

      case  fromApps.MARK_AS_RECENT: {
        return state;
      }

      case  fromApps.MARK_AS_RECENT_SUCCESS: {
        const idx = state.apps.findIndex(o => (o.id === action.payload));
        if (idx !== -1) {
          const d = new Date();
          const n = d.getTime();
          state.apps[idx].lastUsed = n;
        }
        const recentApps = identifyRecentApps(state.apps);

        return {
          ...state,
          recentApps: recentApps,
        };
      }

      case  fromApps.SAVE_WIDGET_STATE: {
        const widget = action.payload;
        let idx;
        if (widget.widgetState === 1) {  // from enabled to disabled
          widget.widgetState = 0;
          state.disabledWidgets.push(widget);
          idx = state.enabledWidgets.findIndex(o => (o.appId === widget.appId));
          if (idx !== -1) {
            state.enabledWidgets.splice(idx, 1);
          }
        } else if (widget.widgetState === 0) {  // from disabled to enabled
          widget.widgetState = 1;
          state.enabledWidgets.push(widget);
          idx = state.disabledWidgets.findIndex(o => (o.appId === widget.appId));
          if (idx !== -1) {
            state.disabledWidgets.splice(idx, 1);
          }
        }
        return state;
      }

      case  fromApps.SAVE_WIDGET_STATE_SUCCESS: {
        return state;
      }


      case  fromApps.SAVE_WIDGET_STATE_FAIL: {
        const widget = action.payload;
        let idx;
        if (widget.widgetState === 1) {
          widget.widgetState = 0;
          state.disabledWidgets.push(widget);
          idx = state.enabledWidgets.findIndex(o => (o.appId === widget.appId));
          if (idx !== -1) {
            state.enabledWidgets.splice(idx, 1);
          }
        } else if (widget.widgetState === 0) {
          widget.widgetState = 1;
          state.enabledWidgets.push(widget);
          idx = state.disabledWidgets.findIndex(o => (o.appId === widget.appId));
          if (idx !== -1) {
            state.disabledWidgets.splice(idx, 1);
          }
        }
        return state;
      }

      case  fromApps.LOAD_ML_LINKS: {
        // Reload ML Widget
        const idx = state.enabledWidgets.findIndex(w => w.app.type === 5);

        if (idx < 0) {
          // market leader widget not found
          return state;
        }
        const mlWidget: Widget = state.enabledWidgets[idx];
        mlWidget.loading = true;
        state.enabledWidgets[idx] = mlWidget;

        return state;
      }

      case  fromApps.LOAD_ML_LINKS_SUCCESS: {
        const response = action.payload;
        const links = new UtilityService().loadLinks(response);

        // Reload ML Widget
        const idx = state.enabledWidgets.findIndex(w => w.app.type === 5);

        if (idx < 0) {
          // market leader widget not found
          return state;
        }
        const mlWidget: Widget = state.enabledWidgets[idx];
        mlWidget.app.actions = links;

        if (_.get(mlWidget, 'app.actions[0].label', 'Error') === 'Error') {
          mlWidget.widgetErrorState = true;
        } else {
          mlWidget.widgetErrorState = false;
        }
        if (_.get(mlWidget, 'mlWidget.app.actions[0].label', '') === 'Warning') {
          mlWidget.widgetWarningState = true;
        } else {
          mlWidget.widgetWarningState = false;
        }
        mlWidget.loading = false;
        mlWidget.loaded = true;
        state.enabledWidgets[idx] = mlWidget;

        return state;
      }

      default: {
        return state;
      }
    }
  }

  function identifyRecentApps(apps) {
    const recentApps = [];
    apps = _.orderBy(apps, 'lastUsed', 'desc');
    for (let i = 0; i < environment.LimitRecentApps && i < apps.length; i++) {
      if (apps[i].lastUsed > 0) {
        recentApps.push(new WaffleApp(apps[i]));
      }
    }
    return recentApps;
  }


  function imp_okta_links_only(a) {
    const name: Array<string>  = ['Market Leader', 'CB Exchange', 'LeadRouter', 'Lead Router'];
      if ( name.indexOf(a.app.name) > -1  || name.indexOf(a.app.oktaName) > -1) {
        for (let j = 0; j < a.app.actions.length; j++) {
          if (_.get(a.app.actions[j], 'url', false)) {
            a.app.actions[j].url = 'pages/okta-no-access';
          }
        }
      }
    return a;
  }
