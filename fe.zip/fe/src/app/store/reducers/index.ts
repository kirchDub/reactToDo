import {ActionReducerMap, createSelector} from '@ngrx/store';
import { ActionReducer } from '@ngrx/store';
import { combineReducers } from '@ngrx/store';

import * as fromApps from './apps.reducers';
import * as fromUser from './user.reducers';
import * as fromFeatures from './features.reducers';

export interface AppsState {
  apps: fromApps.AppsState;
}

export interface UserState {
  user: fromUser.UserState;
}

export interface FeatureState {
  features: fromFeatures.FeatureState;
}

export interface State {
  apps: fromApps.AppsState;
  user: fromUser.UserState;
  features: fromFeatures.FeatureState;
}

export const reducers: ActionReducerMap<State> = {
  apps: fromApps.appsReducers,
  user: fromUser.userReducers,
  features: fromFeatures.featureReducers,

};

const combineReducer: ActionReducer<State> = combineReducers(reducers);

export function reducer(state: any, action: any) {
    return combineReducer(state, action);
}



