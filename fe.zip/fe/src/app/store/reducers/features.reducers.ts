import * as fromFeatures from '../actions/features.actions';
import * as _ from 'lodash';
import { environment } from '../../../environments/environment';
import { UtilityService } from '../../services/utility.service';
import { Feature } from '../../models/feature.model';



export interface FeatureState {
    features: Feature[];
    loaded: boolean;
    loading: boolean;
    success: boolean;
}

const initialState = {
    features: [],
    loaded: false,
    loading: false,
    success: false,
};


 export function  featureReducers(state = initialState, action: fromFeatures.FeatureAction): FeatureState {

    switch (action.type) {
      case  fromFeatures.LOAD_FEATURES: {
        return {
          ...state,
          loading: true,
          loaded: false,
          success: false,
        };
      }

      case  fromFeatures.LOAD_FEATURES_SUCCESS: {
        const data = action.payload;
        const receivedFeatures = [];
        for (const feature of data) {
          const a = new Feature().deserialize(feature);
          receivedFeatures.push(a);
        }
        return {
          ...state,
          features: receivedFeatures,
          loading: false,
          loaded: true,
          success: true,
        };
      }

      case  fromFeatures.LOAD_FEATURES_FAIL: {
        return {
          ...state,
          features: [],
          loading: false,
          loaded: true,
          success: false,
        };
      }
    }
}
