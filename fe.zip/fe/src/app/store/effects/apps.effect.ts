import { Injectable } from '@angular/core';
import { Effect, Actions } from '@ngrx/effects';
import * as appsActions from '../actions/apps.actions';
import { of } from 'rxjs/observable/of';
import { distinctUntilChanged, map, switchMap, catchError } from 'rxjs/operators';
import { UserService } from '../../services/user.service';
import { AppsAPI } from '../api/apps-api';
import { Observable } from 'rxjs/Observable';
import { Action } from '@ngrx/store';
import * as _ from 'lodash';

@Injectable()
export class AppsEffect {
  constructor(
    private actions$: Actions,
    private userService: UserService,
    private appsAPI: AppsAPI,
  ) { }

  @Effect()
  loadApps$: Observable<Action> = this.actions$.ofType(appsActions.LOAD_APPS).pipe(
      switchMap(() => {
        return this.appsAPI.LoadApps(this.userService.user.id).pipe(
          map(apps => new appsActions.LoadAppsSuccess(apps)),
          catchError(error => of(new appsActions.LoadAppsFail(error)))
      );
    }));

  @Effect()
  syncApps$: Observable<Action> = this.actions$.ofType(appsActions.SYNC_APPS).pipe(
    switchMap(() => {
      return this.appsAPI.SyncApps(this.userService.user.id).pipe(
        map(apps => new appsActions.SyncAppsSuccess(apps)),
        catchError(error => of(new appsActions.SyncAppsFail(error)))
      );
    }));

  @Effect()
  markAsRecent$: Observable<Action> = this.actions$.ofType(appsActions.MARK_AS_RECENT).pipe(
    map((action: appsActions.MarkAsRecent) => action.payload),
    switchMap((id) => {
      return this.appsAPI
        .MarkAsRecentlyUsed(id)
        .pipe(
          map(() => new appsActions.MarkAsRecentSuccess(id)),
          catchError(error => of(new appsActions.MarkAsRecentFail(error)))
        );
    })
  );

  @Effect()
  saveWidgetState$: Observable<Action> = this.actions$.ofType(appsActions.SAVE_WIDGET_STATE).pipe(
    map((action: appsActions.SaveWidgetState) => action.payload),
    switchMap((widget) => {
      return this.appsAPI
        .SaveWidgetState(widget)
        .pipe(
          map(() => new appsActions.SaveWidgetStateSuccess(widget)),
          catchError(error => of(new appsActions.SaveWidgetStateFail(widget)))
        );
    })
  );

  @Effect()
  loadMLlinks$: Observable<Action> = this.actions$.ofType(appsActions.LOAD_ML_LINKS).pipe(
    switchMap(() => {
      return this.appsAPI.LoadMLlinks(this.userService.user.id).pipe(
        map(links => new appsActions.LoadMLSuccess(links)),
        catchError(error => of(new appsActions.LoadMLFail(error)))
      );
    }));

  @Effect()
  resetWidgets$: Observable<Action> = this.actions$.ofType(appsActions.RESET_WIDGETS).pipe(
    switchMap(() => {
      return this.appsAPI.ResetWidgets(this.userService.user.id).pipe(
        map(apps => new appsActions.ResetWidgetsSuccess(apps)),
        catchError(error => of(new appsActions.ResetWidgetsFail(error)))
      );
    }));
}
