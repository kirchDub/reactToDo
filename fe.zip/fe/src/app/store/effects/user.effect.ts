import {Inject, Injectable} from '@angular/core';
import { Effect, Actions } from '@ngrx/effects';
import * as profileActions from '../actions/user.actions';
import { of } from 'rxjs/observable/of';
import { map, switchMap, catchError } from 'rxjs/operators';
import { UserService } from '../../services/user.service';
import { UserApi } from '../api/user-api';
import { Observable } from 'rxjs/Observable';
import { Action } from '@ngrx/store';

@Injectable()
export class UserEffect {
  constructor(
    private actions$: Actions,
    private userService: UserService,
    private userAPI: UserApi,
  ) { }

  @Effect()
  updateUserProfile$: Observable<Action> = this.actions$.ofType(profileActions.UPDATE_USER_PROFILE).pipe(
    switchMap(() => {
      return this.userAPI.UpdateUserProfile(this.userService.user.id).pipe(
        map(user => new profileActions.UpdateUserProfileSuccess(user)),
        catchError(error => of(new profileActions.UpdateUserProfileFail(error)))
      );
    }));

  @Effect()
  syncUserProfile$: Observable<Action> = this.actions$.ofType(profileActions.SYNC_USER_PROFILE).pipe(
    switchMap(() => {
      return this.userAPI.SyncUserProfile(this.userService.user.id).pipe(
        map(user => new profileActions.SyncUserProfileSuccess(user)),
        catchError(error => of(new profileActions.SyncUserProfileFail(error)))
      );
    }));

  @Effect()
  syncUserPhoto$: Observable<Action> = this.actions$.ofType(profileActions.SYNC_USER_PHOTO).pipe(
    switchMap(() => {
      return this.userAPI.SyncUserPhoto(this.userService.user.id).pipe(
        map(userPhoto => new profileActions.SyncUserPhotoSuccess(userPhoto)),
        catchError(error => of(new profileActions.SyncUserPhotoFail(error)))
      );
    }));

  @Effect()
  impersonate$: Observable<Action> = this.actions$.ofType(profileActions.IMPERSONATE).pipe(
    map((action: profileActions.Impersonate) => action.payload),
    switchMap((email) => {
      return this.userAPI.Impersonate(email).pipe(
        map(() => {
          return new profileActions.ImpersonateSuccess(email);
        }),
        catchError(error => of(new profileActions.ImpersonateFail(error)))
      );
    }));

    @Effect()
    stopImpersonate$: Observable<Action> = this.actions$.ofType(profileActions.STOP_IMPERSONATE).pipe(
      switchMap(() => {
        return this.userAPI.StopImpersonate().pipe(
          map(() => {
            return new profileActions.StopImpersonateSuccess();
          }),
          catchError(error => of(new profileActions.StopImpersonateFail()))
        );
      }));
}
