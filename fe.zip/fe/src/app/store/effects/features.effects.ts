import { Injectable } from '@angular/core';
import { Effect, Actions } from '@ngrx/effects';
import * as featureActions from '../actions/features.actions';
import { of } from 'rxjs/observable/of';
import { distinctUntilChanged, map, switchMap, catchError } from 'rxjs/operators';
import { UserService } from '../../services/user.service';
import { FeatureAPI } from '../api/features-api';
import { Observable } from 'rxjs/Observable';
import { Action } from '@ngrx/store';
import * as _ from 'lodash';

@Injectable()
export class FeatureEffect {
  constructor(
    private actions$: Actions,
    private userService: UserService,
    private featureApi: FeatureAPI,
  ) { }

  @Effect()
  loadFeatures$: Observable<Action> = this.actions$.ofType(featureActions.LOAD_FEATURES).pipe(
      switchMap(() => {
        return this.featureApi.LoadFeatures(this.userService.user.id).pipe(
          map(features => new featureActions.LoadFeaturesSuccess(features)),
          catchError(error => of(new featureActions.LoadFeaturesFail(error)))
      );
    }));
}
