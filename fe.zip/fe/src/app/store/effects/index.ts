import { AppsEffect } from './apps.effect';
import { UserEffect } from './user.effect';
import { FeatureEffect } from './features.effects';

export const effects: any[] = [AppsEffect, UserEffect, FeatureEffect];

export * from './apps.effect';
export * from './user.effect';
export * from './features.effects';
