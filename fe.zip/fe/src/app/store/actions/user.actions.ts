import { Action } from '@ngrx/store';
import { User } from '../../models/user.model';

export const UPDATE_USER_PROFILE       = '[APPS] Load User Profile';
export const UPDATE_USER_PROFILE_SUCCESS    = '[APPS] Load User Profile Success';
export const UPDATE_USER_PROFILE_FAIL    = '[APPS] Load User Profile Fail';

export const SYNC_USER_PROFILE       = '[APPS] Sync User Profile';
export const SYNC_USER_PROFILE_SUCCESS    = '[APPS] Sync User Profile Success';
export const SYNC_USER_PROFILE_FAIL    = '[APPS] Sync User Profile Fail';

export const SYNC_USER_PHOTO       = '[APPS] Sync User Photo';
export const SYNC_USER_PHOTO_SUCCESS    = '[APPS] Sync User Photo Success';
export const SYNC_USER_PHOTO_FAIL    = '[APPS] Sync User Photo Fail';

export const IMPERSONATE       = '[APPS] Impersonate User ';
export const IMPERSONATE_SUCCESS    = '[APPS] Impersonate Success';
export const IMPERSONATE_FAIL    = '[APPS] Impersonate Fail';

export const STOP_IMPERSONATE       = '[APPS] Stop User Impersonation ';
export const STOP_IMPERSONATE_SUCCESS    = '[APPS] Stop User Impersonation Success';
export const STOP_IMPERSONATE_FAIL    = '[APPS] Stop User Impersonation Fail';

export class UpdateUserProfile implements Action {
  readonly type = UPDATE_USER_PROFILE;
}

export class UpdateUserProfileSuccess implements Action {
  readonly type = UPDATE_USER_PROFILE_SUCCESS;
  constructor(public payload: User) {}
}

export class UpdateUserProfileFail implements Action {
  readonly type = UPDATE_USER_PROFILE_FAIL;
  constructor(public payload: any) {}
}

export class SyncUserProfile implements Action {
  readonly type = SYNC_USER_PROFILE;
}

export class SyncUserProfileSuccess implements Action {
  readonly type = SYNC_USER_PROFILE_SUCCESS;
  constructor(public payload: User) {}
}

export class SyncUserProfileFail implements Action {
  readonly type = SYNC_USER_PROFILE_FAIL;
  constructor(public payload: any) {}
}

export class SyncUserPhoto implements Action {
  readonly type = SYNC_USER_PHOTO;
}

export class SyncUserPhotoSuccess implements Action {
  readonly type = SYNC_USER_PHOTO_SUCCESS;
  constructor(public payload: any) {}
}

export class SyncUserPhotoFail implements Action {
  readonly type = SYNC_USER_PHOTO_FAIL;
  constructor(public payload: any) {}
}

export class Impersonate implements Action {
  readonly type = IMPERSONATE;
  constructor(public payload: any) {}
}

export class ImpersonateSuccess implements Action {
  readonly type = IMPERSONATE_SUCCESS;
  constructor(public payload: any) {}
}

export class ImpersonateFail implements Action {
  readonly type = IMPERSONATE_FAIL;
  constructor(public payload: any) {}
}

export class StopImpersonate implements Action {
  readonly type = STOP_IMPERSONATE;
  constructor() {}
}

export class StopImpersonateSuccess implements Action {
  readonly type = STOP_IMPERSONATE_SUCCESS;
  constructor() {}
}

export class StopImpersonateFail implements Action {
  readonly type = STOP_IMPERSONATE_FAIL;
  constructor() {}
}

export type UserAction = UpdateUserProfile
  | UpdateUserProfileSuccess
  | UpdateUserProfileFail
  | SyncUserProfile
  | SyncUserProfileSuccess
  | SyncUserProfileFail
  | SyncUserPhoto
  | SyncUserPhotoSuccess
  | SyncUserPhotoFail
  | Impersonate
  | ImpersonateSuccess
  | ImpersonateFail
  | StopImpersonate
  | StopImpersonateSuccess
  | StopImpersonateFail;
