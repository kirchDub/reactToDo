import { Action } from '@ngrx/store';
import { Feature } from '../../models/feature.model';

export const LOAD_FEATURES       = '[FEATURES] Load Features';
export const LOAD_FEATURES_SUCCESS    = '[FEATURES] Load Features Success';
export const LOAD_FEATURES_FAIL    = '[FEATURES] Load Features Fail';


export class LoadFeatures implements Action {
    readonly type = LOAD_FEATURES;
}
export class LoadFeaturesSuccess implements Action {
    readonly type = LOAD_FEATURES_SUCCESS;
    constructor(public payload: Feature[]) {}
}
export class LoadFeaturesFail implements Action {
    readonly type = LOAD_FEATURES_FAIL;
    constructor(public payload: any) {}
}


export type FeatureAction = LoadFeatures
  | LoadFeaturesSuccess
  | LoadFeaturesFail;
