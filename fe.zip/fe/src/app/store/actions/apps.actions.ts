import { Action } from '@ngrx/store';
import { UserApplication } from '../../models/user-application.model';
import { Widget } from '../../models/widget.model';

export const LOAD_APPS       = '[APPS] Load Apps';
export const LOAD_APPS_SUCCESS    = '[APPS] Load Apps Success';
export const LOAD_APPS_FAIL    = '[APPS] Load Apps Fail';

export const SYNC_APPS       = '[APPS] Sync Apps';
export const SYNC_APPS_SUCCESS    = '[APPS] Sync Apps Success';
export const SYNC_APPS_FAIL    = '[APPS] Sync Apps Fail';

export const SAVE_WIDGET_STATE    = '[APPS] Save Widgets';
export const SAVE_WIDGET_STATE_SUCCESS    = '[APPS] Save Widgets Success';
export const SAVE_WIDGET_STATE_FAIL    = '[APPS] Save Widgets Fail';

export const MARK_AS_RECENT    = '[APPS] Mark as Recently Used';
export const MARK_AS_RECENT_SUCCESS    = '[APPS] Mark as Recently Used Success';
export const MARK_AS_RECENT_FAIL    = '[APPS] Mark as Recently Used Fail';

export const LOAD_ML_LINKS       = '[APPS] Load Market Leader Links';
export const LOAD_ML_LINKS_SUCCESS    = '[APPS] Load Market Leader Links Success';
export const LOAD_ML_LINKS_FAIL    = '[APPS] Load Market Leader Links Fail';

export const RESET_WIDGETS    = '[APPS] Reset Widgets';
export const RESET_WIDGETS_SUCCESS    = '[APPS] Reset Widgets Success';
export const RESET_WIDGETS_FAIL    = '[APPS] Reset Widgets Fail';

export const UPDATE_LINKS       = '[APPS] Update Links When Impersionating';

export class LoadApps implements Action {
  readonly type = LOAD_APPS;
}

export class LoadAppsSuccess implements Action {
  readonly type = LOAD_APPS_SUCCESS;
  constructor(public payload: UserApplication[]) {}
}

export class LoadAppsFail implements Action {
  readonly type = LOAD_APPS_FAIL;
  constructor(public payload: any) {}
}

export class SyncApps implements Action {
  readonly type = SYNC_APPS;
}

export class SyncAppsSuccess implements Action {
  readonly type = SYNC_APPS_SUCCESS;
  constructor(public payload: any) {}
}

export class SyncAppsFail implements Action {
  readonly type = SYNC_APPS_FAIL;
  constructor(public payload: any) {}
}

export class MarkAsRecent implements Action {
  readonly type = MARK_AS_RECENT;
  constructor(public payload: number) {}
}

export class MarkAsRecentSuccess implements Action {
  readonly type = MARK_AS_RECENT_SUCCESS;
  constructor(public payload: number) {}
}

export class MarkAsRecentFail implements Action {
  readonly type = MARK_AS_RECENT_FAIL;
  constructor(public payload: any) {}
}

export class SaveWidgetState implements Action {
  readonly type = SAVE_WIDGET_STATE;
  constructor(public payload: Widget) {}
}

export class SaveWidgetStateSuccess implements Action {
  readonly type = SAVE_WIDGET_STATE_SUCCESS;
  constructor(public payload: Widget) {}
}

export class SaveWidgetStateFail implements Action {
  readonly type = SAVE_WIDGET_STATE_FAIL;
  constructor(public payload: Widget) {}
}

export class LoadML implements Action {
  readonly type = LOAD_ML_LINKS;
}

export class LoadMLSuccess implements Action {
  readonly type = LOAD_ML_LINKS_SUCCESS;
  constructor(public payload: any) {}
}

export class LoadMLFail implements Action {
  readonly type = LOAD_ML_LINKS_FAIL;
  constructor(public payload: any) {}
}

export class ResetWidgets implements Action {
  readonly type = RESET_WIDGETS;
}

export class ResetWidgetsSuccess implements Action {
  readonly type = RESET_WIDGETS_SUCCESS;
  constructor(public payload: UserApplication[]) {}
}

export class ResetWidgetsFail implements Action {
  readonly type = RESET_WIDGETS_FAIL;
  constructor(public payload: any) {}
}

export class UpdateLinks implements Action {
  readonly type = UPDATE_LINKS;
}
export type AppsAction = LoadApps
  | LoadAppsSuccess
  | LoadAppsFail
  | MarkAsRecent
  | MarkAsRecentSuccess
  | MarkAsRecentFail
  | SaveWidgetState
  | SaveWidgetStateSuccess
  | SaveWidgetStateFail
  | LoadML
  | LoadMLSuccess
  | LoadMLFail
  | ResetWidgets
  | ResetWidgetsSuccess
  | ResetWidgetsFail
  | UpdateLinks;



