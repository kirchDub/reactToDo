import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import {finalize, catchError, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Feature } from '../../models/feature.model';
import { environment } from '../../../environments/environment';
import { UserService } from '../../services/user.service';
import * as _ from 'lodash';

@Injectable()
export class FeatureAPI {
  constructor(private httpClient: HttpClient,
              private userService: UserService) { }

  LoadFeatures(userId): Observable<Feature[]> {
    return this.httpClient.get<Feature[]>(environment.apiBaseURL + 'api/users/' + userId + '/features')
      .pipe(
        catchError((error: any) => Observable.throw(error.json())),
      );
  }
}
