import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import {finalize, catchError, map} from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { UserApplication } from '../../models/user-application.model';
import { environment } from '../../../environments/environment';
import { UserService } from '../../services/user.service';
import { Widget } from '../../models/widget.model';
import { WaffleApp } from '../../models/waffle-app.model';
import * as _ from 'lodash';

@Injectable()
export class AppsAPI {
  constructor(private httpClient: HttpClient,
              private userService: UserService) { }

  LoadApps(userId): Observable<UserApplication[]> {
    return this.httpClient.get<UserApplication[]>(environment.apiBaseURL + 'api/users/' + userId + '/apps')
      .pipe(
        catchError((error: any) => Observable.throw(error.json())),
      );
  }

  SyncApps(userId): Observable<UserApplication[]> {
    return this.httpClient.get<UserApplication[]>(environment.apiBaseURL + 'api/users/' + userId + '/apps/sync')
      .pipe(
        catchError((error: any) => Observable.throw(error.json())),
      );
  }

  SaveWidgetState(widget: Widget): Observable<Widget> {
    const data = {
      'widget_state': widget.widgetState
    };
    return this.httpClient.patch<Widget>(environment.apiBaseURL + 'api/user-apps/' + widget.id + '/', data)
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  MarkAsRecentlyUsed(payload: number ): Observable<WaffleApp> {
    let user_id;
    if (_.get(this.userService, 'user.id', false)) {
      user_id = this.userService.user.id;
    }
    return this.httpClient
      .post<WaffleApp>(environment.apiBaseURL + 'api/users/apps/markrecent' , {'app_id': payload, 'user_id': user_id })
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  LoadMLlinks(userId): Observable<any> {
    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + userId + '/market-leader/links')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  ResetWidgets(userId): Observable<any> {
    return this.httpClient.get(environment.apiBaseURL + 'api/users/' + userId + '/apps/widget-reset')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

}
