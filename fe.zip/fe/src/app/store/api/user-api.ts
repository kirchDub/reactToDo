import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { environment } from '../../../environments/environment';

@Injectable()
export class UserApi {
  constructor(private httpClient: HttpClient) { }

  UpdateUserProfile(userId): Observable<any> {
    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + userId + '/')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  SyncUserProfile(userId): Observable<any> {
    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + userId + '/profile/sync/')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  SyncUserPhoto(userId): Observable<any> {
    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + userId + '/profile/photos/sync/')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  SetOffice(userId): Observable<any> {
    return this.httpClient.get<any>(environment.apiBaseURL + 'api/users/' + userId + '/active-office/set')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }

  Impersonate(email): Observable<any> {
    return this.httpClient
      .post(environment.apiBaseURL + 'api/users/impersonate/start/' , {'email': email})
      .pipe(catchError((error: any) => Observable.throw(error)));
  }

  StopImpersonate(): Observable<any> {
    return this.httpClient
      .get(environment.apiBaseURL + 'api/users/impersonate/stop/')
      .pipe(catchError((error: any) => Observable.throw(error.json())));
  }
}
