import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'cleanTitle'})
export class CleanTitlePipe implements PipeTransform {
    // name for google tag manager
    // keep only a-z and 0-9. convert to lowercase
    // spaces to underscores.
  transform(val: string, args) {
    if (val) {
      let appName;
      appName = val.replace(/[^a-zA-Z0-9 ]/g, '');
      appName = appName.replace(/\s+/g, '_');
      appName = appName.toLowerCase();
      return appName;
    }
  }
}
