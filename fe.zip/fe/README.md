# Introduction 
Angular front end component for NRT Productivity Suite

# Getting Started
1. Install NodeJS from https://nodejs.org/en/
2. npm -g install @angular/cli
3. from frontend subdirectory, run NG SERVE

# Notes for initial Angular Install, not needed on subsequent systems
1. npm -g install @angular/cli
2. ng new frontend
3. npm install --save bootstrap

# Frontend

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.3.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
Run `ng serve -environment local` for a dev server with environment set for local.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Integrating A Library
1. npm install --save [LIBRARY]
2. check package-lock.json and package.json
3. in app.module.ts --> add "import" for library
4. in app.module.ts --> add library in "imports:"
5. in component --> add import in compontnet.ts file

## Removing a Library
1. npm uninstall [LIBRARY] --save
2. restart of local server may be required (ng serve)


## Docker Frontend Build / Run Instructions
docker build . -t frontend
docker run frontend -p 8088:80
http://localhost:8088/

## Docker Push to Azure Container Repo
az acr login -name ACRPRDSUITEPOC
az acr login --name ACRPRDSUITEPOC

docker tag frontend ACRPRDSUITEPOC.azurecr.io/ps/frontend:dev
docker push ACRPRDSUITEPOC.azurecr.io/ps/frontend:dev

**
npm install angular2-ui-switch --save


## Use external API on Front end Process
Backend
  Create new feature if necc
  create new URL endpoint
  create new view
  create a new model
  create a new serializer
  create new worker process (maybe)
  test new API through command line
  
Frontend
  Use new backend api to route us to 3rd party api
  



